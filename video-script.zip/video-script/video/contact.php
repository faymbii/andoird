<?php
 
session_start();

include ("includes/config.php");

$action = $_GET[action];

if ($action == 'sendemail') {
    $sendSubject = $_POST[messagesubject];
	$sendMessage = $HTTP_POST_VARS['message'];
	$sendName = $_POST[sendername];
	$sendEmail = $_POST[senderemail];
    if (!empty($sendMessage)) {
      if (preg_match(' /[\r\n,;\'"]/ ', $sendEmail)) {
	      header ("Location: ".$siteurl."/contact.php?e=1");
	      exit();
      } else {
	      @mail($sitecontactemail, $sendSubject, $sendMessage, "From: " .$sendName. "<".$sendEmail.">\nReply-To: ".$sendEmail. "\nX-Mailer: PHP.ee/". phpversion()); 
	      header ("Location: ".$siteurl."/contact.php?e=2");
	      exit();
      }
	} else {
	    header ("Location: ".$_SERVER['HTTP_REFERER']);
		exit();
	}
} else {
    $contactError = $_GET[e];
	if ($contactError == '1') {
		$contactErrorText = "Invalid email address";
	} elseif ($contactError == '2') {
		$contactErrorText = "Thank you, your message was successfully sent.";
	} else {
		$contactErrorText = "";
	}
	$sitename2 = $sitename." - Contact Us";

	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/contact.html");
	include ("templates/".$template."/footer.html");
}

?>