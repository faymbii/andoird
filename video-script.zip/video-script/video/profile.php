<?php
 
session_start();

include ("includes/config.php");

$action = $_GET[action];

if ($action == 'register') {
    if ($userStatus == '1') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$nure = $_GET[e];
	$nurerror = "";
	if ($nure == '1') {
	     $nurerror = "&#1603;&#1604; &#1575;&#1604;&#1581;&#1602;&#1608;&#1604; &#1605;&#1591;&#1604;&#1608;&#1576;&#1577;";
    } elseif ($nure == '2') {
	    $nurerror = "Your passwords did not match";
    } elseif ($nure == '3') {
	    $nurerror = "That username is already taken";
    } elseif ($nure == '4') {
	    $nurerror = "You have entered an invalid email address";
    } elseif ($nure == '5') {
	    $nurerror = "&#1575;&#1604;&#1576;&#1585;&#1610;&#1583; &#1575;&#1604;&#1575;&#1604;&#1603;&#1578;&#1585;&#1608;&#1606;&#1610; &#1605;&#1587;&#1580;&#1604; &#1604;&#1583;&#1610;&#1606;&#1575;";
    } elseif ($nure == '6') {
	    $nurerror = "You have entered an invalid username";
    }
	$pagefile = "register.html";
	$sitename2 = $sitename." - &#1575;&#1604;&#1578;&#1587;&#1580;&#1610;&#1604;";
		
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/register.html");
	include ("templates/".$template."/footer.html");
} elseif ($action == 'addnewuser') {
    if ($userStatus == '1') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$newuserPassword = strip_tags($_POST[newuserPassword]);
	$newuserPassword2 = $_POST[newuserPassword2];
	$newuserEmail = strip_tags($_POST[newuserEmail]);
	$newuserUsername = strip_tags($_POST[newuserUsername]);
    if (strlen($newuserPassword) < '4' || !strlen($newuserEmail) || !strlen($newuserUsername)) {
	    header ("Location: ".$siteurl."/profile.php?action=register&e=1"); 
		exit();
	}
   // Check if email is valid
   $emailval = "^[a-z\'0-9]+([._-][a-z\'0-9]+)*@([a-z0-9]+([._-][a-z0-9]+))+$";
   if (!eregi($emailval,$newuserEmail)  || preg_match(' /[\r\n,;\'"]/ ', $newuserEmail)) {
	 header ("Location: ".$siteurl."/profile.php?action=register&e=4");
     exit();
   }
   if (preg_match(' /[\r\n,;\'"]/ ', $newuserUsername)) {
	 header ("Location: ".$siteurl."/profile.php?action=register&e=6");
     exit();
   }
   // Check passwords
   if ($newuserPassword != $newuserPassword2) {
	 header ("Location: ".$siteurl."/profile.php?action=register&e=2");
     exit();
   }
   // Check if user is already in the database
   $check_username = mysql_query("SELECT count(userid) AS usernamecount FROM users WHERE username = '$newuserUsername'");
   $get_check_username = mysql_fetch_array($check_username);
   $usernamecount = $get_check_username['usernamecount'];
   if ($usernamecount > '0') {
	   header ("Location: ".$siteurl."/profile.php?action=register&e=3");
       exit();
   }
   // Check if email is already in the database
   $check_email = mysql_query("SELECT count(userid) AS emailcount FROM users WHERE email = '$newuserEmail'");
   $get_check_email = mysql_fetch_array($check_email);
   $emailcount = $get_check_email['emailcount'];
   if ($emailcount > '0') {
	   header ("Location: ".$siteurl."/profile.php?action=register&e=5");
     exit();
   }
   
   // Add new user into database
   $newuserPassword = md5($newuserPassword);
   if ($emailconfirmation == '1') {
	   $uniqkey = substr( md5(uniqid (rand())), 0, 10 );
	   $add_result = mysql_query( "INSERT INTO users SET username = '$newuserUsername', password = '$newuserPassword', email = '$newuserEmail', status = '0', joined = now(), receiveemails = '1', confirmation = '$uniqkey', usergroup = '1'");
	   
	   $to = "$newuserEmail";
       $subject = "New User";
       $headers = "Return-Path: ".$sitecontactemail."\r\n";
       $headers .= "From: ".$sitename." <".$sitecontactemail.">\n";
       $headers .= "MIME-Version: 1.0\n";
       $headers .= "Content-type: text/html\r\n"; 
	   
	  		$msg .= "<p dir=\"rtl\" align=\"right\">&#1605;&#1585;&#1581;&#1576;&#1575; ".$lostuserName."</p>
<p dir=\"rtl\" align=\"right\">&#1588;&#1603;&#1585;&#1575; &#1604;&#1603; &#1593;&#1604;&#1609; &#1578;&#1587;&#1580;&#1610;&#1604;&#1603; &#1601;&#1610; &#1605;&#1603;&#1578;&#1576;&#1577; &#1575;&#1604;&#1601;&#1610;&#1583;&#1610;&#1608; &#1575;&#1604;&#1582;&#1575;&#1589;&#1577; &#1576;&#1600; 
".$sitename."</p>
<p dir=\"rtl\" align=\"right\">&#1610;&#1585;&#1580;&#1609;<a href=\"".$siteurl."/profile.php?action=confirmaccount&username=".$newuserUsername."&code=".$uniqkey."\"> 
&#1575;&#1604;&#1590;&#1594;&#1591; &#1607;&#1606;&#1575;</a> &#1604;&#1578;&#1571;&#1603;&#1610;&#1583; &#1575;&#1604;&#1578;&#1587;&#1580;&#1610;&#1604; &#1608; &#1581;&#1578;&#1609; &#1578;&#1578;&#1605;&#1603;&#1606; &#1605;&#1606; &#1575;&#1604;&#1605;&#1588;&#1575;&#1585;&#1603;&#1577; &#1576;&#1575;&#1604;&#1605;&#1603;&#1578;&#1576;&#1577; </p>
<p dir=\"rtl\" align=\"right\">&#1575;&#1584;&#1575; &#1604;&#1605; &#1578;&#1578;&#1605;&#1603;&#1606; &#1605;&#1606; &#1575;&#1604;&#1578;&#1601;&#1593;&#1610;&#1604; &#1593;&#1576;&#1585; &#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1575;&#1593;&#1604;&#1575;&#1607; &#1610;&#1585;&#1580;&#1609; &#1606;&#1587;&#1582; 
&#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1607;&#1584;&#1575; &#1576;&#1575;&#1604;&#1605;&#1578;&#1589;&#1601;&#1581;</p>";

       @mail($to, $subject, $msg, $headers);
       
       $registeringmessage = "Thank you for registering with ".$sitename."! A confirmation email has been sent to your email address. Please click on the link in the email to confirm you account.";
   } else {
	   $add_result = mysql_query( "INSERT INTO users SET username = '$newuserUsername', password = '$newuserPassword', email = '$newuserEmail', status = '1', joined = now(), receiveemails = '1', usergroup = '1'");
	   $registeringmessage = "Thank you for registering with ".$sitename."! You may now log in by entering your username and password into the login box.";   
   }
   $sitename2 = $sitename;
   
   // Load template files
   include ("templates/".$template."/header.html");
   include ("templates/".$template."/addnewuser.html");
   include ("templates/".$template."/footer.html");
} elseif ($action == 'confirmaccount') {
    if ($userStatus == '1') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$confirmUsername = $_GET[username];
	$confirmCode = $_GET[code];
    if (strlen($confirmCode) != '10' || !strlen($confirmUsername)) {
	    header ("Location: ".$siteurl."/"); 
		exit();
	}
	$userinfo_result = mysql_query("SELECT userid, status, confirmation FROM users WHERE username = '$confirmUsername'");
	if (mysql_num_rows($userinfo_result)) {
		$userinfo_row = mysql_fetch_array($userinfo_result);
		
		$confirmUserId = $userinfo_row['userid'];
		$confirmUserStatus = $userinfo_row['status'];
		$confirmCode2 = $userinfo_row['confirmation'];
	}
	if ($confirmUserStatus != '0') {
		header("Location: ".$siteurl."/"); 
		exit();
    }
    if ($confirmCode != $confirmCode2) {
		header("Location: ".$siteurl."/"); 
		exit();
    }
    $result = mysql_query("UPDATE users SET status = '1', confirmation = '' WHERE userid = '$confirmUserId'");
    
	$sitename2 = $sitename." - Account Confirmed";
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/confirmaccount.html");
	include ("templates/".$template."/footer.html");
} elseif ($action == 'edit') {
	if ($userStatus != '1' || $userId == '0') {
		header("Location: ".$siteurl."/");
		exit();
    }
    $error = NULL;
    if (isset($_POST[submit])) {
		$newuserWebsite = strip_tags($_POST[newuserWebsite]);
		if (!empty($newuserWebsite) && !eregi("http://", $newuserWebsite)){
			$newuserWebsite = "http://".$newuserWebsite;
		}
		$newuserLocation = strip_tags($_POST[newuserLocation]);
		$newuserGender = $_POST[newuserGender];
		$newuserPassword = strip_tags($_POST[newuserPassword]);
		$newuserReceiveemails = $_POST[newuserReceiveemails];
		if ($newuserReceiveemails == '1') {
			$newuserReceiveemails = '1';
		} else {
			$newuserReceiveemails = '0';
		}
		$newuserAvatar = strip_tags($_POST[newuserAvatar]);
		if (strlen($_FILES['uploadAvatar']['name']) && $avataruploading == '1') {
			$valid = array ("jpg","gif","png");
			$extension = strtolower( substr($_FILES['uploadAvatar']['name'], -3));
			if (in_array($extension, $valid) && $_FILES['uploadAvatar']['size'] <= $maxavatarsize) {
				$profile_sql = mysql_query("SELECT avatar, avatar_uploaded FROM users WHERE userid = '$userId' && status = '1'");
				$row = mysql_fetch_array($profile_sql);
				$oldAvatar = $row['avatar'];
				$avatar_uploaded = $row['avatar_uploaded'];
				if ($avatar_uploaded == '1' && strlen($oldAvatar)) {
					@unlink("images/avatars/".$oldAvatar);
				}
				@move_uploaded_file($_FILES['uploadAvatar']['tmp_name'], "images/avatars/avatar_".$userId.".".$extension);
				$update_avatar = mysql_query("UPDATE users SET avatar = 'avatar_$userId.$extension', avatar_uploaded = '1' WHERE userid = '$userId'");
			} else {
				$error .= "Couldn't upload avatar! ";
			}
		} elseif (strlen($newuserAvatar)) {
			$profile_sql = mysql_query("SELECT avatar, avatar_uploaded FROM users WHERE userid = '$userId' && status = '1'");
			$row = mysql_fetch_array($profile_sql);
			$oldAvatar = $row['avatar'];
			$avatar_uploaded = $row['avatar_uploaded'];
			if ($avatar_uploaded == '1' && strlen($oldAvatar)) {
				@unlink("images/avatars/".$oldAvatar);
			}
			$update_avatar = mysql_query("UPDATE users SET avatar = '$newuserAvatar', avatar_uploaded = '0' WHERE userid = '$userId'");
		}
		if (!empty($newuserPassword)) {
			if (strlen($newuserPassword) > '2') {
				$newuserPassword = md5($newuserPassword);
				$update = mysql_query("UPDATE users SET location = '$newuserLocation', website = '$newuserWebsite', gender = '$newuserGender', receiveemails = '$newuserReceiveemails', password = '$newuserPassword' WHERE userid = '$userId'");
				$error .= "Profile updated!";
	    	} else {
		    	$error .= "&#1603;&#1604;&#1605;&#1577; &#1575;&#1604;&#1587;&#1585; &#1610;&#1580;&#1576; &#1571;&#1606; &#1578;&#1603;&#1608;&#1606; &#1593;&#1604;&#1609; &#1575;&#1604;&#1571;&#1602;&#1604; 3 &#1575;&#1581;&#1585;&#1601;";
	    	}
		} else {
			$update = mysql_query("UPDATE users SET location = '$newuserLocation', website = '$newuserWebsite', gender = '$newuserGender', receiveemails = '$newuserReceiveemails' WHERE userid = '$userId'");
			$error .= "&#1578;&#1605; &#1578;&#1593;&#1583;&#1610;&#1604; &#1575;&#1604;&#1605;&#1604;&#1601; &#1575;&#1604;&#1588;&#1582;&#1589;&#1610;";
    	}
	}
    $profile_info = mysql_query("SELECT receiveemails, avatar, website, location, gender, avatar_uploaded FROM users WHERE userid = '$userid'");
    $profile_row = mysql_fetch_array($profile_info);
    $userReceiveemails  = $profile_row['receiveemails'];
	$userWebsite = htmlentities($profile_row['website']);
	$userLocation = ($profile_row['location']);
	$userGender = $profile_row['gender'];
	$avatarUploaded = $profile_row['avatar_uploaded'];
	$userAvatar = htmlentities($profile_row['avatar']);
	if (empty($userAvatar)) {
		$displayuserAvatar = $siteurl."/images/noavatar.gif";
		$avatarWidth = "100";
		$avatarHeight = "100";
	} else {
	    if ($avatarUploaded == '1') {
		    $displayuserAvatar = $siteurl."/images/avatars/".$userAvatar;
		} else {
		    $displayuserAvatar = $userAvatar;
		}
		$avatarSize = @getimagesize($displayuserAvatar);
		$avatarWidth = $avatarSize[0];
		$avatarHeight = $avatarSize[1];
		if ($avatarWidth > 150) {
			$change = ($avatarWidth / 150);
			$avatarWidth = 150;
			$avatarHeight = ($avatarHeight / $change);    
		}
		if ($avatarHeight > 150) {
			$change = ($avatarHeight / 150);
			$avatarHeight = 150;
			$avatarWidth = ($avatarWidth / $change);    
		}
	}
	$sitename2 = $sitename." - Edit Profile";
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/editprofile.html");
	include ("templates/".$template."/footer.html");
} else {
    $profileuserId = $_GET[u];
	if (!is_numeric($profileuserId)) {
	    header("Location: ".$siteurl."/"); 
		exit();
	}
	// Get user info
	$profile_sql = mysql_query("SELECT * FROM users WHERE userid = '$profileuserId' && status = '1'");
	if (mysql_num_rows($profile_sql)) {
	    $row = mysql_fetch_array($profile_sql);
		$puserid = $row['userid'];
		$puserName = ($row['username']);
		$puserPlayed = number_format($row['played']);
		$puserComments = number_format($row['comments']);
		$puserdateJoined = $row['joined'];
		$puserGroup = $row['usergroup'];
		if ($puserGroup == '2') {
		    $puserGroup = "Administrator";
		} elseif ($puserGroup == '1') {
			$puserGroup = "Member";
		} else {
		    $puserGroup = "Member";
		}
		$puserGender = $row['gender'];
		if ($puserGender == '1') {
		    $puserGender = "Male";
		} elseif ($puserGender == '2') {
		    $puserGender = "Female";
		} else {
		    $puserGender = "Unspecified";
		}
		$avatarUploaded = $row['avatar_uploaded'];
		$puserAvatar = htmlentities($row['avatar']);
		if (empty($puserAvatar)) {
		    $puserAvatar = $siteurl."/images/noavatar.gif";
		    $avatarWidth = "100";
		    $avatarHeight = "100";
		} else {
		    if ($avatarUploaded == '1') {
		    	$puserAvatar = $siteurl."/images/avatars/".$puserAvatar;
			}
			$avatarSize = @getimagesize($puserAvatar);
			$avatarWidth = $avatarSize[0];
			$avatarHeight = $avatarSize[1];
			if ($avatarWidth > 150) {
			    $change = ($avatarWidth / 150);
				$avatarWidth = 150;
				$avatarHeight = ($avatarHeight / $change);    
			}
			if ($avatarHeight > 150) {
			  $change = ($avatarHeight / 150);
			  $avatarHeight = 150;
			  $avatarWidth = ($avatarWidth / $change);    
			}
		}
		$puserWebsite = htmlentities($row['website']);
		$puserLocation = ($row['location']);
		$puserFavourite = $row['favourite'];
		// Get info about favourite file
		if ($puserFavourite > '0') {
		    $favourite_sql = mysql_query("SELECT title, icon, iconlocation FROM files WHERE fileid = '$puserFavourite'");
			if (mysql_num_rows($favourite_sql) > 0) {
			    $favourite_row = mysql_fetch_array($favourite_sql);
				$favourite_title = $favourite_row['title'];
				$favourite_icon = $favourite_row['icon'];
				$favourite_iconlocation = $favourite_row['iconlocation'];
				if ($favourite_iconlocation == '1') {
				    $favourite_iconurl = $siteurl."/files/image/".$favourite_icon;
				} else {
				    $favourite_iconurl = $favourite_icon;
				}
				$favourite_url = fileurl($puserFavourite,$favourite_title);
			}
		}
		$isonline_sql = mysql_query("SELECT isonline FROM online WHERE uid = '$profileuserId' LIMIT 1");
		$isonline_row = mysql_fetch_array($isonline_sql);
		$isonline = $isonline_row['isonline'];
		if ($isonline == '1') {
		    $isonline = "<font color=\"green\">Online</font>";
		} else {
		    $isonline = "<font color=\"red\">Offline</font>";
		}
    } else {
	    header("Location: ".$siteurl."/"); 
        exit();
    }
	// Show comments
	function displayusercomments($profileuserId) {
	    global $siteurl,$sefriendly;
		// Get comments from MySQL database
		$comments_result = mysql_query("SELECT * FROM comments WHERE userid = '$profileuserId' && status = '1' ORDER BY commentid DESC LIMIT 5");
		if (mysql_num_rows($comments_result)) {
		    while ($row = mysql_fetch_array($comments_result)) {
			    $cfileId = $row['fileid'];
				$comment = nl2br(($row['comment']));
				$comment = bbcode($comment);
				$commentDate = $row['date'];
				// Get file name
				$comment_file_result = mysql_query("SELECT title FROM files WHERE fileid = '$cfileId' LIMIT 1");
				$file_row = mysql_fetch_array($comment_file_result);
				$cfile_title = $file_row[title];
				$cfile_name = "<a href=\"".fileurl($cfileId,$cfile_title)."\">".$cfile_title."</a>";
?>
   <table border="0" width="98%" class="boxestext">
     <tr>
       <td width="50%" valign="top">
       <b>File:</b> <?php echo $cfile_name; ?>
       </td>
       <td width="50%" valign="top">
       <b>Date:</b> <?php echo $commentDate; ?>
       </td>
     </tr>
     <tr>
       <td colspan="2" valign="top">
       <?php echo $comment; ?>
       </td>
     </tr>
   </table>
<?php
		    }
		}
	}
	$sitename2 = $sitename." - ".$puserName;
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/profile.html");
	include ("templates/".$template."/footer.html");
}
?>