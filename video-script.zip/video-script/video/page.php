<?php
 
session_start();

include ("includes/config.php");

$page = $_GET[p];

if (empty($page) || !is_numeric($page)) {
	header("Location: ".$siteurl."/"); 
	exit();
}
$page_result = mysql_query("SELECT * FROM pages WHERE pageid = '$page'");
if (mysql_num_rows($page_result)) {
    $page_row = mysql_fetch_array($page_result);
	$pageTitle = $page_row['title'];
	$pageContent = $page_row['content'];
	$pageKeywords = $page_row['keywords'];
	$pageDescription = $page_row['description'];
} else {
	$pageTitle = "&#1604;&#1575; &#1578;&#1608;&#1580;&#1583; &#1589;&#1601;&#1581;&#1607;";
	$pageContent = "<center><b>&#1604;&#1575; &#1578;&#1608;&#1580;&#1583; &#1589;&#1601;&#1581;&#1607;</b></center>";
	$pageKeywords = "&#1604;&#1575; &#1578;&#1608;&#1580;&#1583; &#1589;&#1601;&#1581;&#1607;";
	$pageDescription = "&#1604;&#1575; &#1578;&#1608;&#1580;&#1583; &#1589;&#1601;&#1581;&#1607;";
}

$sitename2 = $sitename." - ".$pageTitle;
$sitedescription = $pageDescription;
$sitekeywords = $sitekeywords.", ".$pageKeywords;

// Load template files
include ("templates/".$template."/header.html");
include ("templates/".$template."/page.html");
include ("templates/".$template."/footer.html");
?>