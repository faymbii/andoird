<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
if ($siteonline == '0') {
	echo '<div style="border: 1px dotted #5D478B; margin: 5px; padding: 2px; background: #F8F8FF;">
	<a href="index.php?action=config"><font color="#380474">Your arcade is offline!</font></a>
	</div>';
}
// Get number of inactive links
$ial_result = mysql_query("SELECT count(linkid) AS inactive_links FROM links WHERE status = '0'");
$getial = mysql_fetch_array($ial_result); 
$inactivelinks = $getial['inactive_links'];
if ($inactivelinks > '0') {
	echo '<div style="border: 1px dotted #FFC125; margin: 5px; padding: 2px; background: #FEF1B5;">
	<a href="index.php?action=links"><font color="#385E0F">There are '.$inactivelinks.' inactive '; if ($inactivelinks == '1') { echo "link"; } else { echo "links"; } echo '!</font></a>
	</div>';
}

// Get number of inactive files
$iaf_result = mysql_query("SELECT count(fileid) AS inactive_files FROM files WHERE status = '0'");
$getiaf = mysql_fetch_array($iaf_result); 
$inactivefiles = $getiaf['inactive_files'];
if ($inactivefiles  > '0') {
	echo '<div style="border: 1px dotted #6B8E23; margin: 5px; padding: 2px; background: #DFFFA5;">
	<a href="index.php?action=games"><font color="#808000">There '; if ($inactivefiles == '1') { echo "is"; } else { echo "are"; } echo ' '.$inactivefiles.' inactive '; if ($inactivefiles == '1') { echo "file"; } else { echo "files"; } echo '!</font></a>
	</div>';
}

// Get number of submited files
$sf_result = mysql_query("SELECT count(fileid) AS submitted_files FROM files WHERE status = '2'");
$getsf = mysql_fetch_array($sf_result); 
$submittedfiles = $getsf['submitted_files'];
if ($submittedfiles  > '0') {
	echo '<div style="border: 1px dotted #3366CC; margin: 5px; padding: 2px; background: #CCFFFF;">
	<a href="index.php?action=games"><font color="#000066">There '; if ($submittedfiles == '1') { echo "is"; } else { echo "are"; } echo ' '.$submittedfiles.' submitted '; if ($submittedfiles == '1') { echo "file"; } else { echo "files"; } echo ' waiting for approval!</font></a>
	</div>';
}

// Get number of inactive categories
$iac_result = mysql_query("SELECT count(catid) AS inactive_categories FROM categories WHERE status = '0'");
$getiac = mysql_fetch_array($iac_result); 
$inactivecategories = $getiac['inactive_categories'];
if ($inactivecategories  > '0') {
	echo '<div style="border: 1px dotted #4F94CD; margin: 5px; padding: 2px; background: #F0F8FF;">
	<a href="index.php?action=categories"><font color="#36648B">There are '.$inactivecategories.' inactive '; if ($inactivecategories == '1') { echo "category"; } else { echo "categories"; } echo '!</font></a>
	</div>';
}
// Get number of unapproved comments
$uac_result = mysql_query("SELECT count(commentid) AS unapproved_comments FROM comments WHERE status = '0'");
$getuac = mysql_fetch_array($uac_result); 
$unapprovedcomments = $getuac['unapproved_comments'];
if ($unapprovedcomments  > '0') {
	echo '<div style="border: 1px dotted #6B8E23; margin: 5px; padding: 2px; background: #DFFFA5;">
	<a href="index.php?action=approvecomments"><font color="#808000">There are '.$unapprovedcomments.' unapproved '; if ($unapprovedcomments == '1') { echo "comment"; } else { echo "comments"; } echo '!</font></a>
	</div>';
}
	
// Get stats
$total_files = totalfiles();
$total_played = totalplayed();
if ($memberlogin == '1') {
	$total_members = totalmembers();
}
?>

<p align="right" dir="rtl">

<br /><br />
<font color="#FF0000">&#1605;&#1580;&#1605;&#1608;&#1593;&#1577; &#1575;&#1604;<span lang="ar-sa">&#1602;&#1575;&#1591;&#1593;
</span>&nbsp;: <b><?php echo $total_files; ?></b><br />
&#1605;&#1588;&#1575;&#1607;&#1583;&#1575;&#1578; &#1575;&#1604;&#1610;&#1608;&#1605;: <b><?php echo $played_today; ?></b><br />
&#1605;&#1580;&#1605;&#1608;&#1593; &#1575;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1575;&#1578;</span> : <b><?php echo $total_played; ?></b><br />
&#1605;&#1580;&#1605;&#1608;&#1593; &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569; : <b><?php echo $total_members; ?></b>
<br /></font><br />
</p>

