<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT * FROM files WHERE fileid = '$gameid'");
	
	if (mysql_num_rows($sql)) {
	$row = mysql_fetch_array($sql);
	$fileid = $row['fileid'];
	$file = $row['file'];
	$image = $row['icon'];
	$filelocation = $row['filelocation'];
	$imagelocation = $row['iconlocation'];
	$customcode = $row['customcode'];
	$filetitle = $row['title'];
	$filedescription = $row['description'];
	$filekeywords = $row['keywords'];
	$filewidth = $row['width'];
	$fileheight = $row['height'];
	$filecategory = $row['category'];
	$timesplayed = $row['timesplayed'];
	$filestatus = $row['status'];
	$filetype = $row['filetype'];

	$category_sql = mysql_query("SELECT name FROM categories WHERE catid = '$filecategory'");
	$category_row = mysql_fetch_array($category_sql);
	$categoryname = $category_row['name'];
    } else {
	    header ("Location: index.php?action=games");
	    exit();
    }
?>
<center><a href="index.php?action=addgame">&#1575;&#1590;&#1601; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | <a href="index.php?action=grabfile">Grab File</a> | 
<a href="index.php?action=uploadfile">&#1585;&#1601;&#1593; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | 
<a href="index.php?action=approvecomments">&#1575;&#1583;&#1575;&#1585;&#1577; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</a></center><br />
<form action="index.php?action=updategame" method="POST" name="form">
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if (strlen($error)) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="2"><font color="red"><b><?php echo $error; ?></b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="20%" valign="top" dir="rtl">&#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1604;&#1601; :</td><td width="80%"><input type="text" name="name" value="<?php echo $filetitle; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top" dir="rtl">&#1575;&#1604;&#1608;&#1589;&#1601; :</td><td width="80%"><textarea name="description" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $filedescription; ?></textarea></td>
  </tr>
  <tr>
  <td width="20%" valign="top" dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1577; :</td><td width="80%"><textarea name="keywords" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $filekeywords; ?></textarea></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top" dir="rtl">&#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601; :</td><td width="80%"><select name="category"><option value="<?php echo $filecategory; ?>" selected><?php echo $categoryname; ?></option><?php $category_result = mysql_query("SELECT name,catid FROM categories ORDER BY name"); if (mysql_num_rows($category_result)) { while($cat_row = mysql_fetch_array($category_result)) { echo "<option value=\"".$cat_row['catid']."\">".$cat_row['name']."</option>"; } }?></select></td>
  </tr>
  <tr>
  <td width="20%" valign="top" dir="rtl">&#1575;&#1604;&#1591;&#1608;&#1610;&#1604; &#1608;&#1575;&#1604;&#1593;&#1585;&#1590;</td><td width="80%"><input type="text" name="width" value="<?php echo $filewidth; ?>" style="width: 50px; margin: 2px; border: 1px solid #4A708B;"> x <input type="text" name="height" value="<?php echo $fileheight; ?>" style="width: 50px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top" dir="rtl">&#1606;&#1608;&#1593; &#1575;&#1604;&#1605;&#1604;&#1601; :</td><td width="80%"><select name="gamefiletype"><option value="1" <?php if ($filetype == '1') { echo "selected"; } ?>>Google Flash</option><option value="2" <?php if ($filetype == '2') { echo "selected"; } ?>>dailymotion no url</option><option value="3" <?php if ($filetype == '3') { echo "selected"; } ?>>dailymotion flash</option><option value="4" <?php if ($filetype == '4') { echo "selected"; } ?>>&#1601;&#1610;&#1583;&#1610;&#1608;</option><option value="5" <?php if ($filetype == '5') { echo "selected"; } ?>>YouTube Flash</option></select></td>
  </tr>
  <tr>
  <td width="20%" valign="top" dir="rtl">&#1585;&#1575;&#1576;&#1591; &#1575;&#1604;&#1605;&#1604;&#1601;</td><td width="80%"><input type="text" name="gamefile" value="<?php echo $file; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"> <select name="filelocation"><option value="1" <?php if ($filelocation == '1') { echo "selected"; } ?>>&#1605;&#1581;&#1604;&#1610;</option><option value="2" <?php if ($filelocation == '2') { echo "selected"; } ?>>&#1585;&#1575;&#1576;&#1591; &#1582;&#1575;&#1585;&#1580;&#1610;</option><option value="3" <?php if ($filelocation == '3') { echo "selected"; } ?>>Frame</option></select> 
	<a target="_blank" href="?php if ($filelocation == '1') { echo $siteurl.'/files/'.$filesdir.'/'.$file; } else { echo $file; } ?">
	&#1605;&#1588;&#1575;&#1607;&#1583;&#1577;</a><?php if ($filelocation == '1') { ?> | 
	<a target="_self" href="index.php?action=editgame&gameid=<?php echo $fileid; ?>&a=deletefile">
	&#1581;&#1584;&#1601;</a><?php } ?></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top" dir="rtl">&#1603;&#1608;&#1583; &#1610;&#1583;&#1608;&#1610;</td><td width="80%"><textarea name="customcode" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $customcode; ?></textarea></td>
  </tr>
  <tr>
  <td width="20%" valign="top" dir="rtl">&#1589;&#1608;&#1585;&#1577; &#1605;&#1593;&#1576;&#1585;&#1607; &#1593;&#1606; &#1575;&#1604;&#1605;&#1604;&#1601;</td><td width="80%"><input type="text" name="gameimage" value="<?php echo $image; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"> <select name="imagelocation"><option value="1" <?php if ($imagelocation == '1') { echo "selected"; } ?>>&#1605;&#1581;&#1604;&#1610;</option><option value="2" <?php if ($imagelocation == '2') { echo "selected"; } ?>>&#1585;&#1575;&#1576;&#1591; &#1582;&#1575;&#1585;&#1580;&#1610;</option></select> 
	<a target="_blank" href="?php if ($imagelocation == '1') { echo $siteurl.'/files/image/'.$image; } else { echo $image; } ?">
	&#1605;&#1588;&#1575;&#1607;&#1583;&#1577;</a><?php if ($imagelocation == '1') { ?> | 
	<a target="_self" href="index.php?action=editgame&gameid=<?php echo $fileid; ?>&a=deleteimage">
	&#1581;&#1584;&#1601;</a><?php } ?></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top" dir="rtl">
	<p dir="rtl">&#1575;&#1604;&#1581;&#1575;&#1604;&#1577; :</td><td width="80%"><select name="filestatus"><option value="1" <?php if ($filestatus == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($filestatus == '0') { echo "selected"; } ?>>&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  </tr>
  <tr>
  <td colspan="2" align="center"><input type="hidden" name="gameid" value="<?php echo $fileid; ?>">
	<input type="submit" name="submit" value="&#1581;&#1601;&#1592; &#1575;&#1604;&#1578;&#1593;&#1583;&#1610;&#1604;&#1575;&#1578;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=games">< &#1585;&#1580;&#1608;&#1593;</a>