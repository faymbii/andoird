<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT * FROM links WHERE linkid = '$linkid'");
	
	if (mysql_num_rows($sql)) {
	$row = mysql_fetch_array($sql);
	
	$linkName = htmlentities($row['name']);
	$linkDescription = htmlentities($row['description']);
	$linkURL = htmlentities($row['linkurl']);
	$linkEmail = htmlentities($row['email']);
	$linkStatus = $row['status'];

    } else {
	    header ("Location: index.php?action=links");
	    exit();
    }
?>
<center><a href="index.php?action=addlink" style="color: #003366;">Add New Link</a></center><br />
<form action="index.php?action=updatelink" method="POST" name="form">
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="2"><font color="red"><b>Link updated!</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="20%" valign="top">Website Name:</td><td width="80%"><input type="text" name="linkname" value="<?php echo $linkName; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top">URL:</td><td width="80%"><input type="text" name="linkurl" value="<?php echo $linkURL; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="20%" valign="top">Description:</td><td width="80%"><textarea name="linkdescription" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $linkDescription; ?></textarea></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top">Contact Email:</td><td width="80%"><input type="text" name="linkemail" value="<?php echo $linkEmail; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="20%" valign="top">Status:</td><td width="80%"><select name="linkstatus"><option value="1" <?php if ($linkStatus == '1') { echo "selected"; } ?>>Active</option><option value="0" <?php if ($linkStatus == '0') { echo "selected"; } ?>>Inactive</option></select></td>
  </tr>
  <tr>
  <td colspan="2" align="center"><input type="hidden" name="linkid" value="<?php echo $linkid; ?>"><input type="submit" name="submit" value="Edit Link" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=links" style="color: #003366;">< Back</a>