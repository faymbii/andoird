<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=addgame" style="color: #003366;">Add New File</a> | <a href="index.php?action=grabfile" style="color: #003366;">Grab File</a> | <a href="index.php?action=uploadfile" style="color: #003366;">Upload File</a><?php if ($commentapproval == '1' || $commentapproval == '2') { ?> | <a href="index.php?action=approvecomments" style="color: #003366;">Approve Comments</a><?php } ?></center><br />
<form action="index.php?action=gograb" method="POST" name="form">
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if (!is_writable('../files/'.$filesdir.'/')) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="3"><font color="red"><b>Files directory (../files/<?php echo $filesdir; ?>/) isn't writable. Please try to CHMOD it to 777!</b></font></td>
  </tr>
<?php } ?>
<?php if (!is_writable('../files/image/')) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="3"><font color="red"><b>Images directory (../files/image/) isn't writable. Please try to CHMOD it to 777!</b></font></td>
  </tr>
<?php } ?>
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="2"><font color="red"><b>Couldn't grab!</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="20%" valign="top">File:</td><td width="80%"><input type="text" name="grabfile" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top">Image:</td><td width="80%"><input type="text" name="grabimage" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td colspan="2" align="center"><input type="submit" name="submit" value="Grab" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=games" style="color: #003366;">< Back</a>