<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center>
<p dir="rtl"><a href="index.php?action=addcategory">&#1575;&#1590;&#1601; &#1578;&#1589;&#1606;&#1610;&#1601; &#1580;&#1583;&#1610;&#1583;</a></p>
</center><br />
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="6">
	<p dir="rtl"><font color="red"><b>&#1578;&#1589;&#1606;&#1610;&#1601; &#1580;&#1583;&#1610;&#1583; &#1575;&#1590;&#1610;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581; !</b></font></td>
  </tr>
<?php } elseif ($error == '2') {?>
  <tr>
  <td align="center" colspan="6">
	<p dir="rtl"><font color="red"><b>&#1578;&#1589;&#1606;&#1610;&#1601; &#1581;&#1584;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581; !</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td align="center">
	<p dir="rtl"><b>&#1575;&#1587;&#1605; &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601;</b></td><td align="center">
	<p dir="rtl"><b>&#1578;&#1589;&#1606;&#1610;&#1601; &#1601;&#1585;&#1593;&#1610;</b></td><td align="center">
	<p dir="rtl"><b>&#1605;&#1606; &#1610;&#1588;&#1575;&#1607;&#1583; &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601;</b></td><td align="center">
	<p dir="rtl"><b>&#1575;&#1604;&#1608;&#1590;&#1593;</b></td><td align="center">
	<p dir="rtl"><b>Order</b></td><td>
	<p dir="rtl"></td>
  </tr>
<?php
$category_sql = mysql_query("SELECT name, catid FROM categories");
    $catparentName["0"] = "&#1576;&#1583;&#1608;&#1606;";
while($category_row = mysql_fetch_array($category_sql)) {
    $catparentId = $category_row['catid'];
	$catparentName[$catparentId] = $category_row['name'];
}
$catStatusName = array(
	"1" => "<font color=\"green\">&#1605;&#1601;&#1593;&#1604;</font>",
	"0" => "<font color=\"red\">&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</font>"
);
$catnr = "0";
$cat_result = mysql_query("SELECT * FROM categories ORDER BY catorder, name");
if (mysql_num_rows($cat_result)) {
while($row = mysql_fetch_array($cat_result)) {
	    $catid = $row['catid'];
        $catname = $row['name'];
        $catorder = $row['catorder'];
        $catpermissions = $row['permissions'];
	    if ($catpermissions == '2') {
		    $catpermissions = "&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;";
	    } else {
		    $catpermissions = "&#1575;&#1610; &#1588;&#1582;&#1589;";
	    }
	    $catstatus = $row['status'];
	    $catparent = $row['parentcategory'];
	    if ($catnr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $catnr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $catnr = "0";
        }
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
  <td><?php echo $catname; ?></td><td align="center"><?php echo $catparentName[$catparent]; ?></td><td align="center"><?php echo $catpermissions; ?></td><td align="center"><?php echo $catStatusName[$catstatus]; ?></td><td align="center"><?php echo $catorder; ?></td><td align="center">
	<p dir="rtl">
	<a href="index.php?action=editcategory&catid=<?php echo $catid; ?>">&#1578;&#1593;&#1583;&#1610;&#1604;</a> 
	-
	<a onclick="return confirmDelete()" href="index.php?action=deletecategory&catid=<?php echo $catid; ?>">
	&#1581;&#1584;&#1601;</a></td>
  </tr>
<?php
}
}
?>
</table>