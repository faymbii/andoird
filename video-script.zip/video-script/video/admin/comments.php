<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT title FROM files WHERE fileid = '$fileid' LIMIT 1");
$row = mysql_fetch_array($sql);
$filetitle = $row['title'];
?>
<p align="center">
<a style="color: #003366; text-decoration: underline" href="index.php?action=addgame">
&#1575;&#1590;&#1601; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> |
<a style="color: #003366; text-decoration: underline" href="index.php?action=grabfile">
Grab File</a> |
<a style="color: #003366; text-decoration: underline" href="index.php?action=uploadfile">
&#1585;&#1601;&#1593; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> |
<a style="color: #003366; text-decoration: underline" href="index.php?action=approvecomments">
Approve Comments</a><br>
<br />
</p>
<center><b><?php echo $filetitle; ?></b></center>
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="4"><font color="#FF0000"><b>&#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602; &#1581;&#1584;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581;</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td align="center"><b>&#1575;&#1604;&#1593;&#1590;&#1608;</b></td><td align="center"><b>IP</b></td><td align="center">
	<b>&#1578;&#1575;&#1585;&#1610;&#1582; &#1575;&#1604;&#1575;&#1590;&#1575;&#1601;&#1577;</b></td><td align="center"><b>&#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1607;</b></td><td></td>
  </tr>
<?php
$commentnr = "0";
$comments_result = mysql_query("SELECT * FROM comments WHERE fileid = '$fileid' && status = '1' ORDER BY commentid");
if (mysql_num_rows($comments_result)) {
while($row = mysql_fetch_array($comments_result)) {
	    $commentid = $row['commentid'];
        $cuserid = $row['userid'];
        $comment = nl2br(($row['comment']));
        $comment = bbcode($comment);
        $cdate = $row['date'];
        $cuserip = $row['ip'];
		if ($cuserid == '0') {
		  $cusername = "Guest";
		} else {
		  $sql = mysql_query("SELECT username FROM users WHERE userid = '$cuserid' LIMIT 1");
		  $row2 = mysql_fetch_array($sql);
		  $cusername = ($row2[username]);
		  $cusername = "<a href=\"".profileurl($cuserid,$cusername)."\" style=\"color: #003366;\">".$cusername."</a>";
		}
        if ($commentnr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $commentnr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $commentnr = "0";
        }
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
  <td align="center" valign="top"><?php echo $cusername; ?></td><td align="center" valign="top"><?php echo $cuserip; ?></td><td align="center" valign="top"><?php echo $cdate; ?></td><td valign="top"><?php echo $comment; ?></td><td align="center" valign="top">
	<a onclick="return confirmDelete()" style="color: #003366;" href="index.php?action=deletecomment&cid=<?php echo $commentid; ?>&fid=<?php echo $fileid; ?>">
	&#1581;&#1584;&#1601;</a></td>
  </tr>
<?php
}
}
?>
</table>
<br />
<a style="color: #003366;" href="index.php?action=games">&lt; &#1585;&#1580;&#1608;&#1593;</a>