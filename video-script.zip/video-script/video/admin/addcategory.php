<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}

?>
<center><a style="color: #003366;" href="index.php?action=addcategory">&#1575;&#1590;&#1601; &#1578;&#1589;&#1606;&#1610;&#1601; 
&#1580;&#1583;&#1610;&#1583;</a></center><br />
<form action="index.php?action=addnewcategory" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial; ">
  <tr>
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1575;&#1604;&#1575;&#1587;&#1605; :</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><input type="text" name="catname" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1575;&#1604;&#1608;&#1589;&#1601; :</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><textarea name="catdescription" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"></textarea></td>
  </tr>
  <tr>
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1577; :</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><textarea name="catkeywords" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"></textarea></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1605;&#1606; &#1610;&#1588;&#1575;&#1607;&#1583; &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601; :</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><select name="catpermissions"><option value="1">
	&#1575;&#1604;&#1580;&#1605;&#1610;&#1593;</option><option value="2">&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</option></select></td>
  </tr>
  <tr>
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1575;&#1604;&#1608;&#1590;&#1593; :</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><select name="catstatus"><option value="1">&#1605;&#1601;&#1593;&#1604;</option><option value="0">
	&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1594;&#1610;&#1585; :</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><input type="text" name="catorder" style="width: 50px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="144" valign="top" align="right" dir="rtl">
	<p align="right" dir="rtl">&#1578;&#1589;&#1606;&#1610;&#1601; &#1601;&#1585;&#1593;&#1610;</td>
  <td width="242" align="right" dir="rtl">
	<p align="right" dir="rtl"><select name="parentcategory"><option value="0">
	None</option><?php $category_result = mysql_query("SELECT name,catid FROM categories WHERE  parentcategory = '0' ORDER BY name"); if (mysql_num_rows($category_result)) { while($cat_row = mysql_fetch_array($category_result)) { echo "<option value=\"".$cat_row['catid']."\">".$cat_row['name']."</option>"; } }?></select></td>
  </tr>
  <tr>
  <td colspan="2" align="center">
	<p align="right" dir="rtl">
	<input type="submit" name="submit" value="&#1571;&#1590;&#1601; &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601; &#1575;&#1604;&#1575;&#1606;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=categories" style="color: #003366;">< &#1585;&#1580;&#1608;&#1593;</a>