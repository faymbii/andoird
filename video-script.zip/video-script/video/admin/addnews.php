<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a style="color: #003366;" href="index.php?action=addnews">&#1575;&#1590;&#1601; &#1582;&#1576;&#1585; &#1580;&#1583;&#1610;&#1583;</a></center><br />
<form action="index.php?action=addnewnews" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial;" width="100%">
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;&#1575;&#1604;&#1593;&#1606;&#1608;&#1575;&#1606; :</td>
  <td width="553" dir="rtl"><input type="text" name="newstitle" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;&#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1607; :</td>
  <td width="553" dir="rtl"><textarea name="newsmessage" rows="5" cols="50" style="margin: 2px; border: 1px solid #4A708B;"></textarea></td>
  </tr>
  <tr>
  <td colspan="2" align="center">
	<input type="submit" name="submit" value="&#1575;&#1590;&#1601; &#1575;&#1604;&#1582;&#1576;&#1585;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a style="color: #003366;" href="index.php?action=news">&lt; &#1585;&#1580;&#1608;&#1593;</a>