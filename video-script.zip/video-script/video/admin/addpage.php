<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=addnews">&#1575;&#1590;&#1575;&#1601;&#1577; &#1589;&#1601;&#1581;&#1607; &#1580;&#1583;&#1610;&#1583;&#1607;</a></center><br />
<form action="index.php?action=addnewpage" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial; ">
    <tr>
  <td width="236" valign="top" align="right" dir="rtl">&nbsp;&#1575;&#1604;&#1593;&#1606;&#1608;&#1575;&#1606; :</td>
  <td width="216" align="right" dir="rtl"><input type="text" name="pageTitle" value="<?php echo $pageTitle; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="236" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1607; :</td>
  <td width="216" align="right" dir="rtl"><input type="text" name="pageKeywords" value="<?php echo $pageKeywords; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="236" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1608;&#1589;&#1601; :</td>
  <td width="216" align="right" dir="rtl"><input type="text" name="pageDescription" value="<?php echo $pageDescription; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE" title="You can use this link to place a link to this page on your site.">
  <td width="236" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1605;&#1581;&#1578;&#1608;&#1609; :</td>
  <td width="216" align="right" dir="rtl"><textarea name="pageContent" rows="10" cols="50" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $pageContent; ?></textarea></td>
  </tr>
  <tr>
  <td colspan="2" align="center">
	<input type="submit" name="submit" value="&#1575;&#1590;&#1601; &#1575;&#1604;&#1589;&#1601;&#1581;&#1607;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=pages">&lt; &#1585;&#1580;&#1608;&#1593;</a>