<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT * FROM users WHERE userid = '$euserid'");
	
	if (mysql_num_rows($sql)) {
	$row = mysql_fetch_array($sql);
	
	$eusername = htmlentities($row['username']);
	$euseremail = htmlentities($row['email']);
	$euserlocation = htmlentities($row['location']);
	$euserwebsite = htmlentities($row['website']);
	$eusergender = $row['gender'];
	$eusergroup = $row['usergroup'];
	$euseravatar = htmlentities($row['avatar']);
	$eavataruploaded = $row['avatar_uploaded'];
	$euserstatus = $row['status'];
	
	if (empty($euseravatar)) {
		$displayAvatar = $siteurl."/images/noavatar.gif";
		$avatarWidth = "100";
		$avatarHeight = "100";
	} else {
		if ($eavataruploaded == '1') {
		    $displayAvatar = $siteurl."/images/avatars/".$euseravatar;
		}
		$avatarSize = @getimagesize($displayAvatar);
		$avatarWidth = $avatarSize[0];
		$avatarHeight = $avatarSize[1];
		if ($avatarWidth > 150) {
		    $change = ($avatarWidth / 150);
			$avatarWidth = 150;
			$avatarHeight = ($avatarHeight / $change);    
		}
		if ($avatarHeight > 150) {
		  $change = ($avatarHeight / 150);
		  $avatarHeight = 150;
		  $avatarWidth = ($avatarWidth / $change);    
		}
	}
    } else {
	    header ("Location: index.php?action=users");
	    exit();
    }
?>
<center><a href="index.php?action=adduser">&#1575;&#1590;&#1601; &#1605;&#1587;&#1578;&#1582;&#1583;&#1605; &#1580;&#1583;&#1610;&#1583;</a></center><br />
<form action="index.php?action=updateuser" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial; " width="100%">
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="2">
	<p dir="rtl"><font color="red"><b>&#1578;&#1605; &#1578;&#1581;&#1583;&#1610;&#1579; &#1576;&#1610;&#1575;&#1606;&#1575;&#1578; &#1575;&#1604;&#1593;&#1590;&#1608; &#1576;&#1606;&#1580;&#1575;&#1581; </b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="185" valign="top" dir="rtl">&#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1587;&#1578;&#1582;&#1583;&#1605; : </td>
	<td width="505" align="right" dir="rtl"><input type="text" name="eusername" value="<?php echo $eusername; ?>" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl">&#1575;&#1604;&#1576;&#1585;&#1610;&#1583; &#1575;&#1604;&#1575;&#1604;&#1603;&#1578;&#1585;&#1608;&#1606;&#1610; :</td>
	<td width="505" align="right" dir="rtl"><input type="text" name="euseremail" value="<?php echo $euseremail; ?>" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl">&#1575;&#1604;&#1576;&#1604;&#1583; :</td>
	<td width="505" align="right" dir="rtl"><input type="text" name="euserlocation" value="<?php echo $euserlocation; ?>" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl">&#1575;&#1604;&#1589;&#1601;&#1581;&#1607; &#1575;&#1604;&#1588;&#1582;&#1589;&#1610;&#1577; :</td>
	<td width="505" align="right" dir="rtl"><input type="text" name="euserwebsite" value="<?php echo $euserwebsite; ?>" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl">&#1575;&#1604;&#1580;&#1606;&#1587; :</td>
	<td width="505" align="right" dir="rtl"><select name="eusergender"><option value="1" <?php if ($eusergender == '1') { echo "selected"; } ?>>&#1584;&#1603;&#1585;</option><option value="2" <?php if ($eusergender == '2') { echo "selected"; } ?>>&#1575;&#1606;&#1579;&#1609;</option><option value="0" <?php if ($eusergender == '0') { echo "selected"; } ?>>Unspecified</option></select></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl">&#1575;&#1604;&#1605;&#1580;&#1605;&#1608;&#1593;&#1577; :</td>
	<td width="505" align="right" dir="rtl"><select name="eusergroup"><option value="1" <?php if ($eusergroup == '1') { echo "selected"; } ?>>&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</option><option value="2" <?php if ($eusergroup == '2') { echo "selected"; } ?>>&#1575;&#1604;&#1575;&#1583;&#1575;&#1585;&#1577;</option></select></td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl">&#1589;&#1608;&#1585;&#1577; &#1588;&#1582;&#1589;&#1610;&#1577; :</td>
	<td width="505" align="right" dir="rtl"><img src="<?php echo $displayAvatar; ?>" border="0" title="<?php echo $eusername; ?>'s Avatar" alt="<?php echo $eusername; ?>'s Avatar" width="<?php echo $avatarWidth; ?>" height="<?php echo $avatarHeight; ?>" /><br /><input type="text" name="euseravatar" value="<?php echo $euseravatar; ?>" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"><?php if ($eavataruploaded == '1') { echo "<br /><a href=\"index.php?action=edituser&userid=1&a=deleteavatar\">Delete</a>"; } ?></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl">&#1575;&#1604;&#1581;&#1575;&#1604;&#1577; :</td>
	<td width="505" align="right" dir="rtl"><select name="euserstatus"><option value="1" <?php if ($euserstatus == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="2" <?php if ($euserstatus == '2') { echo "selected"; } ?>>&#1591;&#1585;&#1583;</option><option value="0" <?php if ($euserstatus == '0') { echo "selected"; } ?>>&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  </tr>
  <tr>
  <td colspan="2" align="center"><input type="hidden" name="euserid" value="<?php echo $euserid; ?>">
	<input type="submit" name="submit" value="&#1581;&#1601;&#1592; &#1575;&#1604;&#1578;&#1593;&#1583;&#1610;&#1604;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=users">< &#1585;&#1580;&#1608;&#1593;</a>