<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a style="color: #003366;" href="index.php?action=addlink">&#1575;&#1590;&#1601; &#1585;&#1575;&#1576;&#1591; &#1580;&#1583;&#1610;&#1583;</a></center><br />
<form action="index.php?action=addnewlink" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial;" width="100%">
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&#1593;&#1606;&#1608;&#1575;&#1606; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
	<td width="517" dir="rtl" align="right"><input type="text" name="linkname" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl" align="right">&#1585;&#1575;&#1576;&#1591; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
	<td width="517" dir="rtl" align="right"><input type="text" name="linkurl" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&#1608;&#1589;&#1601; &#1604;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
	<td width="517" dir="rtl" align="right"><textarea name="linkdescription" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"></textarea></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl" align="right">&#1575;&#1610;&#1605;&#1610;&#1604; &#1589;&#1575;&#1581;&#1576; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
	<td width="517" dir="rtl" align="right"><input type="text" name="linkemail" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&#1575;&#1604;&#1608;&#1590;&#1593; :</td>
	<td width="517" dir="rtl" align="right"><select name="linkstatus"><option value="1" selected>&#1605;&#1601;&#1593;&#1604;</option><option value="0">&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  </tr>
  <tr>
  <td colspan="2" align="center">
	<input type="submit" name="submit" value="&#1575;&#1590;&#1601; &#1575;&#1604;&#1585;&#1575;&#1576;&#1591;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a style="color: #003366;" href="index.php?action=links">&lt; &#1585;&#1580;&#1608;&#1593;</a>