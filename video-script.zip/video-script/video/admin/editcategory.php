<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT * FROM categories WHERE catid = '$catid'");
	
	if (mysql_num_rows($sql)) {
	    $row = mysql_fetch_array($sql);
		$catName = $row['name'];
		$catDescription = $row['description'];
		$catKeywords = $row['keywords'];
		$catPermissions = $row['permissions'];
		$catStatus = $row['status'];
		$catOrder = $row['catorder'];
		$parentCategory = $row['parentcategory'];
		if ($parentCategory == '0') {
		    $parentCategoryname = "None";
		} else {
		    $category_sql = mysql_query("SELECT name FROM categories WHERE catid = '$parentCategory'");
			$category_row = mysql_fetch_array($category_sql);
			$parentCategoryname = $category_row['name'];
		}
	} else {
	    header ("Location: index.php?action=categories");
	    exit();
    }
?>
<center><a style="color: #003366;" href="index.php?action=addcategory">&#1575;&#1590;&#1601; &#1578;&#1589;&#1606;&#1610;&#1601; 
&#1580;&#1583;&#1610;&#1583;</a></center><br />
<form action="index.php?action=updatecategory" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial;">
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="3"><font color="#FF0000"><b>&#1578;&#1605; &#1578;&#1593;&#1583;&#1610;&#1604; 
	&#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581;</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&#1575;&#1587;&#1605; &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601; :</td>
  <td width="561" align="right"><input type="text" name="catname" value="<?php echo $catName; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl" align="right">&#1575;&#1604;&#1608;&#1589;&#1601; :</td>
  <td width="561" align="right"><textarea name="catdescription" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $catDescription; ?></textarea></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">
	<p dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1577; :</td>
  <td width="561" align="right"><textarea name="catkeywords" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $catKeywords; ?></textarea></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl" align="right">&#1605;&#1606; &#1610;&#1588;&#1575;&#1607;&#1583;&#1607; :</td>
  <td width="561" align="right"><select name="catpermissions"><option value="1" <?php if ($catPermissions == '1') { echo "selected"; } ?>>&#1575;&#1610; &#1588;&#1582;&#1589;</option><option value="2" <?php if ($catPermissions == '2') { echo "selected"; } ?>>&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</option></select></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&#1575;&#1604;&#1581;&#1575;&#1604;&#1577; : </td>
  <td width="561" align="right"><select name="catstatus"><option value="1" <?php if ($catStatus == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($catStatus == '0') { echo "selected"; } ?>>&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" dir="rtl" align="right">Order:</td>
  <td width="561" align="right"><input type="text" name="catorder" value="<?php echo $catOrder; ?>" style="width: 50px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;&#1578;&#1589;&#1606;&#1610;&#1601; &#1601;&#1585;&#1593;&#1610;:</td>
  <td width="561" align="right"><select name="parentcategory"><option value="<?php echo $parentCategory; ?>" selected><?php echo $parentCategoryname; ?></option><option value="0">None</option><?php $category_result = mysql_query("SELECT name,catid FROM categories WHERE parentcategory = '0' ORDER BY name"); if (mysql_num_rows($category_result)) { while($cat_row = mysql_fetch_array($category_result)) { if ($cat_row['catid'] != $catid) { echo "<option value=\"".$cat_row['catid']."\">".$cat_row['name']."</option>"; }} }?></select></td>
  <td width="185" valign="top" dir="rtl" align="right">&nbsp;</td>
  </tr>
  <tr>
  <td colspan="3" align="center"><input type="hidden" name="catid" value="<?php echo $catid; ?>">
	<input type="submit" name="submit" value="&#1581;&#1601;&#1592; &#1575;&#1604;&#1578;&#1593;&#1583;&#1610;&#1604;&#1575;&#1578;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a style="color: #003366;" href="index.php?action=categories">&lt; &#1585;&#1580;&#1608;&#1593;</a>