<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT * FROM news WHERE newsid = '$newsid'");
	
	if (mysql_num_rows($sql)) {
	$row = mysql_fetch_array($sql);
	
	$newsTitle = $row['title'];
	$newsMessage = $row['message'];

    } else {
	    header ("Location: index.php?action=news");
	    exit();
    }
?>
<center><a href="index.php?action=addnews" style="color: #003366;">Add News</a></center><br />
<form action="index.php?action=updatenews" method="POST" name="form">
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="2"><font color="red"><b>News updated!</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="20%" valign="top">Title:</td><td width="80%"><input type="text" name="newstitle" value="<?php echo $newsTitle; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top">Message:</td><td width="80%"><textarea name="newsmessage" rows="5" cols="50" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $newsMessage; ?></textarea></td>
  </tr>
  <tr>
  <td colspan="2" align="center"><input type="hidden" name="newsid" value="<?php echo $newsid; ?>"><input type="submit" name="submit" value="Edit News" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=news" style="color: #003366;">< Back</a>