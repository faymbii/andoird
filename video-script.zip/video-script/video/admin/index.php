<?php

session_start();

include ("../includes/adminconfig.php");

if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
        header ("Location: login.php");
        exit();
}

$action = $_GET[action];
if ($action == 'categories') {
        $error = $_GET[e];
        $includefile = "categories.php";
} elseif ($action == 'games') {
        $error = $_GET[e];
        $order = $_GET[order];
        switch($order) {
    case 1:
        $orderby = "title";
        break;
    case 2:
        $orderby = "category, title";
        break;
    case 3:
        $orderby = "filetype, title";
        break;
    case 4:
        $orderby = "fileid";
        break;
    case 5:
        $orderby = "status, title";
        break;
    default:
        $orderby = "title";
        }
        $page = $_GET[page];
        if (empty($page) || !is_numeric($page)) {
            $page = "1";
        }
        $includefile = "games.php";
} elseif ($action == 'links') {
        $error = $_GET[e];
        $includefile = "links.php";
} elseif ($action == 'addgame') {
        $gfile = $_GET[gfile];
        $gimage = $_GET[gimage];
        $includefile = "addgame.php";
} elseif ($action == 'addnewgame') {
        $gametitle = $_POST[name];
        $gamedescription = $_POST[description];
        $gamekeywords = $_POST[keywords];
        $gamecategory = $_POST[category];
        $gamewidth = $_POST[width];
        $gameheight = $_POST[height];
        $gamefiletype = $_POST[gamefiletype];
        $gamefile = $_POST[gamefile];
        $gamefilelocation = $_POST[filelocation];
        $gameimage = $_POST[gameimage];
        $gameimagelocation = $_POST[imagelocation];
        $gamefilestatus = $_POST[filestatus];
        $gamecustomcode = $_POST[customcode];
        // Check if game is already in the database
    $check_gamename = mysql_query("SELECT count(fileid) AS filenamecount FROM files WHERE title = '$gametitle'");
    $get_check_gamename = mysql_fetch_array($check_gamename);
    $gamenamecount = $get_check_gamename['filenamecount'];
    if ($gamenamecount > '0') {
            header ("Location: index.php?action=games&e=3");
        exit();
    }
         if (empty($gamewidth) && $gamefilelocation != '3' && $gamefiletype != '5' || empty($gameheight) && $gamefilelocation != '3' && $gamefiletype != '5') {
            // Get file size
                if ($gamefilelocation == '2') {
                    $size = getimagesize($gamefile);
                } else {
                    $size = getimagesize($siteurl."/files/".$filesdir."/".$gamefile);
                }
                $gamewidth = $size[0];
                $gameheight = $size[1];
    }
    // Resize files that are too big
    if ($autoresize == '1') {
            if ($gamewidth > $maxfilewidth) {
                    $change = ($gamewidth / $maxfilewidth);
                        $gamewidth = $maxfilewidth;
                        $gameheight = ($gameheight / $change);
                }
                if ($gameheight > $maxfileheight) {
                    $change = ($gameheight / $maxfileheight);
                        $gameheight = $maxfileheight;
                        $gamewidth = ($gamewidth / $change);
                }
    }
        if (strlen($gametitle)) {
                // Add game to MySQL database
                $dateadded = date('Y-m-d');
                $addgame = mysql_query("INSERT INTO files SET  title = '$gametitle', description = '$gamedescription', keywords = '$gamekeywords', category = '$gamecategory', width = '$gamewidth', height = '$gameheight', filetype = '$gamefiletype', file = '$gamefile', filelocation = '$gamefilelocation', customcode ='$gamecustomcode', icon = '$gameimage', iconlocation = '$gameimagelocation', status = '$gamefilestatus', dateadded = '$dateadded'");
        }
        // Redirect to games page
        header ("Location: index.php?action=games&e=1");
        exit();
} elseif ($action == 'editgame') {
        $gameid = $_GET[gameid];
        $editgameAction = $_GET[a];
        $error = $_GET[e];
        if ($error == '1') {
                $error = "File updated!";
        } else {
                $error = NULL;
        }
        if ($editgameAction == 'deletefile') {
                $sql = mysql_query("SELECT file, filelocation FROM files WHERE fileid = '$gameid'");
                $row = mysql_fetch_array($sql);
                $file = $row['file'];
                $filelocation = $row['filelocation'];
                if ($filelocation == '1') {
                        @unlink("../files/".$filesdir."/".$file);
                        $error = "File deleted!";
                }
        } elseif ($editgameAction == 'deleteimage') {
                $sql = mysql_query("SELECT icon, iconlocation FROM files WHERE fileid = '$gameid'");
                $row = mysql_fetch_array($sql);
                $image = $row['icon'];
                $imagelocation = $row['iconlocation'];
                if ($imagelocation == '1') {
                        @unlink("../files/image/".$image);
                        $error = "Image deleted!";
                }
        }
        $includefile = "editgame.php";
} elseif ($action == 'updategame') {
        $gameid = $_POST[gameid];
        $gametitle = $_POST[name];
        $gamedescription = $_POST[description];
        $gamekeywords = $_POST[keywords];
        $gamecategory = $_POST[category];
        $gamewidth = $_POST[width];
        $gameheight = $_POST[height];
        $gamefiletype = $_POST[gamefiletype];
        $gamefile = $_POST[gamefile];
        $gamefilelocation = $_POST[filelocation];
        $gameimage = $_POST[gameimage];
        $gameimagelocation = $_POST[imagelocation];
        $gamefilestatus = $_POST[filestatus];
        $gamecustomcode = $_POST[customcode];
        if (isset($gameid)) {
                $update = mysql_query("UPDATE files SET title = '$gametitle', description = '$gamedescription', keywords = '$gamekeywords', category = '$gamecategory', width = '$gamewidth', height = '$gameheight', filetype = '$gamefiletype', file = '$gamefile', filelocation = '$gamefilelocation', customcode ='$gamecustomcode', icon = '$gameimage', iconlocation = '$gameimagelocation', status = '$gamefilestatus' WHERE fileid = '$gameid'");
        }
        header ("Location: index.php?action=editgame&gameid=".$gameid."&e=1");
        exit();
} elseif ($action == 'deletegame') {
        $gameid = $_GET[gameid];
        if (strlen($gameid)) {
                $delete = mysql_query("DELETE FROM files WHERE fileid = '$gameid'");
        }
        header ("Location: index.php?action=games&e=2");
        exit();
} elseif ($action == 'comments') {
        $fileid = $_GET[fid];
        $error = $_GET[e];
        $includefile = "comments.php";
} elseif ($action == 'deletecomment') {
        $commentid = $_GET[cid];
        $fileid = $_GET[fid];
        if (strlen($commentid)) {
                $delete = mysql_query("DELETE FROM comments WHERE commentid = '$commentid'");
        }
        header ("Location: index.php?action=comments&fid=".$fileid."&e=1");
        exit();
} elseif ($action == 'approvecomments') {
    $approveId = $_GET[approve];
    $deleteId = $_GET[delete];
        $includefile = "approvecomments.php";
        if (strlen($approveId) && is_numeric($approveId)) {
            $update = mysql_query("UPDATE comments SET status = '1' WHERE commentid = '$approveId'");
            $error = "2";
        } elseif (strlen($deleteId) && is_numeric($deleteId)) {
            $delete = mysql_query("DELETE FROM comments WHERE commentid = '$deleteId'");
            $error = "1";
        }
} elseif ($action == 'addcategory') {
        $includefile = "addcategory.php";
} elseif ($action == 'addnewcategory') {
        $catname = $_POST[catname];
        $catdescription = $_POST[catdescription];
        $catkeywords = $_POST[catkeywords];
        $catpermissions = $_POST[catpermissions];
        $catstatus = $_POST[catstatus];
        $catorder = $_POST[catorder];
        $parentcategory = $_POST[parentcategory];

        if (strlen($catname)) {
                // Add category to MySQL database
                $add = mysql_query("INSERT INTO categories SET name = '$catname', description = '$catdescription', keywords = '$catkeywords', permissions = '$catpermissions', status = '$catstatus', catorder = '$catorder', parentcategory = '$parentcategory'");
        }
        // Redirect to games page
        header ("Location: index.php?action=categories&e=1");
        exit();
} elseif ($action == 'editcategory') {
        $catid = $_GET[catid];
        $error = $_GET[e];
        $includefile = "editcategory.php";
} elseif ($action == 'updatecategory') {
        $catid = $_POST[catid];
        $catname = $_POST[catname];
        $catdescription = $_POST[catdescription];
        $catkeywords = $_POST[catkeywords];
        $catpermissions = $_POST[catpermissions];
        $catstatus = $_POST[catstatus];
        $catorder = $_POST[catorder];
        $parentcategory = $_POST[parentcategory];
        if (strlen($catid)) {
                $update = mysql_query("UPDATE categories SET name = '$catname', description = '$catdescription', keywords = '$catkeywords', permissions = '$catpermissions', status = '$catstatus', catorder = '$catorder', parentcategory = '$parentcategory' WHERE catid = '$catid'");
        }
        header ("Location: index.php?action=editcategory&catid=".$catid."&e=1");
        exit();
} elseif ($action == 'deletecategory') {
        $catid = $_GET[catid];
        if (strlen($catid)) {
                $delete = mysql_query("DELETE FROM categories WHERE catid = '$catid'");
        }
        header ("Location: index.php?action=categories&e=2");
        exit();
} elseif ($action == 'deletelink') {
        $linkid = $_GET[linkid];
        if (strlen($linkid)) {
                $delete = mysql_query("DELETE FROM links WHERE linkid = '$linkid'");
        }
        header ("Location: index.php?action=links&e=2");
        exit();
} elseif ($action == 'editlink') {
        $linkid = $_GET[linkid];
        $error = $_GET[e];
        $includefile = "editlink.php";
} elseif ($action == 'updatelink') {
        $linkid = $_POST[linkid];
        $linkname = $_POST[linkname];
        $linkurl = $_POST[linkurl];
        $linkdescription = $_POST[linkdescription];
        $linkemail = $_POST[linkemail];
        $linkstatus = $_POST[linkstatus];
        if (strlen($linkid)) {
                $update = mysql_query("UPDATE links SET linkurl = '$linkurl', description = '$linkdescription', name = '$linkname', email = '$linkemail', status = '$linkstatus' WHERE linkid = '$linkid'");
        }
        header ("Location: index.php?action=editlink&linkid=".$linkid."&e=1");
        exit();
} elseif ($action == 'addlink') {
        $includefile = "addlink.php";
} elseif ($action == 'addnewlink') {
        $linkname = $_POST[linkname];
        $linkurl = $_POST[linkurl];
        $linkdescription = $_POST[linkdescription];
        $linkemail = $_POST[linkemail];
        $linkstatus = $_POST[linkstatus];
        if (strlen($linkname)) {
                $add = mysql_query("INSERT INTO links SET linkurl = '$linkurl', description = '$linkdescription', name = '$linkname', email = '$linkemail', status = '$linkstatus'");
        }
        header ("Location: index.php?action=links&e=1");
        exit();
} elseif ($action == 'users') {
        $order = $_GET[order];
        switch($order) {
    case 1:
        $orderby = "username";
        break;
    case 2:
        $orderby = "status, username";
        break;
    case 3:
        $orderby = "usergroup, username";
        break;
    default:
        $orderby = "username";
        }
        $page = $_GET[page];
        if (empty($page) || !is_numeric($page)) {
            $page = "1";
        }
        $error = $_GET[e];
        $includefile = "users.php";
} elseif ($action == 'deleteuser') {
        $duserid = $_GET[userid];
        if (strlen($duserid)) {
                $delete = mysql_query("DELETE FROM users WHERE userid = '$duserid'");
        }
        header ("Location: index.php?action=users&e=2");
        exit();
} elseif ($action == 'edituser') {
        $euserid = $_GET[userid];
        $error = $_GET[e];
        $edituserAction = $_GET[a];
        if ($edituserAction == 'deleteavatar') {
                $sql = mysql_query("SELECT avatar, avatar_uploaded FROM users WHERE userid = '$euserid'");
                $row = mysql_fetch_array($sql);
                $euseravatar = ($row['avatar']);
                $eavataruploaded = $row['avatar_uploaded'];
                if ($eavataruploaded == '1') {
                        @unlink("../images/avatars/".$euseravatar);
                        $update_avatar = mysql_query("UPDATE users SET avatar = '', avatar_uploaded = '0' WHERE userid = '$euserid'");
                }
        }
        $includefile = "edituser.php";
} elseif ($action == 'updateuser') {
        $euserid = $_POST[euserid];
        $eusername = $_POST[eusername];
        $euseremail = $_POST[euseremail];
        $euserlocation = $_POST[euserlocation];
        $euserwebsite = $_POST[euserwebsite];
        $eusergender = $_POST[eusergender];
        $eusergroup = $_POST[eusergroup];
        $euseravatar = $_POST[euseravatar];
        $euserstatus = $_POST[euserstatus];
        if (strlen($euserid)) {
                $update = mysql_query("UPDATE users SET username = '$eusername', email = '$euseremail', location = '$euserlocation', website = '$euserwebsite', gender = '$eusergender', usergroup = '$eusergroup', avatar = '$euseravatar', status = '$euserstatus' WHERE userid = '$euserid'");
        }
        header ("Location: index.php?action=edituser&userid=".$euserid."&e=1");
        exit();
} elseif ($action == 'adduser') {
        $error = $_GET[e];
        $includefile = "adduser.php";
} elseif ($action == 'addnewuser') {
        $eusername = $_POST[eusername];
        $euserpassword = $_POST[euserpassword];
        $euseremail = $_POST[euseremail];
        $euserlocation = $_POST[euserlocation];
        $euserwebsite = $_POST[euserwebsite];
        $eusergender = $_POST[eusergender];
        $eusergroup = $_POST[eusergroup];
        $euseravatar = $_POST[euseravatar];
        $euserstatus = $_POST[euserstatus];
        if (strlen($eusername) && strlen($euserpassword)) {
                // Check if user is already in the database
        $check_username = mysql_query("SELECT count(userid) AS usernamecount FROM users WHERE username = '$eusername'");
        $get_check_username = mysql_fetch_array($check_username);
        $usernamecount = $get_check_username['usernamecount'];
        if ($usernamecount > '0') {
                header ("Location: index.php?action=adduser&e=1");
                exit();
            }
                $euserpassword = md5($euserpassword);
                $add = mysql_query("INSERT INTO users SET username = '$eusername', email = '$euseremail', location = '$euserlocation', website = '$euserwebsite', gender = '$eusergender', usergroup = '$eusergroup', avatar = '$euseravatar', status = '$euserstatus', password = '$euserpassword', joined = now()");
                header ("Location: index.php?action=users&e=1");
                exit();
        }
        header ("Location: index.php?action=adduser");
        exit();
} elseif ($action == 'news') {
        $error = $_GET[e];
        $includefile = "news.php";
} elseif ($action == 'deletenews') {
        $newsid = $_GET[newsid];
        if (strlen($newsid)) {
                $delete = mysql_query("DELETE FROM news WHERE newsid = '$newsid'");
        }
        header ("Location: index.php?action=news&e=2");
        exit();
} elseif ($action == 'editnews') {
        $newsid = $_GET[newsid];
        $error = $_GET[e];
        $includefile = "editnews.php";
} elseif ($action == 'updatenews') {
        $newstitle = $_POST[newstitle];
        $newsmessage = $_POST[newsmessage];
        $newsid = $_POST[newsid];
        if (strlen($newsid)) {
                $update = mysql_query("UPDATE news SET title = '$newstitle', message = '$newsmessage' WHERE newsid = '$newsid'");
        }
        header ("Location: index.php?action=editnews&newsid=".$newsid."&e=1");
        exit();
} elseif ($action == 'addnews') {
        $includefile = "addnews.php";
} elseif ($action == 'addnewnews') {
        $newstitle = $_POST[newstitle];
        $newsmessage = $_POST[newsmessage];
        if (strlen($newstitle)) {
                $insert = mysql_query("INSERT INTO news SET title = '$newstitle', message = '$newsmessage', date = now()");
        }
        header ("Location: index.php?action=news&e=1");
        exit();
} elseif ($action == 'pages') {
        $error = $_GET[e];
        $includefile = "pages.php";
} elseif ($action == 'editpage') {
        $pageId = $_GET[p];
        $error = NULL;
        if (isset($_POST[submit])) {
                $pageTitle = $_POST[pageTitle];
                $pageKeywords = $_POST[pageKeywords];
                $pageDescription = $_POST[pageDescription];
                $pageContent = $_POST[pageContent];
                $update_page = mysql_query("UPDATE pages SET title = '$pageTitle', content = '$pageContent', keywords = '$pageKeywords', description = '$pageDescription' WHERE pageid = '$pageId'");
                $error = "Page updated!";
        }
        $includefile = "editpage.php";
} elseif ($action == 'addpage') {
        $includefile = "addpage.php";
} elseif ($action == 'addnewpage') {
        $pageTitle = $_POST[pageTitle];
        $pageKeywords = $_POST[pageKeywords];
        $pageDescription = $_POST[pageDescription];
        $pageContent = $_POST[pageContent];
        if (strlen($pageTitle)) {
                $insert_page = mysql_query("INSERT INTO pages SET title = '$pageTitle', content = '$pageContent', keywords = '$pageKeywords', description = '$pageDescription'");
        }
        header ("Location: index.php?action=pages&e=1");
        exit();
} elseif ($action == 'deletepage') {
        $pageId = $_GET[p];
        if (strlen($pageId)) {
                $delete = mysql_query("DELETE FROM pages WHERE pageid = '$pageId'");
        }
        header ("Location: index.php?action=pages&e=2");
        exit();
} elseif ($action == 'grabfile') {
        $error = $_GET[e];
        $includefile = "grabfile.php";
} elseif ($action == 'gograb') {
        $grabfile = $_POST[grabfile];
        $grabimage = $_POST[grabimage];

        if (strlen($grabfile) || strlen($grabimage)) {
        // Get directories info
        $gamedirectory = "../files/".$filesdir."/";
        $imagedirectory = "../files/image/";

        if (strlen($grabfile)) {
                // Get game file name
                $gname = $grabfile;
                while(strstr($gname,"/")){
                        $gname = substr($gname,strpos($gname,"/")+1,999);
                }
                $newgame = $gamedirectory.$gname;

                // If file already exists then change it's name
                if (file_exists($newgame)) {
                        $uniq = substr( md5(uniqid (rand())), 0, 4 );
                        $gname = $uniq."_".$gname;
                        $newgame = $gamedirectory.$gname;
                }
                if (copy($grabfile, $newgame)) {
                        $files = "&gfile=".$gname;
        }
    }
    if (strlen($grabimage)) {
                // Get game file name
                $gimage = $grabimage;
                while(strstr($gimage,"/")){
                        $gimage = substr($gimage,strpos($gimage,"/")+1,999);
                }
                $newimage = $imagedirectory.$gimage;

                // If file already exists then change it's name
                if (file_exists($newimage)) {
                        $uniq = substr( md5(uniqid (rand())), 0, 4 );
                        $gimage = $uniq."_".$gimage;
                        $newimage = $imagedirectory.$gimage;
                }
                if (copy($grabimage, $newimage)) {
                        $images = "&gimage=".$gimage;
        }
    }
    if (strlen($files) || strlen($images)) {
            header ("Location: index.php?action=addgame".$files.$images);
            exit();
    } else {
            header ("Location: index.php?action=grabfile&e=1");
            exit();
    }
    }
        header ("Location: index.php?action=grabfile");
        exit();
} elseif ($action == 'uploadfile') {
        $error = $_GET[e];
        $includefile = "uploadfile.php";
} elseif ($action == 'goupload') {

        if (strlen($_FILES['uploadfile']['name']) || strlen($_FILES['uploadimage']['name'])) {
        // Get directories info
        $gamedirectory = "../files/".$filesdir."/";
        $imagedirectory = "../files/image/";

        if (strlen($_FILES['uploadfile']['name'])) {
                $filename = $_FILES['uploadfile']['name'];
                $uploadfilename = $gamedirectory.$filename;

            if (file_exists($uploadfilename)) {
                        $uniq = substr( md5(uniqid (rand())), 0, 4 );
                        $filename = $uniq."_".$filename;
                        $uploadfilename = $gamedirectory.$filename;
                }

            if (copy($_FILES['uploadfile']['tmp_name'],$uploadfilename)) {
                    $files = "&gfile=".$filename;
            }
    }

    if (strlen($_FILES['uploadimage']['name'])) {
                $imagename = $_FILES['uploadimage']['name'];
                $uploadimagename = $imagedirectory.$imagename;

            if (file_exists($uploadimagename)) {
                        $uniq = substr( md5(uniqid (rand())), 0, 4 );
                        $imagename = $uniq."_".$imagename;
                        $uploadimagename = $imagedirectory.$imagename;
                }

            if (copy($_FILES['uploadimage']['tmp_name'],$uploadimagename)) {
                    $images = "&gimage=".$imagename;
            }
    }

    if (strlen($files) || strlen($images)) {
            header ("Location: index.php?action=addgame".$files.$images);
            exit();
    } else {
            header ("Location: index.php?action=uploadfile&e=1");
            exit();
    }

    }

    header ("Location: index.php?action=uploadfile");
        exit();

} elseif ($action == 'stats') {
        $error = $_GET[e];
        $includefile = "statistics.php";
} elseif ($action == 'massemail') {
        $error = $_GET[e];
        $includefile = "massemail.php";
        $masssubject = $_POST[masssubject];
        $massmessage = $HTTP_POST_VARS[massmessage];
        $deliverymethod = $_POST[deliverymethod];
        if (isset($_POST[preview])) {
            if ($deliverymethod == "1") {
                $previewmessage = nl2br($massmessage);
                } elseif ($deliverymethod == "2") {
                    $previewmessage = nl2br(($massmessage));
                    $previewmessage = bbcode($previewmessage);
                }

        } elseif (isset($_POST[submit])) {
            if (empty($masssubject) || empty($massmessage) || empty($deliverymethod)) {
                    $error = "3";
                } else {
                    if ($deliverymethod == '1') {
                            // Send mass-email
                                $result = mysql_query("SELECT username, email FROM users WHERE status ='1'");
                                while ($row = mysql_fetch_array($result)) {
                                    $massuserName = $row['username'];
                                        $massuserEmail = $row['email'];
                                        $messagetext = str_replace("{username}",$massuserName,$massmessage);
                                        // Send
                                        if (strlen($massuserEmail)) {
                                            if (preg_match(' /[\r\n,;\'"]/ ', $massuserEmail)) {
                                                } else {
                                                    @mail($massuserEmail, $masssubject, $messagetext, "From: " .$sitename. "<".$sitecontactemail.">\nReply-To: ".$sitecontactemail. "\nX-Mailer: PHP.ee/". phpversion());
                                                }
                                        }
                                }
                                unset($masssubject, $massmessage, $deliverymethod);
                                $error = "1";
                        } elseif ($deliverymethod == '2') {
                            // Send mass-pm
                                $massresult = mysql_query("SELECT userid, username FROM users WHERE status = '1' && receiveemails = '1'");
                                while ($row = mysql_fetch_array($massresult)) {
                                    $massuserName = $row['username'];
                                        $massuserUserid = $row['userid'];
                                        $messagetext = str_replace("{username}",$massuserName,$massmessage);
                                        // Send
                                        $result = mysql_query( "INSERT INTO privatemessages SET userid = '$massuserUserid', touser = '$massuserUserid', fromuser = '$userId', folder = '1', subject = '$masssubject', message = '$messagetext', date = now(), status = '0'");
                                        // And make it so that user who gets new PM gets also a pop-up window
                                        $update_pm = mysql_query("UPDATE users SET newpm = '1' WHERE userid = '$massuserUserid'");
                                }
                                unset($masssubject, $massmessage, $deliverymethod);
                                $error = "2";
                        }
                }

        }
} elseif ($action == 'clearstats') {
        $datetoday = date("Y-m-d");
        $delete = mysql_query("DELETE FROM statistics WHERE datetoday != '$datetoday'");
        header ("Location: index.php?action=stats&e=1");
        exit();
} elseif ($action == 'config') {
        $error = $_GET[e];
        $includefile = "configuration.php";
} elseif ($action == 'updateconfig') {
        $sitetitle = $_POST[sitetitle];
        $siteurl = $_POST[siteurl];
        $sitedescription = $_POST[sitedescription];
        $sitekeywords = $_POST[sitekeywords];
        $sitecontactemail = $_POST[sitecontactemail];
        $sitestatus = $_POST[sitestatus];
        $sefriendly = $_POST[sefriendly];
        $template = $_POST[template];
        $filesdir = $_POST[filesdir];
        $memberlogin = $_POST[memberlogin];
        $emailconfirmation = $_POST[emailconfirmation];
        $guestcredits = $_POST[guestcredits];
        $maxguestplays = $_POST[maxguestplays];
        $commentson = $_POST[commentson];
        $commentwho = $_POST[commentwho];
        $maxcomments = $_POST[maxcomments];
        $ratewho = $_POST[ratewho];
        $maxfilewidth = $_POST[maxfilewidth];
        $maxfileheight = $_POST[maxfileheight];
        $filesperpage = $_POST[filesperpage];
        $maxindexpage = $_POST[maxindexpage];
        $tellfriend = $_POST[tellfriend];
        $addtoyourwebsite = $_POST[addtoyourwebsite];
        $mostpopularlist = $_POST[mostpopularlist];
        $maxmostpopular = $_POST[maxmostpopular];
        $newestlist = $_POST[newestlist];
        $maxnewest = $_POST[maxnewest];
        $topplayerslist = $_POST[topplayerslist];
        $maxtopplayers = $_POST[maxtopplayers];
        $links = $_POST[links];
        $maxlinks = $_POST[maxlinks];
        $shownews = $_POST[shownews];
        $maxnews = $_POST[maxnews];
        $relatedfiles = $_POST[relatedfiles];
        $maxrelatedfiles = $_POST[maxrelatedfiles];
        $autoresize = $_POST[autoresize];
        $commentapproval = $_POST[commentapproval];
        $avataruploading = $_POST[avataruploading];
        $maxavatarsize = $_POST[maxavatarsize];
        $submitcontent = $_POST[submitcontent];
        $maxsubmitfilesize = $_POST[maxsubmitfilesize]*1024;
        $maxsubmitimagesize = $_POST[maxsubmitimagesize]*1024;

        // Write new settings file
        $newsettings = '<?php
    $siteonline = "'.$sitestatus.'";
        $siteurl = "'.$siteurl.'";
        $filesdir = "'.$filesdir.'";
        $sitename = "'.$sitetitle.'";
        $sitedescription = "'.$sitedescription.'";
        $sitekeywords = "'.$sitekeywords.'";
        $sitecontactemail = "'.$sitecontactemail.'";
        $template = "'.$template.'";
        $emailconfirmation = "'.$emailconfirmation.'";
        $addtoyourwebsite = "'.$addtoyourwebsite.'";
        $commentson = "'.$commentson.'";
        $commentapproval = "'.$commentapproval.'";
        $commentwho = "'.$commentwho.'";
        $ratewho = "'.$ratewho.'";
        $maxcomments = "'.$maxcomments.'";
        $mostpopularlist = "'.$mostpopularlist.'";
        $maxmostpopular = "'.$maxmostpopular.'";
        $newestlist = "'.$newestlist.'";
        $maxnewest = "'.$maxnewest.'";
        $maxfilewidth = "'.$maxfilewidth.'";
        $maxfileheight = "'.$maxfileheight.'";
        $autoresize = "'.$autoresize.'";
        $filesperpage = "'.$filesperpage.'";
        $maxindexpage = "'.$maxindexpage.'";
        $memberlogin = "'.$memberlogin.'";
        $avataruploading = "'.$avataruploading.'";
        $maxavatarsize = "'.$maxavatarsize.'";
        $topplayerslist = "'.$topplayerslist.'";
        $maxtopplayers = "'.$maxtopplayers.'";
        $shownews = "'.$shownews.'";
        $maxnews = "'.$maxnews.'";
        $links = "'.$links.'";
        $maxlinks = "'.$maxlinks.'";
        $relatedfiles = "'.$relatedfiles.'";
        $maxrelatedfiles = "'.$maxrelatedfiles.'";
        $guestcredits = "'.$guestcredits.'";
        $maxguestplays = "'.$maxguestplays.'";
        $sefriendly = "'.$sefriendly.'";
        $tellfriend = "'.$tellfriend.'";
        $submitcontent = "'.$submitcontent.'";
        $maxsubmitfilesize = "'.$maxsubmitfilesize.'";
        $maxsubmitimagesize = "'.$maxsubmitimagesize.'";
?>';
        $errorm == '0';
        $fp = fopen("../includes/settings.php", "w");
        if ($fp) {
                fwrite($fp, $newsettings);
            fclose($fp);
        } else {
                $errorm == '1';
        }

        if ($errorm == '1') {
                header ("Location: index.php?action=config&e=2");
                exit();
    } else {
            header ("Location: index.php?action=config&e=1");
                exit();
    }

} else {
        $includefile = "indexpage.php";
}


?>
<html dir="rtl">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<title><?php echo $sitename; ?> - &#1604;&#1608;&#1581;&#1577; &#1575;&#1604;&#1578;&#1581;&#1603;&#1605;</title>

<style type="text/css">
<!--
a:link {
        color: #003366;
        text-decoration: underline;
}

a:visited {
        color: #003366;
        text-decoration: underline;
}

a:hover {
        color: #FF6347;
        text-decoration: none;
}
.top-link:link {
        color: #FFFFFF;
        text-decoration: underline;
        font-weight: bold;
}

.top-link:visited {
        color: #FFFFFF;
        text-decoration: underline;
        font-weight: bold;
}

.top-link:hover {
        color: #FFFFFF;
        text-decoration: none;
        font-weight: bold;
}
.order:link {
        color: #000000;
        text-decoration: underline;
        font-weight: bold;
}

.order:visited {
        color: #000000;
        text-decoration: underline;
        font-weight: bold;
}

.order:hover {
        color: #000000;
        text-decoration: none;
        font-weight: bold;
}
-->
</style>

<script LANGUAGE="JavaScript" type="text/JavaScript">
<!--
function confirmDelete()
{
var ok=confirm("�� ��� ����� �� ��� ����� �  <?php if ($action == 'comments') { echo "comment"; } elseif ($action == 'games') { echo "file"; } elseif ($action == 'categories') { echo "category"; } elseif ($action == 'users') { echo "user"; } elseif ($action == 'news') { echo "post"; } elseif ($action == 'links') { echo "link"; } elseif ($action == 'pages') { echo "page"; } ?>?");
if (ok)
        return true ;
else
        return false ;
}
// -->
</script>

</head>
<body bgcolor="#36648B">

<center>
<table style="border: 2px solid #003366; font-size: 12px; font-family: Arial; background-color: #FFFFFF; width: 780">
 <tr>
  <td align="left">
   <p dir="rtl">
   <a href="<?php echo $siteurl; ?>" target="_self">
        <img src="images/logo.gif" title="<?php echo $sitename; ?> Administration" alt="<?php echo $sitename; ?> Administration" border="0" width="300" height="80" align="right"></a>
  </td>
 </tr>

  <td align="center" style="background-color: #003366; font-size: 12px; font-family: Arial; font-weight: bold; color: #FFFFFF;">
  <p dir="rtl"><b><a target="_self" class="top-link" href="index.php">
        &#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607;</a> |
        <a target="_self" class="top-link" href="index.php?action=categories">
        &#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601;&#1575;&#1578;</a> |
        <a target="_self" class="top-link" href="index.php?action=games">
        &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578;</a> |
        <a target="_self" class="top-link" href="index.php?action=users">
        &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</a> |
        <a target="_self" class="top-link" href="index.php?action=config">
        &#1573;&#1593;&#1583;&#1575;&#1583;&#1575;&#1578;</a> |
        <a target="_self" class="top-link" href="index.php?action=links">
        &#1585;&#1608;&#1575;&#1576;&#1591;</a> |
        <a target="_self" class="top-link" href="index.php?action=news">
        &#1575;&#1582;&#1576;&#1575;&#1585;</a> |
        <a target="_self" class="top-link" href="index.php?action=pages">
        &#1589;&#1601;&#1581;&#1575;&#1578; &#1582;&#1575;&#1589;&#1577;</a> |
        <a target="_self" class="top-link" href="index.php?action=stats">
        &#1575;&#1604;&#1575;&#1581;&#1589;&#1575;&#1574;&#1610;&#1575;&#1578;</a> |
        <a target="_self" class="top-link" href="index.php?action=massemail">
        &#1605;&#1585;&#1575;&#1587;&#1604;&#1577;
        &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</a> |
        </b>
        <a target="_self" class="top-link" href="<?php echo $siteurl; ?>/login.php?action=logout">
        &#1582;&#1585;&#1608;&#1580;</a>
  </td>
 </tr>
 <tr>
  <td style="font-size: 12px; font-family: Arial; background-color: #FFFFFF; padding: 2px;">

<?php
include ($includefile);
?>

  </td>
 </tr>
 <tr>
  <td align="center" style="background-color: #003366; font-size: 12px; font-family: Arial; color: #FFFFFF;">
  &nbsp;
  </td>
 </tr>
</table>
</center>

</body>
</html>