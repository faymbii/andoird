<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=addpage">&#1575;&#1590;&#1601; &#1589;&#1601;&#1581;&#1607; &#1580;&#1583;&#1610;&#1583;&#1607;</a></center><br />

<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="4">
	<p dir="rtl"><span lang="ar-sa"><font color="#FF0000"><b>&#1589;&#1601;&#1581;&#1607; &#1580;&#1583;&#1610;&#1583;&#1607; &#1575;&#1590;&#1610;&#1601;&#1578; 
	&#1576;&#1606;&#1580;&#1575;&#1581;</b></font></span></td>
  </tr>
<?php } elseif ($error == '2') {?>
  <tr>
  <td align="center" colspan="4"><span lang="ar-sa"><font color="#FF0000"><b>&#1578;&#1605; 
	&#1581;&#1584;&#1601; &#1575;&#1604;&#1589;&#1601;&#1581;&#1607; &#1576;&#1606;&#1580;&#1575;&#1581;</b></font></span></td>
  </tr>
  <?php } ?>
  <tr>
  <td align="center" width="25%"><span lang="ar-sa"><b>&#1575;&#1604;&#1593;&#1606;&#1608;&#1575;&#1606;</b></span></td><td align="center" width="30%">
	<span lang="ar-sa"><b>&#1575;&#1604;&#1608;&#1589;&#1601;</b></span></td><td align="center" width="25%">
	<span lang="ar-sa"><b>&#1575;&#1604;&#1585;&#1575;&#1576;&#1591;</b></span></td><td width="20%"></td>
  </tr>
<?php
$pagenr = "0";
$news_result = mysql_query("SELECT * FROM pages ORDER BY title");
if (mysql_num_rows($news_result)) {
while($row = mysql_fetch_array($news_result)) {
	    $pageTitle = $row['title'];
        $pageId = $row['pageid'];
        $pageDescription = $row['description'];
        if ($pagenr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $pagenr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $pagenr = "0";
        }
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
    <td width="25%"><?php echo $pageTitle; ?></td><td width="30%"><?php echo $pageDescription; ?></td><td width="25%"><?php if ($sefriendly == '1') { echo $siteurl.'/page/'.$pageId.'.html'; } else { echo $siteurl.'/page.php?p='.$pageId; } ?></td><td align="center" width="20%">
	<a href="index.php?action=editpage&p=<?php echo $pageId; ?>">&#1578;&#1593;&#1583;&#1610;&#1604;</a> - 
	<a onclick="return confirmDelete()" href="index.php?action=deletepage&p=<?php echo $pageId; ?>">
	&#1581;&#1584;&#1601;</a></td>
  </tr>
<?php
}
}
?>
</table>