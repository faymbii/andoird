<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a style="color: #003366;" href="index.php?action=addlink">&#1575;&#1590;&#1601; &#1585;&#1575;&#1576;&#1591; &#1580;&#1583;&#1610;&#1583;</a></center><br />

<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="4"><font color="#FF0000"><b>&#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1575;&#1590;&#1610;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581;</b></font></td>
  </tr>
<?php } elseif ($error == '2') {?>
  <tr>
  <td align="center" colspan="4"><font color="#FF0000"><b>&#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1581;&#1584;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581;</b></font></td>
  </tr>
  <?php } ?>
  <tr>
  <td align="center"><b>&#1575;&#1604;&#1605;&#1608;&#1602;&#1593;</b></td><td align="center"><b>&#1575;&#1604;&#1586;&#1610;&#1575;&#1585;&#1575;&#1578;</b></td><td align="center">
	<b>&#1575;&#1604;&#1608;&#1590;&#1593;</b></td><td></td>
  </tr>
<?php
$linknr = "0";
$links_result = mysql_query("SELECT * FROM links ORDER BY name");
if (mysql_num_rows($links_result)) {
while($row = mysql_fetch_array($links_result)) {
	    $linkid = $row['linkid'];
        $linkurl = ($row['linkurl']);
        $linkname = ($row['name']);
        $hitsin = $row['hitsin'];
        $linkstatus = $row['status'];
	    if ($linkstatus == '1') {
		    $linkstatus = "<font color=\"green\">&#1606;&#1588;&#1591;</font>";
	    } else {
		    $linkstatus = "<font color=\"red\">&#1594;&#1610;&#1585; &#1606;&#1588;&#1591;</font>";
	    }
        if ($linknr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $linknr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $linknr = "0";
        }
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
  <td><a href="<?php echo $linkurl; ?>" target="_blank" style="color: #003366;"><?php echo $linkname; ?></a></td><td align="center"><?php echo $hitsin; ?></td><td align="center"><?php echo $linkstatus; ?></td><td align="center">
	<a style="color: #003366;" href="index.php?action=editlink&linkid=<?php echo $linkid; ?>">
	&#1578;&#1593;&#1583;&#1610;&#1604;</a> - 
	<a onclick="return confirmDelete()" style="color: #003366;" href="index.php?action=deletelink&linkid=<?php echo $linkid; ?>">
	&#1581;&#1584;&#1601;</a></td>
  </tr>
<?php
}
}
?>
</table>