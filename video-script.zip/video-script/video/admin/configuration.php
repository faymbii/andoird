<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<form action="index.php?action=updateconfig" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial; " width="100%">
<?php if (!is_writable('../includes/settings.php')) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="4">
	<p dir="rtl"><font color="#FF0000"><b>&#1610;&#1585;&#1580;&#1609; &#1575;&#1593;&#1591;&#1575;&#1569; &#1575;&#1604;&#1605;&#1604;&#1601;</b></font><font color="red"><b> settings.php 
	&#1575;&#1604;&#1578;&#1585;&#1582;&#1610;&#1589; 666 &#1581;&#1578;&#1609; &#1578;&#1578;&#1605;&#1603;&#1606; &#1605;&#1606; &#1581;&#1601;&#1592; &#1575;&#1604;&#1575;&#1593;&#1583;&#1575;&#1583;&#1575;&#1578; (CHMOD it to 666)</b></font></td>
  </tr>
<?php } ?>
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="4">
	<p dir="rtl"><font color="#FF0000"><b>&#1578;&#1605; &#1581;&#1601;&#1592; &#1575;&#1604;&#1575;&#1593;&#1583;&#1575;&#1583;&#1575;&#1578; &#1576;&#1606;&#1580;&#1575;&#1581; </b></font>
	<font color="red"><b>!</b></font></td>
  </tr>
<?php } elseif ($error == '2') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="4">
	<p dir="rtl"><font color="red"><b>&#1604;&#1575; &#1610;&#1605;&#1603;&#1606; &#1601;&#1578;&#1581; &#1605;&#1604;&#1601; settings.php &#1548; &#1575;&#1604;&#1585;&#1580;&#1575;&#1569; 
	&#1575;&#1604;&#1578;&#1575;&#1603;&#1583; &#1605;&#1606; &#1608;&#1580;&#1608;&#1583;&#1607; &#1576;&#1575;&#1604;&#1605;&#1608;&#1602;&#1593; &#1608;&#1575;&#1604;&#1578;&#1585;&#1582;&#1610;&#1589; &#1610;&#1603;&#1608;&#1606; 777</b></font></td>
  </tr>
<?php } ?>
  <tr>
    <td valign="top" colspan="4">
	<p align="right"><b>&#1575;&#1593;&#1583;&#1575;&#1583;&#1575;&#1578; &#1593;&#1575;&#1605;&#1577;</b></td>
  </tr>
  <tr bgcolor="#A4D3EE">
    <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1606;&#1608;&#1575;&#1606; &#1605;&#1608;&#1602;&#1593;&#1603; :</td>
  	<td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="sitetitle" value="<?php echo $sitename; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
    <td width="383" valign="top" align="right" dir="rtl">
	&#1593;&#1606;&#1608;&#1575;&#1606; &#1605;&#1608;&#1602;&#1593;&#1603;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1585;&#1575;&#1576;&#1591; &#1605;&#1608;&#1602;&#1593;&#1603; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="siteurl" value="<?php echo $siteurl; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">
	<p dir="rtl">&#1585;&#1575;&#1576;&#1591; &#1605;&#1608;&#1602;&#1593;&#1603; (&#1605;&#1579;&#1575;&#1604;: http://www.domain.com)</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1608;&#1589;&#1601; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="sitedescription" value="<?php echo $sitedescription; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1608;&#1589;&#1601; &#1605;&#1581;&#1578;&#1608;&#1609; &#1605;&#1608;&#1602;&#1593;&#1603;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1577; &#1604;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="sitekeywords" value="<?php echo $sitekeywords; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1577; &#1604;&#1605;&#1608;&#1602;&#1593;&#1603;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1610;&#1605;&#1610;&#1604; &#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="sitecontactemail" value="<?php echo $sitecontactemail; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1610;&#1585;&#1580;&#1609; &#1603;&#1578;&#1575;&#1576;&#1607; &#1575;&#1604;&#1575;&#1610;&#1605;&#1610;&#1604; &#1575;&#1604;&#1582;&#1575;&#1589; 
	&#1576;&#1575;&#1604;&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1593;&#1575;&#1605; .</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1608;&#1590;&#1593; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="sitestatus"><option value="1" <?php if ($siteonline == '1') { echo "selected"; } ?>>Online</option><option value="0" <?php if ($siteonline == '0') { echo "selected"; } ?>>&#1575;&#1604;&#1605;&#1608;&#1602;&#1593; &#1605;&#1594;&#1604;&#1602;</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1610;&#1605;&#1603;&#1606;&#1603; &#1594;&#1604;&#1602; &#1575;&#1608; &#1601;&#1578;&#1581; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593; 
	&#1603;&#1605;&#1575; &#1578;&#1588;&#1575;&#1569; &#1576;&#1575;&#1582;&#1578;&#1610;&#1575;&#1585;&#1603; &#1575;&#1581;&#1583;&#1609; &#1607;&#1584;&#1607; &#1575;&#1604;&#1582;&#1610;&#1575;&#1585;&#1575;&#1578;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1582;&#1578;&#1589;&#1575;&#1585; &#1575;&#1604;&#1585;&#1608;&#1575;&#1576;&#1591; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="sefriendly"><option value="1" <?php if ($sefriendly == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($sefriendly == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1582;&#1578;&#1589;&#1575;&#1585; &#1575;&#1604;&#1585;&#1608;&#1575;&#1576;&#1591; &#1604;&#1587;&#1607;&#1608;&#1604;&#1577; 
	&#1575;&#1585;&#1588;&#1601;&#1578;&#1607;&#1575; &#1605;&#1606; &#1602;&#1576;&#1604; &#1605;&#1581;&#1585;&#1603;&#1575;&#1578; &#1575;&#1604;&#1576;&#1581;&#1579;<span lang="en-us"><br>
	</span><font size="1">( &#1608;&#1604;&#1603;&#1606; &#1576;&#1575;&#1604;&#1605;&#1602;&#1575;&#1576;&#1604; &#1610;&#1587;&#1576;&#1576; &#1575;&#1585;&#1578;&#1601;&#1575;&#1593; &#1576;&#1575;&#1604;&#1604;&#1608;&#1583; &#1576;&#1575;&#1604;&#1587;&#1610;&#1585;&#1601;&#1585; )</font><br>
&nbsp;www.domain.com/1/<span lang="en-us">File</span>.html</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1587;&#1605; &#1575;&#1604;&#1575;&#1587;&#1578;&#1575;&#1610;&#1604; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="template" value="<?php echo $template; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1580;&#1604;&#1583; &#1575;&#1604;&#1582;&#1575;&#1589; 
	&#1576;&#1575;&#1604;&#1575;&#1587;&#1578;&#1575;&#1610;&#1604; </td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1583;&#1604;&#1610;&#1604; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="filesdir" value="<?php echo $filesdir; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1590;&#1593; &#1593;&#1606;&#1608;&#1575;&#1606; &#1575;&#1604;&#1605;&#1580;&#1604;&#1583; &#1575;&#1604;&#1582;&#1575;&#1589; 
	&#1576;&#1575;&#1604;&#1605;&#1604;&#1601;&#1578; &#1576;&#1605;&#1608;&#1602;&#1593;&#1603; <br>
	&nbsp;(http://yoursite.com/files/(files directory)/.</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="commentson"><option value="1" <?php if ($commentson == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($commentson == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1593;&#1585;&#1590; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1605;&#1608;&#1575;&#1601;&#1602;&#1577; &#1593;&#1604;&#1609; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="commentapproval"><option value="1" <?php if ($commentapproval == '1') { echo "selected"; } ?>>&#1575;&#1604;&#1605;&#1608;&#1575;&#1601;&#1602;&#1577; &#1593;&#1604;&#1609; &#1580;&#1605;&#1610;&#1593; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</option><option value="2" <?php if ($commentapproval == '2') { echo "selected"; } ?>>Require approval for only guests</option><option value="0" <?php if ($commentapproval == '0') { echo "selected"; } ?>>&#1604;&#1575; &#1610;&#1588;&#1578;&#1585;&#1591; &#1575;&#1604;&#1605;&#1608;&#1575;&#1601;&#1602;&#1577;</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1604;&#1605;&#1608;&#1575;&#1601;&#1602;&#1577; &#1593;&#1604;&#1609; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1605;&#1606; &#1610;&#1581;&#1602; &#1604;&#1607; &#1603;&#1578;&#1575;&#1576;&#1577; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;:</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="commentwho"><option value="1" <?php if ($commentwho == '1') { echo "selected"; } ?>>&#1575;&#1610; &#1588;&#1582;&#1589;</option><option value="2" <?php if ($commentwho == '2') { echo "selected"; } ?>>&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569; &#1601;&#1602;&#1591;</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1575;&#1588;&#1582;&#1575;&#1589; &#1575;&#1604;&#1584;&#1610;&#1606; &#1610;&#1581;&#1602; &#1604;&#1607;&#1605; 
	&#1603;&#1578;&#1575;&#1576;&#1577; &#1578;&#1593;&#1604;&#1610;&#1602; &#1593;&#1604;&#1609; &#1575;&#1604;&#1605;&#1602;&#1575;&#1591;&#1593;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578; 
	:</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="maxcomments" value="<?php echo $maxcomments; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578; &#1575;&#1604;&#1605;&#1593;&#1585;&#1608;&#1590;&#1577; &#1601;&#1610; 
	&#1575;&#1604;&#1589;&#1601;&#1581;&#1575;&#1578;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1605;&#1606; &#1610;&#1581;&#1602; &#1604;&#1607; &#1575;&#1604;&#1578;&#1602;&#1610;&#1610;&#1605; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="ratewho"><option value="1" <?php if ($ratewho == '1') { echo "selected"; } ?>>&#1575;&#1610; &#1588;&#1582;&#1589;</option><option value="2" <?php if ($ratewho == '2') { echo "selected"; } ?>>&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569; &#1601;&#1602;&#1591;</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1575;&#1588;&#1582;&#1575;&#1589; &#1575;&#1604;&#1584;&#1610;&#1606; &#1610;&#1581;&#1602; &#1604;&#1607;&#1605; 
	&#1575;&#1604;&#1578;&#1602;&#1610;&#1610;&#1605; :</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1575;&#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1575;&#1602;&#1589;&#1609; &#1604;&#1593;&#1585;&#1590; &#1575;&#1604;&#1605;&#1604;&#1601; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="maxfilewidth" value="<?php echo $maxfilewidth; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1603;&#1576;&#1585; &#1602;&#1610;&#1605;&#1577; &#1604;&#1593;&#1585;&#1590; &#1575;&#1604;&#1605;&#1604;&#1601;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1575;&#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1575;&#1602;&#1589;&#1609; &#1604;&#1591;&#1608;&#1604; &#1575;&#1604;&#1605;&#1604;&#1601; : </td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="maxfileheight" value="<?php echo $maxfileheight; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1575;&#1603;&#1576;&#1585; &#1602;&#1610;&#1605;&#1577; &#1604;&#1591;&#1608;&#1604; &#1575;&#1604;&#1605;&#1604;&#1601;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1584;&#1575; &#1603;&#1575;&#1606; &#1575;&#1604;&#1605;&#1604;&#1601; &#1603;&#1576;&#1610;&#1585; &#1580;&#1583;&#1575; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><select name="autoresize"><option value="0" <?php if ($autoresize == '0') { echo "selected"; } ?>>&#1601;&#1578;&#1581; &#1576;&#1589;&#1601;&#1581;&#1607; &#1580;&#1583;&#1610;&#1583;&#1577;</option><option value="1" <?php if ($autoresize == '1') { echo "selected"; } ?>>Resize</option></select></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1605;&#1575;&#1584;&#1575; &#1610;&#1605;&#1603;&#1606; &#1601;&#1593;&#1604;&#1607; &#1575;&#1584;&#1575; &#1603;&#1575;&#1606; 
	&#1575;&#1604;&#1605;&#1604;&#1601; &#1603;&#1576;&#1610;&#1585; &#1580;&#1583;&#1575;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1605;&#1604;&#1601; &#1604;&#1603;&#1604; &#1589;&#1601;&#1581;&#1577; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="filesperpage" value="<?php echo $filesperpage; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1575;&#1604;&#1605;&#1593;&#1585;&#1608;&#1590;&#1577; &#1601;&#1610; 
	&#1575;&#1604;&#1589;&#1601;&#1581;&#1575;&#1578;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1593;&#1604;&#1609; &#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607; :</td>
  <td width="303" dir="rtl" align="right" colspan="2"><input type="text" name="maxindexpage" value="<?php echo $maxindexpage; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1601;&#1610; &#1603;&#1604; &#1589;&#1601;&#1581;&#1607; 
	&#1576;&#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607;</td>
  </tr>
  <tr>
    <td valign="top" colspan="4" style="padding-top: 20px">
	<p align="right" dir="rtl"><b>&#1575;&#1593;&#1583;&#1575;&#1583;&#1575;&#1578; &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</b></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1583;&#1582;&#1608;&#1604; &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569; :</td>
	<td width="303" align="right" dir="rtl" colspan="2"><select name="memberlogin"><option value="1" <?php if ($memberlogin == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($memberlogin == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1575;&#1604;&#1587;&#1605;&#1575;&#1581; &#1604;&#1580;&#1605;&#1610;&#1593; &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569; 
	&#1575;&#1604;&#1583;&#1582;&#1608;&#1604;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1578;&#1571;&#1603;&#1610;&#1583; &#1575;&#1604;&#1576;&#1585;&#1610;&#1583; &#1575;&#1604;&#1575;&#1604;&#1603;&#1578;&#1585;&#1608;&#1606;&#1610; :</td>
  <td width="303" align="right" dir="rtl" colspan="2"><select name="emailconfirmation"><option value="1" <?php if ($emailconfirmation == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($emailconfirmation == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1604;&#1609; &#1575;&#1604;&#1593;&#1590;&#1608; &#1575;&#1606; &#1610;&#1603;&#1578;&#1576; &#1578;&#1575;&#1603;&#1610;&#1583; 
	&#1604;&#1604;&#1576;&#1585;&#1610;&#1583; &#1575;&#1604;&#1575;&#1604;&#1603;&#1578;&#1585;&#1608;&#1606;&#1610;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1582;&#1589;&#1575;&#1574;&#1589; &#1575;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1577; &#1604;&#1604;&#1586;&#1608;&#1575;&#1585; :</td>
  <td width="303" align="right" dir="rtl" colspan="2"><select name="guestcredits"><option value="1" <?php if ($guestcredits == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($guestcredits == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1575;&#1584;&#1575; &#1603;&#1606;&#1578; &#1578;&#1585;&#1610;&#1583; &#1578;&#1581;&#1583;&#1610;&#1583; &#1593;&#1583;&#1583; 
	&#1575;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1575;&#1578; &#1575;&#1604;&#1578;&#1610; &#1610;&#1587;&#1605;&#1581; &#1604;&#1604;&#1593;&#1590;&#1608; &#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1578;&#1607;&#1575; &#1582;&#1604;&#1575;&#1604; 24 &#1587;&#1575;&#1593;&#1577;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1586;&#1610;&#1575;&#1585;&#1575;&#1578; &#1604;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1577; :</td>
  <td width="303" align="right" dir="rtl" colspan="2"><input type="text" name="maxguestplays" value="<?php echo $maxguestplays; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1604;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1577; &#1602;&#1576;&#1604; &#1575;&#1604;&#1578;&#1587;&#1580;&#1610;&#1604;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
    <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1589;&#1608;&#1585; &#1575;&#1604;&#1588;&#1582;&#1589;&#1610;&#1577; :</td>
  	<td width="303" align="right" dir="rtl" colspan="2"><select name="avataruploading"><option value="1" <?php if ($avataruploading == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($avataruploading == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
    <td width="383" valign="top" dir="rtl" align="right">&#1578;&#1601;&#1593;&#1610;&#1604; &#1585;&#1601;&#1593; &#1575;&#1604;&#1589;&#1608;&#1585; &#1575;&#1604;&#1588;&#1582;&#1589;&#1610;&#1577;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">Maximum Avatar Size:</td>
  <td width="303" align="right" dir="rtl" colspan="2"><input type="text" name="maxavatarsize" value="<?php echo $maxavatarsize; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"> Bytes</td>
  <td width="383" valign="top" dir="rtl" align="right">Maximum avatar file size</td>
  </tr>
  <tr>
    <td valign="top" colspan="4" style="padding-top: 20px">
	<p dir="rtl" align="right"><b>Other Features</b></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" height="24" align="right" dir="rtl">&#1575;&#1582;&#1576;&#1585; &#1589;&#1583;&#1610;&#1602; :</td>
  <td dir="rtl">&nbsp;</td>
	<td dir="rtl"><select name="tellfriend"><option value="1" <?php if ($tellfriend == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($tellfriend == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" height="24" dir="rtl" align="right">&#1593;&#1585;&#1590; &#1585;&#1575;&#1576;&#1591; &#1575;&#1582;&#1576;&#1585; &#1589;&#1583;&#1610;&#1602;&#1603;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">
	<p dir="rtl">&#1578;&#1601;&#1593;&#1610;&#1604; &#1575;&#1604; <span lang="en-us">html</span></td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="addtoyourwebsite"><option value="1" <?php if ($addtoyourwebsite == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($addtoyourwebsite == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1610;&#1578;&#1610;&#1581; &#1604;&#1603; &#1607;&#1584;&#1575; &#1575;&#1604;&#1582;&#1610;&#1575;&#1585; &#1575;&#1606; &#1610;&#1578;&#1605; 
	&#1608;&#1590;&#1593; &#1604;&#1603;&#1604; &#1605;&#1604;&#1601; &#1603;&#1608;&#1583; &#1604;&#1606;&#1602;&#1604;&#1607; &#1605;&#1606; &#1602;&#1576;&#1604; &#1575;&#1604;&#1586;&#1608;&#1575;&#1585; &#1604;&#1605;&#1608;&#1575;&#1602;&#1593;&#1607;&#1605;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1571;&#1603;&#1579;&#1585; &#1588;&#1593;&#1576;&#1610;&#1577; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="mostpopularlist"><option value="1" <?php if ($mostpopularlist == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($mostpopularlist == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">
	&#1593;&#1585;&#1590; &#1575;&#1604;&#1571;&#1603;&#1579;&#1585; &#1588;&#1593;&#1576;&#1610;&#1577; &#1576;&#1575;&#1604;&#1602;&#1575;&#1574;&#1605;&#1577; &#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1575;&#1604;&#1575;&#1603;&#1579;&#1585; &#1588;&#1593;&#1576;&#1610;&#1607; 
	::</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxmostpopular" value="<?php echo $maxmostpopular; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1575;&#1604;&#1575;&#1603;&#1579;&#1585; &#1588;&#1593;&#1576;&#1610;&#1577; 
	&#1578;&#1592;&#1607;&#1585; &#1593;&#1604;&#1609; &#1602;&#1575;&#1574;&#1605;&#1577; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1575;&#1604;&#1575;&#1603;&#1579;&#1585; &#1588;&#1593;&#1576;&#1610;&#1577;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1581;&#1583;&#1579; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="newestlist"><option value="1" <?php if ($newestlist == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($newestlist == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1585;&#1590; &#1575;&#1581;&#1583;&#1579; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1576;&#1575;&#1604;&#1602;&#1575;&#1574;&#1605;&#1577;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">
	<p dir="rtl">&#1575;&#1581;&#1583;&#1579; &#1593;&#1583;&#1583; &#1605;&#1606; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; : </td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxnewest" value="<?php echo $maxnewest; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1575;&#1604;&#1605;&#1593;&#1585;&#1608;&#1590;&#1577; &#1593;&#1604;&#1609; &#1602;&#1575;&#1574;&#1605;&#1577; &#1575;&#1581;&#1583;&#1579; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578;.</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right">&#1575;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="topplayerslist"><option value="1" <?php if ($topplayerslist == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($topplayerslist == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">
	&#1593;&#1585;&#1590; &#1575;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1576;&#1575;&#1604;&#1602;&#1575;&#1574;&#1605;&#1577; &#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1610;&#1606; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxtopplayers" value="<?php echo $maxtopplayers; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1576;&#1610;&#1606; &#1587;&#1610;&#1578;&#1605; &#1608;&#1590;&#1593;&#1607;&#1605; &#1576;&#1575;&#1604;&#1602;&#1575;&#1574;&#1605;&#1577; &#1576;&#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1585;&#1608;&#1575;&#1576;&#1591; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="links"><option value="1" <?php if ($links == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($links == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">Display partner links</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1585;&#1608;&#1575;&#1576;&#1591; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxlinks" value="<?php echo $maxlinks; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1604;&#1585;&#1608;&#1575;&#1576;&#1591; &#1601;&#1610; &#1575;&#1601;&#1590;&#1604; 
	&#1575;&#1604;&#1585;&#1608;&#1575;&#1576;&#1591; &#1576;&#1575;&#1604;&#1602;&#1575;&#1574;&#1605;&#1577;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">
	<p dir="rtl">&#1575;&#1604;&#1575;&#1582;&#1576;&#1575;&#1585; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="shownews"><option value="1" <?php if ($shownews == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($shownews == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1585;&#1590; &#1575;&#1604;&#1575;&#1582;&#1576;&#1575;&#1585; &#1576;&#1575;&#1604;&#1589;&#1601;&#1581;&#1607; &#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1577;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1575;&#1582;&#1576;&#1575;&#1585;:</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxnews" value="<?php echo $maxnews; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1604;&#1575;&#1582;&#1576;&#1575;&#1585; &#1576;&#1575;&#1604;&#1589;&#1601;&#1581;&#1607; &#1575;&#1604;&#1585;&#1574;&#1610;&#1587;&#1610;&#1607;.</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">
	<p dir="rtl">&#1578;&#1602;&#1610;&#1610;&#1605;&#1575;&#1578; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="relatedfiles"><option value="1" <?php if ($relatedfiles == '1') { echo "selected"; } ?>>&#1605;&#1601;&#1593;&#1604;</option><option value="0" <?php if ($relatedfiles == '0') { echo "selected"; } ?>>&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1585;&#1590; &#1575;&#1604;&#1578;&#1602;&#1610;&#1610;&#1605;&#1575;&#1578; &#1601;&#1610; &#1605;&#1604;&#1601;&#1575;&#1578; 
	&#1576;&#1575;&#1604;&#1589;&#1601;&#1581;&#1575;&#1578;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1593;&#1583;&#1583; &#1575;&#1604;&#1578;&#1602;&#1610;&#1610;&#1605;&#1575;&#1578; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxrelatedfiles" value="<?php echo $maxrelatedfiles; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1593;&#1583;&#1583; &#1575;&#1604;&#1578;&#1602;&#1610;&#1610;&#1605;&#1575;&#1578; &#1593;&#1604;&#1609; &#1575;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; 
	&#1601;&#1610; &#1603;&#1604; &#1589;&#1601;&#1581;&#1607;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1605;&#1585;&#1575;&#1587;&#1604;&#1607; :</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><select name="submitcontent"><option value="1" <?php if ($submitcontent == '1') { echo "selected"; } ?>>
	&#1575;&#1610; &#1588;&#1582;&#1589;</option><option value="2" <?php if ($submitcontent == '2') { echo "selected"; } ?>>
	&#1601;&#1602;&#1591; &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;</option><option value="0" <?php if ($submitcontent == '0') { echo "selected"; } ?>>
	&#1605;&#1593;&#1591;&#1604;</option></select></td>
  <td width="383" valign="top" dir="rtl" align="right">&#1578;&#1605;&#1603;&#1610;&#1606; &#1575;&#1604;&#1605;&#1587;&#1578;&#1582;&#1583;&#1605;&#1610;&#1606; &#1605;&#1606; &#1578;&#1602;&#1583;&#1610;&#1605; &#1605;&#1581;&#1578;&#1608;&#1609; &#1580;&#1583;&#1610;&#1583;</td>
  </tr>
  <tr>
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1575;&#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1575;&#1602;&#1589;&#1609; &#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1605;&#1604;&#1601;:</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxsubmitfilesize" value="<?php echo $maxsubmitfilesize/1024; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"> 
	KB</td>
  <td width="383" valign="top" dir="rtl" align="right">&#1575;&#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1575;&#1602;&#1589;&#1609; &#1604;&#1604;&#1605;&#1604;&#1601;&#1575;&#1578; &#1575;&#1604;&#1578;&#1610; 
	&#1610;&#1605;&#1603;&#1606; &#1578;&#1581;&#1605;&#1610;&#1604;&#1607;&#1575; </td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="311" valign="top" align="right" dir="rtl">&#1575;&#1575;&#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1575;&#1602;&#1589;&#1609; &#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1589;&#1608;&#1585;&#1577;:</td>
  <td width="4" dir="rtl">&nbsp;</td><td width="306" align="right" dir="rtl"><input type="text" name="maxsubmitimagesize" value="<?php echo $maxsubmitimagesize/1024; ?>" style="width: 100px; margin: 2px; border: 1px solid #4A708B;"> 
	KB</td>
  <td width="383" valign="top" dir="rtl" align="right">&#1575;&#1604;&#1581;&#1580;&#1605; &#1575;&#1604;&#1575;&#1602;&#1589;&#1609; &#1604;&#1604;&#1589;&#1608;&#1585;&#1577; &#1575;&#1604;&#1578;&#1610; 
	&#1610;&#1605;&#1603;&#1606; &#1578;&#1581;&#1605;&#1610;&#1604;&#1607;&#1575; </td>
  </tr>
  <tr>
  <td colspan="4" align="center">
	<input type="submit" name="submit" value="&#1581;&#1601;&#1592; &#1575;&#1604;&#1575;&#1593;&#1583;&#1575;&#1583;&#1575;&#1578;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>