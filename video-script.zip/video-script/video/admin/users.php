<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=adduser">&#1575;&#1590;&#1601; &#1605;&#1587;&#1578;&#1582;&#1583;&#1605; &#1580;&#1583;&#1610;&#1583;</a></center><br />

<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="4">
	<p dir="rtl"><font color="#FF0000"><b>&#1593;&#1590;&#1608; &#1580;&#1583;&#1610;&#1583; &#1575;&#1590;&#1610;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581; </b></font>
	<font color="red"><b>!</b></font></td>
  </tr>
<?php } elseif ($error == '2') {?>
  <tr>
  <td align="center" colspan="4">
	<p dir="rtl"><font color="#FF0000"><b>&#1578;&#1605; &#1581;&#1584;&#1601; &#1575;&#1604;&#1593;&#1590;&#1608; &#1576;&#1606;&#1580;&#1575;&#1581; </b></font>
	<font color="red"><b>!</b></font></td>
  </tr>
<?php } 
  
$users_result = mysql_query("SELECT userid FROM users");
$usersperpage = "50";
$numrows = mysql_num_rows($users_result);
$offset = ($page - 1) * $usersperpage;
$pagescount = ceil($numrows/$usersperpage);
for ($pagen = 1; $pagen <= $pagescount; $pagen++) {
	if ($pagen == $page) {
		$nav .= " <b>$pagen</b>";
    } else {
		$nav .= " <a href=\"index.php?action=users&order=".$order."&page=".$pagen."\">".$pagen."</a>";
	} 
}
if ($page > 1) {
	$pagen = $page - 1;
	$prev = " <a href=\"index.php?action=users&order=".$order."&page=".$pagen."\"><</a>";
} else {
	$prev  = "";
}
if ($page < $pagescount) {
	$pagen = $page + 1;
	$next = " <a href=\"index.php?action=users&order=".$order."&page=".$pagen."\">></a>";
} else {
	$next = "";
}
echo "<tr><td align='center' colspan='6' style='font-size: 11px;'>".$prev.$nav.$next."</td></tr>";

?>
  <tr>
  <td align="center"><a class="order" href="index.php?action=users&order=1">
	&#1575;&#1604;&#1605;&#1587;&#1578;&#1582;&#1583;&#1605;</a></td><td align="center"><a href="index.php?action=users&order=2" class="order">&#1575;&#1604;&#1581;&#1575;&#1604;&#1577;</a></td><td align="center">
	<a class="order" href="index.php?action=users&order=3">&#1575;&#1604;&#1605;&#1580;&#1605;&#1608;&#1593;&#1577;</a></td><td></td>
  </tr>
<?php
$euserStatusName = array(
	"1" => "<font color=\"green\">&#1605;&#1601;&#1593;&#1604;</font>",
	"2" => "<font color=\"red\">&#1605;&#1581;&#1592;&#1608;&#1585;</font>",
	"0" => "<font color=\"#FF6103\">Unconfirmed</font>"
);
$euserGroupName = array(
	"2" => "<font color=\"#FF6103\">&#1575;&#1604;&#1575;&#1583;&#1575;&#1585;&#1577;</font>",
	"1" => "&#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;"
);
$usernr = "0";
$users_result = mysql_query("SELECT * FROM users ORDER BY $orderby LIMIT $offset, $usersperpage");
if (mysql_num_rows($users_result)) {
while($row = mysql_fetch_array($users_result)) {
	    $euserid = $row['userid'];
        $eusername = $row['username'];
        $euserstatus = $row['status'];
	    $eusergroup = $row['usergroup'];
        if ($usernr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $usernr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $usernr = "0";
        }
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
  <td><?php echo $eusername; ?></td><td align="center"><?php echo $euserStatusName[$euserstatus]; ?></td><td align="center"><?php echo $euserGroupName[$eusergroup]; ?></td><td align="center">
	<a href="index.php?action=edituser&userid=<?php echo $euserid; ?>">&#1578;&#1593;&#1583;&#1610;&#1604;</a> - <?php if ($eusergroup == '2') { echo "<font color='#003366'>Delete</font>"; } else {?><a onclick="return confirmDelete()" href="index.php?action=deleteuser&userid=<?php echo $euserid; ?>">&#1581;&#1584;&#1601;</a><?php } ?></td>
  </tr>
<?php
}
}
?>
</table>