<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=addgame">&#1575;&#1590;&#1601; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | <a href="index.php?action=grabfile">
Grab File</a> | <a href="index.php?action=uploadfile">&#1585;&#1601;&#1593; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> |
<a href="index.php?action=approvecomments">&#1575;&#1583;&#1575;&#1585;&#1577; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</a></center>
<form action="index.php?action=goupload" method="POST" name="form" ENCTYPE="multipart/form-data">
<table style="border: 0px none; font-size: 12px; font-family: Arial;" width="100%">
<?php if (!is_writable('../files/'.$filesdir.'/')) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="929" align="center" colspan="2">
	<p dir="rtl"><font color="red"><b>&#1610;&#1585;&#1580;&#1609; &#1575;&#1593;&#1591;&#1575;&#1569; &#1575;&#1604;&#1605;&#1580;&#1604;&#1583; (../files/<?php echo $filesdir; ?>/)&nbsp; 
	&#1575;&#1604;&#1578;&#1585;&#1582;&#1610;&#1589; 777</b></font></td>
  </tr>
<?php } ?>
<?php if (!is_writable('../files/image/')) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="929" align="center" colspan="2">
	<p dir="rtl"><font color="red"><b>&#1610;&#1585;&#1580;&#1609; &#1575;&#1593;&#1591;&#1575;&#1569; &#1575;&#1604;&#1605;&#1580;&#1604;&#1583; (../files/image/) 
	&#1575;&#1604;&#1578;&#1585;&#1582;&#1610;&#1589; 777</b></font></td>
  </tr>
<?php } ?>
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="929" align="center" colspan="2"><font color="red"><b>&#1604;&#1575; &#1610;&#1605;&#1603;&#1606; 
	&#1575;&#1604;&#1578;&#1581;&#1605;&#1610;&#1604;</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="185" valign="top" align="right" dir="rtl">&#1575;&#1604;&#1605;&#1604;&#1601; :</td>
	<td width="739" dir="rtl" align="right"><input type="file" name="uploadfile" id="uploadfile" style="width: 300px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" align="right" dir="rtl">&nbsp;&#1575;&#1604;&#1589;&#1608;&#1585;&#1577; :</td>
	<td width="739" dir="rtl" align="right"><input type="file" name="uploadimage" id="uploadimage" style="width: 300px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td colspan="2" align="center">
	<input type="submit" name="submit" value="&#1585;&#1601;&#1593;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a style="color: #003366;" href="index.php?action=games">&lt; &#1585;&#1580;&#1608;&#1593;</a>