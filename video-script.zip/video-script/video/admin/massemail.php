<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<form action="index.php?action=massemail" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial; ">
<?php if (isset($_POST[preview])) { ?>
  <tr>
  <td width="100%" colspan="3" style="margin: 2px; border: 1px dotted #4A708B;">
	<p align="right" dir="rtl"><b><font color="#FF0000">&#1593;&#1606;&#1608;&#1575;&#1606; &#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577;</font> :</b> <?php echo $masssubject; ?>&nbsp; <br />
	<b><font color="#FF0000">&#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577; </font>:</b><?php echo $previewmessage; ?>&nbsp; </td>
  </tr>
<?php }?>
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="3">
	<p dir="rtl"><font color="red"><b>&#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577; &#1575;&#1585;&#1587;&#1604;&#1578; &#1576;&#1606;&#1580;&#1575;&#1581; !</b></font></td>
  </tr>
<?php } elseif ($error == '2') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="3"><font color="red"><b>Mass PM sent!</b></font></td>
  </tr>
<?php } elseif ($error == '3') { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="3">
	<p dir="rtl"><font color="#FF0000"><b>&#1604;&#1575; &#1610;&#1605;&#1603;&#1606;&#1603; &#1575;&#1585;&#1587;&#1575;&#1604; &#1585;&#1587;&#1575;&#1604;&#1577; &#1601;&#1575;&#1585;&#1594;&#1607; </b></font>
	<font color="red"><b>!</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="185" valign="top" dir="rtl" align="right">&#1593;&#1606;&#1608;&#1575;&#1606; &#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577; : </td>
	<td width="576" dir="ltr" align="left">
	<p dir="rtl"><input type="text" name="masssubject" value="<?php echo $masssubject; ?>" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  <td width="185" valign="top" align="right" dir="rtl">&nbsp;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="185" valign="top" align="right" dir="rtl">&nbsp;&#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577; :<br>
	&nbsp;&#1610;&#1605;&#1603;&#1606;&#1603; &#1575;&#1587;&#1578;&#1582;&#1583;&#1575;&#1605; &#1593;&#1576;&#1575;&#1585;&#1607; {username}</td>
  <td width="576" dir="ltr" align="left">
	<p dir="rtl"><textarea name="massmessage" rows="5" cols="50" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $massmessage; ?></textarea></td>
  <td width="185" valign="top" align="right" dir="rtl">&nbsp;</td>
  </tr>
  <tr>
  <td width="185" valign="top" align="right" dir="rtl"><span dir="ltr">Delivery 
	Method:</span></td>
  <td width="576" dir="ltr" align="left">
	<p dir="rtl"><select name="deliverymethod"><option value="1" <?php if ($deliverymethod == "1") { echo "selected"; } ?>>&#1585;&#1587;&#1575;&#1604;&#1577; &#1593;&#1575;&#1583;&#1610;&#1577;</option><option value="2" <?php if ($deliverymethod == "2") { echo "selected"; } ?>>&#1585;&#1587;&#1575;&#1604;&#1577; &#1582;&#1575;&#1589;&#1577;</option></select></td>
  <td width="185" valign="top" align="right" dir="rtl">&nbsp;</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td colspan="3" align="center">&nbsp;<input type="submit" name="preview" value="&#1575;&#1592;&#1607;&#1575;&#1585; &#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"><input type="submit" name="submit" value="&#1575;&#1585;&#1587;&#1604; &#1575;&#1604;&#1585;&#1587;&#1575;&#1604;&#1577;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>