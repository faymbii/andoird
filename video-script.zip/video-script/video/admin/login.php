<?php

session_start();

include ("../includes/adminconfig.php");

if ($userStatus == '1' && $userGroup == '2' && isset($_SESSION['userid'])) {
	header ("Location: index.php");
	exit();
}
if (isset($_POST[submit])) {
	$username = $_POST[username];
	$password = md5($_POST[password]);
	if (empty($username) || empty($password)) {
	    $error = "Username and/or password cannot be left blank!";
	} else {
		$check = mysql_query("SELECT * FROM users WHERE username = '$username' && password = '$password'");
		if (mysql_num_rows($check) > 0) {	
	    	$row = mysql_fetch_array($check);
			$userid = $row['userid'];	
			if ($row['status'] == '1' && $row['usergroup'] == '2') {
		    	$_SESSION['userid'] = $userid;
				header("Location: ".$siteurl."/admin/index.php");
				exit();
			} else {
		    	$error = "&#1610;&#1576;&#1583;&#1608; &#1575;&#1606;&#1603; &#1604;&#1575; &#1578;&#1605;&#1578;&#1604;&#1603; &#1575;&#1604;&#1589;&#1604;&#1575;&#1581;&#1610;&#1577; &#1604;&#1583;&#1582;&#1608;&#1604; &#1607;&#1584;&#1607; &#1575;&#1604;&#1589;&#1601;&#1581;&#1607;!";
			}
		} else {
			$error = "&#1607;&#1606;&#1575;&#1604;&#1603; &#1582;&#1591;&#1575; &#1601;&#1610; &#1575;&#1583;&#1582;&#1575;&#1604; &#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1587;&#1578;&#1582;&#1583;&#1605; &#1608;&#1575;&#1604;&#1576;&#1575;&#1587;&#1608;&#1585;&#1583;!";
		}
	}
}
?>
<html>
<head>
<title>&#1604;&#1608;&#1581;&#1577; &#1575;&#1604;&#1578;&#1581;&#1603;&#1605;</title>
</head>
<body bgcolor="#36648B">

<center>

<br /><br /><br /><br />
<table style="border: 2px solid #CCCCCC; font-size: 12px; font-family: Arial; background-color: #FFFFFF;" width="313">
 <tr>
  <td align="center">
   <br /><b><font color="#FF0000" size="3">&#1604;&#1608;&#1581;&#1577; &#1575;&#1604;&#1578;&#1581;&#1603;&#1605;<br />
   </font></b>
   <?php echo $error; ?>
   <div style="padding: 10px;">
   <form action="<?php echo $siteurl; ?>/admin/login.php" method="post">
    <p dir="rtl">&#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1588;&#1585;&#1601; &#1575;&#1604;&#1593;&#1575;&#1605; :<input type="text" name="username" style="width: 150px; margin: 2px; border: 1px solid #A9A9A9;" maxlength="20"><br>
&nbsp;&#1575;&#1604;&#1600;&#1600;&#1600;&#1600;&#1600;&#1585;&#1602;&#1605; &#1575;&#1604;&#1587;&#1600;&#1600;&#1585;&#1610;&nbsp; :<input type="password" name="password" style="width: 150px; margin: 2px; border: 1px solid #A9A9A9;" maxlength="20"><br />
    <input type="submit" name="submit" value="&#1583;&#1582;&#1608;&#1604;" style="margin: 2px; border: 1px solid #A9A9A9; background-color: #FFFFFF;">
   	</p>
   </form>
   </div>
  </td>
 </tr>
</table>

</center>

</body>
</html>