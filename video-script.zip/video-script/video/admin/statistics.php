<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a style="color: #003366;" href="index.php?action=clearstats">&#1605;&#1587;&#1581; 
&#1575;&#1604;&#1575;&#1581;&#1589;&#1575;&#1574;&#1610;&#1575;&#1578;</a></center><br />

<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="3"><font color="#FF0000"><b>&#1578;&#1605; &#1605;&#1587;&#1581; &#1575;&#1604;&#1575;&#1581;&#1589;&#1575;&#1574;&#1610;&#1575;&#1578; 
	&#1576;&#1606;&#1580;&#1575;&#1581;</b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td align="center"><b>&#1575;&#1604;&#1610;&#1608;&#1605; #</b></td><td align="center"><b>&#1575;&#1604;&#1608;&#1602;&#1578;</b></td><td align="center">
	<b>&#1575;&#1604;&#1605;&#1588;&#1575;&#1607;&#1583;&#1577;</b></td><td></td>
  </tr>
<?php
$statsnr = "0";
$news_result = mysql_query("SELECT * FROM statistics ORDER BY statsid DESC");
if (mysql_num_rows($news_result)) {
while($row = mysql_fetch_array($news_result)) {
        if ($statsnr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $statsnr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $statsnr = "0";
        }
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
  <td><?php echo $row['statsid']; ?></td><td align="center"><?php echo $row['datetoday']; ?></td><td align="center"><?php echo $row['playedtoday']; ?></td>
  </tr>
<?php
}
}
?>
</table>