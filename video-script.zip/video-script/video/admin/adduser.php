<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=adduser">&#1575;&#1590;&#1575;&#1601;&#1577; &#1605;&#1587;&#1578;&#1582;&#1583;&#1605; &#1580;&#1583;&#1610;&#1583;</a></center><br />
<form action="index.php?action=addnewuser" method="POST" name="form">
<table style="border: 0px none; font-size: 12px; font-family: Arial; " width="100%">
<?php if ($error == '1') { ?>
  <tr bgcolor="#A4D3EE">
  <td valign="top" dir="rtl" colspan="2">
	<p dir="rtl" align="center"><font color="#FF0000"><b>&#1575;&#1590;&#1601; &#1605;&#1587;&#1578;&#1582;&#1583;&#1605; &#1580;&#1583;&#1610;&#1583; </b></font></td>
  </tr>
<?php } ?>
  <tr>
  <td width="34%" dir="rtl" align="right">&#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1587;&#1578;&#1582;&#1583;&#1605; :</td>
  <td width="65%" dir="rtl"><input type="text" name="eusername" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1585;&#1602;&#1605; &#1575;&#1604;&#1587;&#1585;&#1610; : </td>
  <td dir="rtl"><input type="text" name="euserpassword" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1576;&#1585;&#1610;&#1583; &#1575;&#1604;&#1575;&#1604;&#1603;&#1578;&#1585;&#1608;&#1606;&#1610; :</td>
  <td width="65%" dir="rtl"><input type="text" name="euseremail" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1576;&#1604;&#1583; : </td>
  <td width="65%" dir="rtl"><input type="text" name="euserlocation" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1589;&#1601;&#1581;&#1607; &#1575;&#1604;&#1588;&#1582;&#1589;&#1610;&#1577; :</td>
  <td width="65%" dir="rtl"><input type="text" name="euserwebsite" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1580;&#1606;&#1587; :</td>
  <td width="65%" dir="rtl"><select name="eusergender"><option value="0">
	&#1575;&#1582;&#1578;&#1585;</option><option value="1">&#1584;&#1603;&#1585;</option><option value="2">&#1575;&#1606;&#1579;&#1609;</option></select></td>
  </tr>
  <tr>
  <td width="34%" dir="rtl" align="right">&#1605;&#1580;&#1605;&#1608;&#1593;&#1577; :</td>
  <td width="65%" dir="rtl"><select name="eusergroup"><option value="1" selected>
	&#1593;&#1590;&#1608;</option><option value="2">&#1575;&#1583;&#1575;&#1585;&#1577;</option></select></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1589;&#1608;&#1585;&#1577; &#1575;&#1604;&#1588;&#1582;&#1589;&#1610;&#1577;:</td>
  <td width="65%" dir="rtl"><input type="text" name="euseravatar" style="width: 170px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="34%" dir="rtl" align="right">&#1575;&#1604;&#1608;&#1590;&#1593; :</td>
  <td width="65%" dir="ltr">
	<p dir="rtl"><select name="euserstatus"><option value="1" selected>
	&#1605;&#1601;&#1593;&#1604;</option><option value="2">&#1605;&#1581;&#1592;&#1608;&#1585;</option><option value="0">&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td colspan="2" align="center" dir="rtl">
	<input type="submit" name="submit" value="&#1575;&#1590;&#1601; &#1575;&#1604;&#1593;&#1590;&#1608;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=users">&lt; &#1585;&#1580;&#1608;&#1593;</a>