<html dir="rtl">
<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=addgame">&#1575;&#1590;&#1601; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | <a href="index.php?action=grabfile">Grab File</a> | 
<a href="index.php?action=uploadfile">&#1585;&#1601;&#1593; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | 
<a href="index.php?action=approvecomments">&#1575;&#1583;&#1575;&#1585;&#1577; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</a></center><br />
<form action="index.php?action=addnewgame" method="POST" name="form">
<div align="center">
	<table style="border-left:0 none; border-right:0 none; border-bottom:0 none; font-size: 12px; font-family: Arial; border-top-style:none; border-top-color:inherit" cellspacing="1" width="100%">
  <tr>
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1575;&#1587;&#1605;:</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><input type="text" name="name" style="width: 150px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1608;&#1589;&#1601; :</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><textarea name="description" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"></textarea></td>
  </tr>
  <tr>
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1603;&#1604;&#1605;&#1575;&#1578; &#1575;&#1604;&#1583;&#1604;&#1610;&#1604;&#1610;&#1607; :</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><textarea name="keywords" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $filekeywords; ?></textarea></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601;:</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><select name="category"><?php $category_result = mysql_query("SELECT name,catid FROM categories ORDER BY name"); if (mysql_num_rows($category_result)) { while($cat_row = mysql_fetch_array($category_result)) { echo "<option value=\"".$cat_row['catid']."\">".stripslashes($cat_row['name'])."</option>"; } }?></select></td>
  </tr>
  <tr>
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1581;&#1580;&#1605; ( &#1575;&#1604;&#1591;&#1608;&#1604; &#1608;&#1575;&#1604;&#1593;&#1585;&#1590;)</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><input type="text" name="width" style="width: 50px; margin: 2px; border: 1px solid #4A708B;"> 
	x <input type="text" name="height" style="width: 50px; margin: 2px; border: 1px solid #4A708B;"> 
	( &#1604;&#1575; &#1578;&#1590;&#1593; &#1575;&#1610; &#1581;&#1580;&#1605; &#1604;&#1604;&#1601;&#1604;&#1575;&#1588; &#1604;&#1575;&#1606;&#1607; &#1610;&#1578;&#1593;&#1585;&#1601; &#1593;&#1604;&#1609; &#1575;&#1604;&#1581;&#1580;&#1605; &#1604;&#1608;&#1581;&#1583;&#1607; )</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1606;&#1608;&#1593; &#1575;&#1604;&#1605;&#1604;&#1601; :</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><select name="gamefiletype"><option value="1">
	Google Flash</option><option value="2">dailymotion no url</option><option value="3">
	dailymotion flash</option><option value="4">Music/video</option><option value="5">
	YouTbe Flash</option></select></td>
  </tr>
  <tr>
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1605;&#1601;:</td>
  <td width="460" dir="rtl" align="right">
	<p align="right" dir="rtl">
	<input type="text" name="gamefile" value="<?php echo $gfile; ?>" style="width: 347; margin: 2px; border: 1px solid #4A708B; height:24"> 
	<select name="filelocation" size="1" tabindex="1"><option value="1">&#1605;&#1581;&#1604;&#1610;</option>
	<option value="2" selected>&#1585;&#1575;&#1576;&#1591; &#1582;&#1575;&#1585;&#1580;&#1610;</option><option value="3">Frame</option></select> </td>
  <td width="333" dir="rtl" align="right">
	&nbsp;&#1610;&#1585;&#1580;&#1609; &#1603;&#1578;&#1575;&#1576;&#1577; &#1575;&#1604;&#1585;&#1602;&#1605; &#1601;&#1602;&#1591; &#1575;&#1584;&#1575; &#1603;&#1575;&#1606; &#1575;&#1604;&#1605;&#1602;&#1591;&#1593; &#1604;&#1604;&#1601;&#1604;&#1575;&#1588; &#1605;&#1579;&#1575;&#1604; :<br>
	YIqZSc<span lang="en-us">0</span>ynNQ &#1576;&#1583;&#1604; &#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1576;&#1575;&#1604;&#1603;&#1575;&#1605;&#1604; &#1605;&#1579;&#1575;&#1604; : <br>
	http://www.youtube.com/watch?v=YIqZSc<span lang="en-us">0</span>ynNQ</td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1603;&#1608;&#1583; &#1610;&#1583;&#1608;&#1610; :</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><textarea name="customcode" rows="3" cols="35" style="margin: 2px; border: 1px solid #4A708B;"></textarea></td>
  </tr>
  <tr>
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1589;&#1608;&#1585;&#1577; :</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl">
	<input type="text" name="gameimage" value="<?php echo $gimage; ?>" style="width: 309; margin: 2px; border: 1px solid #4A708B; height:24"> <select name="imagelocation"><option value="1">
	&#1605;&#1581;&#1604;&#1610;</option><option value="2">&#1585;&#1575;&#1576;&#1591; &#1582;&#1575;&#1585;&#1580;&#1610;</option></select></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="144" valign="top" dir="rtl" align="right">
	<p align="right" dir="rtl">&#1575;&#1604;&#1608;&#1590;&#1593;:</td>
  <td width="796" dir="rtl" align="right" colspan="2">
	<p align="right" dir="rtl"><select name="filestatus"><option value="1">
	Active</option><option value="0">&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</option></select></td>
  </tr>
  <tr>
  <td align="right" dir="rtl">
	<p align="right" dir="rtl">
	<input type="submit" name="submit" value="&#1575;&#1590;&#1601; &#1575;&#1604;&#1605;&#1604;&#1601;" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table></div>

</form>
<br />
<a href="index.php?action=games">< &#1585;&#1580;&#1608;&#1593;</a>