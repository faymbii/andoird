<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
?>
<center><a href="index.php?action=addgame">&#1575;&#1590;&#1601; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | <a href="index.php?action=grabfile">Grab File</a> | 
<a href="index.php?action=uploadfile">&#1585;&#1601;&#1593; &#1605;&#1604;&#1601; &#1580;&#1583;&#1610;&#1583;</a> | 
<a href="index.php?action=approvecomments">&#1575;&#1583;&#1575;&#1585;&#1577; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</a></center><br />

<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if ($error == '1') { ?>
  <tr>
  <td align="center" colspan="6">
	<p dir="rtl"><font color="red"><b>&#1575;&#1604;&#1605;&#1604;&#1601; &#1575;&#1590;&#1610;&#1601; &#1576;&#1606;&#1580;&#1575;&#1581; !</b></font></td>
  </tr>
<?php } elseif ($error == '2') {?>
  <tr>
  <td align="center" colspan="6">
	<p dir="rtl"><font color="#FF0000"><b>&#1575;&#1604;&#1605;&#1604;&#1601; &#1578;&#1605; &#1581;&#1584;&#1601;&#1607; &#1576;&#1606;&#1580;&#1575;&#1581; </b></font></td>
  </tr>
  <?php } elseif ($error == '3') {?>
  <tr>
  <td align="center" colspan="6"><font color="red"><b>&#1575;&#1604;&#1605;&#1604;&#1601; &#1576;&#1575;&#1604;&#1601;&#1593;&#1604; &#1601;&#1610; &#1602;&#1575;&#1593;&#1583;&#1577; 
	&#1575;&#1604;&#1576;&#1610;&#1575;&#1606;&#1575;&#1578; </b></font></td>
  </tr>
<?php
}
$games_result = mysql_query("SELECT fileid FROM files");
$filesperpage = "50";
$numrows = mysql_num_rows($games_result);
$offset = ($page - 1) * $filesperpage;
$pagescount = ceil($numrows/$filesperpage);
for ($pagen = 1; $pagen <= $pagescount; $pagen++) {
	if ($pagen == $page) {
		$nav .= " <b>$pagen</b>";
    } else {
		$nav .= " <a href=\"index.php?action=games&order=".$order."&page=".$pagen."\">".$pagen."</a>";
	} 
}
if ($page > 1) {
	$pagen = $page - 1;
	$prev = " <a href=\"index.php?action=games&order=".$order."&page=".$pagen."\"><</a>";
} else {
	$prev  = "";
}
if ($page < $pagescount) {
	$pagen = $page + 1;
	$next = " <a href=\"index.php?action=games&order=".$order."&page=".$pagen."\">></a>";
} else {
	$next = "";
}
echo "<tr><td align='center' colspan='6' style='font-size: 11px;'>".$prev.$nav.$next."</td></tr>";
?>
  <tr>
  <td align="center"><a class="order" href="index.php?action=games&order=1">&#1575;&#1587;&#1605; 
	&#1575;&#1604;&#1605;&#1604;&#1601;</a></td><td align="center">
	<a class="order" href="index.php?action=games&order=2">&#1575;&#1604;&#1578;&#1589;&#1606;&#1610;&#1601;</a></td><td align="center">
	<a class="order" href="index.php?action=games&order=3">&#1575;&#1604;&#1606;&#1608;&#1593;</a></td><td align="center">
	<a class="order" href="index.php?action=games&order=4">&#1608;&#1602;&#1578; &#1575;&#1604;&#1575;&#1590;&#1575;&#1601;&#1577;</a></td><td align="center">
	<a class="order" href="index.php?action=games&order=5">&#1575;&#1604;&#1608;&#1590;&#1593;</a></td><td></td>
  </tr>
<?php
$category_sql = mysql_query("SELECT name, catid FROM categories");
while($category_row = mysql_fetch_array($category_sql)) {
    $categoryId = $category_row['catid'];
	$categoryName[$categoryId] = $category_row['name'];
}
$fileTypeName = array(
	"1" => "&#1601;&#1604;&#1575;&#1588;",
	"2" => "&#1601;&#1604;&#1575;&#1588;",
	"3" => "&#1601;&#1604;&#1575;&#1588;",
	"4" => "&#1601;&#1610;&#1583;&#1610;&#1608;",
	"5" => "&#1601;&#1604;&#1575;&#1588;"
);
$fileStatusName = array(
	"1" => "<font color=\"green\">&#1605;&#1601;&#1593;&#1604;</font>",
	"0" => "<font color=\"red\">&#1594;&#1610;&#1585; &#1605;&#1601;&#1593;&#1604;</font>",
	"2" => "<font color=\"Orange\">&#1575;&#1606;&#1578;&#1592;&#1575;&#1585; &#1605;&#1608;&#1575;&#1601;&#1602;&#1577;</font>"
);
$gamenr = "0";
$games_result = mysql_query("SELECT * FROM files ORDER BY $orderby LIMIT $offset, $filesperpage");
if (mysql_num_rows($games_result)) {
while($row = mysql_fetch_array($games_result)) {
	    $fileid = $row['fileid'];
        $filetitle = $row['title'];
        $filetype = $row['filetype'];
        $dateadded = $row['dateadded'];
        $filestatus = $row['status'];
        if ($gamenr == '0') {
	        $rowbgcolor = "#A4D3EE";
	        $gamenr = "1";
        } else {
	        $rowbgcolor = "#FFFFFF";
	        $gamenr = "0";
        }
        $filecategory = $row['category'];
?>
  <tr bgcolor="<?php echo $rowbgcolor; ?>">
  <td><?php echo $filetitle; ?></td><td align="center"><?php echo $categoryName[$filecategory]; ?></td><td align="center"><?php echo $fileTypeName[$filetype]; ?></td><td align="center"><?php echo $dateadded; ?></td><td align="center"><?php echo $fileStatusName[$filestatus]; ?></td><td align="center">
	<a href="index.php?action=editgame&gameid=<?php echo $fileid; ?>">&#1578;&#1593;&#1583;&#1610;&#1604;</a> - 
	<a href="index.php?action=comments&fid=<?php echo $fileid; ?>">&#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;</a> - 
	<a onclick="return confirmDelete()" href="index.php?action=deletegame&gameid=<?php echo $fileid; ?>">
	&#1581;&#1584;&#1601;</a></td>
  </tr>
<?php
}
}
echo "<tr><td align='center' colspan='6' style='font-size: 11px;'>".$prev.$nav.$next."</td></tr>";
?>
</table>