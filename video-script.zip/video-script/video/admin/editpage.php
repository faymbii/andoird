<?php
if ($userStatus != '1' || $userGroup != '2' || !isset($_SESSION['userid'])) {
	header ("Location: login.php");
	exit();
}
$sql = mysql_query("SELECT * FROM pages WHERE pageid = '$pageId'");
	
	if (mysql_num_rows($sql)) {
	$row = mysql_fetch_array($sql);
	
	$pageTitle = $row['title'];
	$pageContent = htmlentities($row['content']);
	$pageKeywords = $row['keywords'];
	$pageDescription = $row['description'];

    } else {
	    header ("Location: index.php?action=pages");
	    exit();
    }
?>
<center><a href="index.php?action=addpage">Add Page</a></center><br />
<form action="index.php?action=editpage&p=<?php echo $pageId; ?>" method="POST" name="form">
<table style="border: 0px; font-size: 12px; font-family: Arial; width: 100%;">
<?php if (strlen($error)) { ?>
  <tr bgcolor="#A4D3EE">
  <td width="100%" align="center" colspan="2"><b><?php echo $error; ?></b></td>
  </tr>
<?php } ?>
  <tr>
  <td width="20%" valign="top">Title:</td><td width="80%"><input type="text" name="pageTitle" value="<?php echo $pageTitle; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top">Keywords:</td><td width="80%"><input type="text" name="pageKeywords" value="<?php echo $pageKeywords; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr>
  <td width="20%" valign="top">Description:</td><td width="80%"><input type="text" name="pageDescription" value="<?php echo $pageDescription; ?>" style="width: 200px; margin: 2px; border: 1px solid #4A708B;"></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td width="20%" valign="top">Content:</td><td width="80%"><textarea name="pageContent" rows="10" cols="50" style="margin: 2px; border: 1px solid #4A708B;"><?php echo $pageContent; ?></textarea></td>
  </tr>
  <tr>
  <td width="20%" valign="top">URL:</td><td width="80%"><?php if ($sefriendly == '1') { echo $siteurl.'/page/'.$pageId.'.html'; } else { echo $siteurl.'/page.php?p='.$pageId; } ?></td>
  </tr>
  <tr bgcolor="#A4D3EE">
  <td colspan="2" align="center"><input type="submit" name="submit" value="Edit Page" style="margin: 2px; border: 1px solid #4A708B; background-color: #FFFFFF;"></td>
  </tr>
</table>
</form>
<br />
<a href="index.php?action=pages">< Back</a>