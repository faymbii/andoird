<?php

// Get user ip
function getip() {
        if (getenv('HTTP_CLIENT_IP')) {
            $ip = getenv('HTTP_CLIENT_IP');
        }
        elseif (getenv('HTTP_X_FORWARDED_FOR')) {
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        }
        elseif (getenv('HTTP_X_FORWARDED')) {
            $ip = getenv('HTTP_X_FORWARDED');
        }
        elseif (getenv('HTTP_FORWARDED_FOR')) {
            $ip = getenv('HTTP_FORWARDED_FOR');
        }
        elseif (getenv('HTTP_FORWARDED')) {
            $ip = getenv('HTTP_FORWARDED');
        }
        else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
}
function fileurl($fileId,$fileTitle) {
        global $siteurl, $sefriendly;
        if ($sefriendly == '1') {
                $fileTitle = str_replace(" ","-",$fileTitle);
        $fileTitle = str_replace("'","_",$fileTitle);
        $fileTitle = str_replace(":","_",$fileTitle);
        $fileTitle = str_replace("�","a",$fileTitle);
        $fileTitle = str_replace("�","o",$fileTitle);
        $fileTitle = str_replace("�","y",$fileTitle);
           $fileurl = $siteurl."/".$fileId.".html";
    } else {
            $fileurl = $siteurl."/file.php?f=".$fileId;
    }
        return $fileurl;
}
function categoryurl($categoryId,$categoryname) {
        global $siteurl, $sefriendly;
        if ($sefriendly == '1') {
                $categoryname = str_replace(" ","-",$categoryname);
        $categoryname = str_replace("'","_",$categoryname);
        $categoryname = str_replace("�","a",$categoryname);
        $categoryname = str_replace("�","o",$categoryname);
        $categoryname = str_replace("�","y",$categoryname);
        $categoryurl = $siteurl."/category/".$categoryId."/".$categoryId;
    } else {
            $categoryurl = $siteurl."/browse.php?c=".$categoryId;
    }
        return $categoryurl;
}
function profileurl($userid,$username) {
        global $siteurl, $sefriendly;
        if ($sefriendly == '1') {
            $username = str_replace(" ","-",$username);
            $username = str_replace("'","_",$username);
            $username = str_replace("�","a",$username);
            $username = str_replace("�","o",$username);
            $username = str_replace("�","y",$username);
            $profileurl = $siteurl."/profile/".$userid.".html";
        } else {
                $profileurl = $siteurl."/profile.php?u=".$userid;
    }
    return $profileurl;
}
//Display categories
function displaycategories($userStatus) {
        if ($userStatus == '1') {
                $result = mysql_query("SELECT name, catid FROM categories WHERE status = '1' && parentcategory = '0' ORDER BY catorder, name");
        } else {
                $result = mysql_query("SELECT name, catid FROM categories WHERE status = '1' && permissions = '1' && parentcategory = '0' ORDER BY catorder, name");
        }
    if (mysql_num_rows($result)) {
    while($row = mysql_fetch_array($result)) {
    $categoryname = $row['name'];
    $categoryid = $row['catid'];
    if (isset($separator)) {
                echo ' | ';
        }
        echo '<a href="'.categoryurl($categoryid,$categoryname).'" target="_self" class="header-link">'.$categoryname.'</a> ';
        $separator = "1";
    }
    unset ($separator);
  }
}
//Display most popular files
function displaymostpopular() {
        global $maxmostpopular;
        $result = mysql_query("SELECT title, fileid, timesplayed FROM files WHERE status = '1' ORDER BY timesplayed DESC LIMIT $maxmostpopular");
    if (mysql_num_rows($result)) {

    while($row = mysql_fetch_array($result)) {
    $mpfiletitle = $row['title'];
    $mpfileid = $row['fileid'];
    $mptimesplayed = number_format($row['timesplayed']);
    ?>
        <a href = "<?php echo fileurl($mpfileid,$mpfiletitle); ?>" target="_self"><?php echo $mpfiletitle; ?></a> (<?php echo $mptimesplayed; ?>�� ��������)<br />
    <?php
    }
    } else {
            echo "No files";
    }
}
//Display newest files
function displaynewest() {
        global $maxnewest;
        $result = mysql_query("SELECT title, fileid, timesplayed FROM files WHERE status = '1' ORDER BY fileid DESC LIMIT $maxnewest");
    if (mysql_num_rows($result)) {

    while($row = mysql_fetch_array($result)) {
    $nfiletitle = $row['title'];
    $nfileid = $row['fileid'];
    $ntimesplayed = number_format($row['timesplayed']);
    ?>
        <a href = "<?php echo fileurl($nfileid,$nfiletitle); ?>"><?php echo $nfiletitle; ?></a> (<?php echo $ntimesplayed; ?>�� ��������)<br />
    <?php
    }
    } else {
            echo "No files";
    }
}
//Display top players
function displaytopplayers() {
        global $maxtopplayers;
        $top_result = mysql_query("SELECT * FROM users WHERE status = '1' ORDER BY played DESC LIMIT $maxtopplayers");
    if (mysql_num_rows($top_result)) {

    while($top_row = mysql_fetch_array($top_result)) {
    $topuserName = $top_row['username'];
    $topuserId = $top_row['userid'];
    $topuserPlayed = number_format($top_row['played']);
    ?>
        <a href = "<?php echo profileurl($topuserId,$topuserName); ?>" target="_self"><?php echo $topuserName; ?></a> (<?php echo $topuserPlayed; ?> ��������)<br />
    <?php
    }
    } else {
            echo "No users";
    }
}
//Display top links
function displaytoplinks() {
        global $maxlinks;
        $result = mysql_query("SELECT * FROM links WHERE status = '1' ORDER BY hitsin DESC LIMIT $maxlinks");
    if (mysql_num_rows($result)) {

    while($row = mysql_fetch_array($result)) {
    $linkName = ($row['name']);
    $linkUrl = ($row['linkurl']);
    ?>
        <a href = "<?php echo $linkUrl; ?>" target="_blank"><?php echo $linkName; ?></a><br />
    <?php
    }
    } else {
            echo "No links";
    }
}
// BB Code
function bbcode($text) {
        global $siteurl;
    $text = str_replace("[b]","<b>",$text);
    $text = str_replace("[/b]","</b>",$text);
    $text = str_replace("[u]","<u>",$text);
    $text = str_replace("[/u]","</u>",$text);
    $text = str_replace("[i]","<i>",$text);
    $text = str_replace("[/i]","</i>",$text);
    $text = str_replace("[s]","<s>",$text);
    $text = str_replace("[/s]","</s>",$text);
    $text = str_replace("[quote]","<div class=\"quote\">",$text);
        $text = str_replace("[/quote]","</div>",$text);
    $text = str_replace(":)","<img src=\"".$siteurl."/images/happy.gif\" title=\"Happy\">",$text);
    $text = str_replace(":(","<img src=\"".$siteurl."/images/sad.gif\" title=\"Sad\">",$text);
    $text = str_replace(";)","<img src=\"".$siteurl."/images/wink.gif\" title=\"Wink\">",$text);
    $text = str_replace(":@:","<img src=\"".$siteurl."/images/@.gif\" title=\"@\">",$text);
    $text = str_replace(":8","<img src=\"".$siteurl."/images/cool.gif\" title=\"Cool\">",$text);
    $text = str_replace(":wave:","<img src=\"".$siteurl."/images/wave.gif\" title=\"Wave\">",$text);
    $text = str_replace(":think:","<img src=\"".$siteurl."/images/think.gif\" title=\"Hmm...\">",$text);
    $text = str_replace(":clap:","<img src=\"".$siteurl."/images/clap.gif\" title=\"Clap hands\">",$text);
    return $text;
}
// Get the number of files in database
function totalfiles() {
        $totalfiles_result = mysql_query("SELECT count(fileid) AS total_files FROM files WHERE status = '1'");
        $gettotalfiles = mysql_fetch_array($totalfiles_result);
        $totalfiles = $gettotalfiles['total_files'];
        return number_format($totalfiles);
}
// Count total played
function totalplayed() {
    $totalplayed_result = mysql_query("SELECT sum(timesplayed) AS total_played FROM files");
        $gettotalplayed = mysql_fetch_array($totalplayed_result);
        $totalplayed = $gettotalplayed['total_played'];
        return number_format($totalplayed);
}
// Count # of members
function totalmembers() {
    $totalmembers_result = mysql_query("SELECT count(userid) AS total_members FROM users WHERE status = '1'");
        $gettotalmembers = mysql_fetch_array($totalmembers_result);
        $totalmembers = $gettotalmembers['total_members'];
        return number_format($totalmembers);
}

?>