<?php
 
// Get MySQL database info
include ("dbinfo.php");

// Connect to MySQL server
$connect = @mysql_connect($db_host,$db_user,$db_pass);

if (!$connect) {
   include ("../noconnection.html");
   exit();
}

// Connect to MySQL database
$db = mysql_select_db($db_name,$connect);

// Escape string for MySQL query
function escape_string($string) {
    if (get_magic_quotes_gpc()) {
          $string = stripslashes($string);
    }
    if (function_exists("mysql_real_escape_string")) {
          $string = mysql_real_escape_string($string);
    } else {
          $string = addslashes($string);
    }
    return $string;
}

// Escape GET variable
foreach ( $_GET as $key => $val ){
	$val =  escape_string($val);
	$_GET[ $key ] = $val;
}

// Escape POST variable
foreach ( $_POST as $key => $val ){
	$val =  escape_string($val);
	$_POST[ $key ] = $val;
}

// Get settings
include ("settings.php");

// Get site statistics
$statistics_sql = mysql_query("SELECT playedtoday, datetoday FROM statistics ORDER BY statsid DESC LIMIT 1");
$stats_row = mysql_fetch_array($statistics_sql);

$played_today = $stats_row['playedtoday'];
$datetoday2 = $stats_row['datetoday'];

// Update stats
$datetoday = date("Y-m-d");
if ($datetoday != $datetoday2) {
	$today_mysql = mysql_query("INSERT INTO statistics SET datetoday = '$datetoday', playedtoday = '0'");
	$played_today = "0";
}

include ("sessions.php");

include ("functions.php");

$ipaddress = getip();
$total_files = totalfiles();
$total_played = totalplayed();
if ($memberlogin == '1') {
	$total_members = totalmembers();
}

include ("version.php");

?>