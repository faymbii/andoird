<?php
// Your MySQL database host (usually "localhost")
$db_host = "localhost";
// Your MySQL database username
$db_user = "root";
// Your MySQL database password
$db_pass = "";
// Your MySQL database name
$db_name = "swalif";
// License key
$license_key = "Translate by aljayyash & sh2soft";
?>