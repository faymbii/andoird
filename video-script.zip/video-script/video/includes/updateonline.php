<?php

$timestamp = time();
$expiration = $timestamp - 900;
$current_day = date('j');
	
	$delete_results = mysql_query("DELETE FROM online WHERE online_date != '$current_day'");
	
	if($userStatus != '1'){
		$guest_result = mysql_query("SELECT * FROM online WHERE ip = '$ipaddress' && status = '0'");
		$guest_count = mysql_num_rows($guest_result);

		$update_results = mysql_query("UPDATE online SET isonline='0' WHERE ip='$ipaddress' && status = '1'");

		if($guest_count != '0'){
			$online_result = mysql_query("UPDATE online SET timestamp = '$timestamp', online_date = '$current_day', isonline = '1' WHERE ip = '$ipaddress' && status = '0'");
		} else {
			$online_result = mysql_query("INSERT INTO online (timestamp,online_date,isonline,status,played,ip)".
			"VALUES ('". $timestamp ."', '".$current_day."', '1', '0', '0', '". $ipaddress ."')"); 
		}
	} else {
		$user_result = mysql_query("SELECT * FROM online WHERE uid = '$userId' && status = '1'");
		$user_count = mysql_num_rows($user_result);

		$update_results = mysql_query("UPDATE online SET isonline='0' WHERE ip='$ipaddress' && status = '0'");

		if($user_count != '0'){
				$online_result = mysql_query("UPDATE online SET timestamp = '$timestamp', online_date = '$current_day', isonline='1', ip='$ipaddress' WHERE uid = '$userId' && status = '1'");
		} else {
			    $uuserName = escape_string($userName);
				$online_result = mysql_query("INSERT INTO online (timestamp,online_date,isonline,status,played,ip,uid,username)".
			"VALUES ('". $timestamp ."', '".$current_day."', '1', '1', '0', '". $ipaddress ."', '". $userId ."', '". $uuserName ."')");
		}
	}
	$update_results = mysql_query("UPDATE online SET isonline = '0' WHERE timestamp < '$expiration'");
	
	// Get online stats
	$guests_online = mysql_query("SELECT * FROM online WHERE status = '0' && isonline = '1'");
    $guests_online_number = mysql_num_rows($guests_online);
    if ($memberlogin == '1') {
	    $members_online = mysql_query("SELECT * FROM online WHERE status = '1' && isonline = '1'");
	    $members_online_number = mysql_num_rows($members_online);
	    $total_online = $guests_online_number + $members_online_number;
	    $members_online_list = "";
	    if ($members_online_number > '0') {
		    $member_nr = "1";
		    while($members_row = mysql_fetch_array($members_online)) {
			    $mouserId = $members_row['uid'];
			    $mouserName = ($members_row['username']);
				$members_online_list .= "<a href=\"".profileurl($mouserId,$mouserName)."\" target=\"_self\">".$mouserName."</a>";
			    if ($member_nr < $members_online_number) {
				    $members_online_list .= ", ";
				    $member_nr++;
		        }
			}
        }
    } else {
	    $total_online = $guests_online_number;
    }
?>