<?php

//www.sh2soft.net
//www.aljayyash.net
// Check for cookies
if (!isset($_SESSION['userid'])) {
if (isset($_COOKIE['arcadeuser'])) {

	$userinfo = escape_string($_COOKIE['arcadeuser']);
	$userinfo = explode(':', $userinfo);
    $userid = $userinfo[0];
    $password = $userinfo[1];

	$cookie_check = mysql_query("SELECT * FROM users WHERE userid = '$userid' && password='$password'");

	if (mysql_num_rows($cookie_check) > '0'){
		$_SESSION['userid'] = $userid;
	}
}
}

// Check existing sessions
if (isset($_SESSION['userid'])) {

	$userid = escape_string($_SESSION['userid']);

    // Check that user
	$user_check = mysql_query("SELECT username, userid, played, comments, joined, status, usergroup, newpm, email FROM users WHERE userid = '$userid'");

	if (mysql_num_rows($user_check) > '0') {
		$row = mysql_fetch_array($user_check);

		if($row['status'] == '2'){
			$userName = NULL;
			$userId = '0';
			$userStatus = '2';
			$userGroup = '0';
		} elseif ($row['status'] == '1') {
			// Associate the constants with the database values.
			$userName = ($row['username']);
			$userId = $row['userid'];
			$userPlayed = $row['played'];
			$userComments = $row['comments'];
			$userDatejoined = $row['joined'];
			$userStatus = '1';
			$userGroup = $row['usergroup'];
			$userNewpm = $row['newpm'];
	        $userEmail = htmlentities($row['email']);
	        // Count unread PMs
	        $unread_pms = mysql_query("SELECT count(pmid) AS total_unread_pms FROM privatemessages WHERE status = '0' && userid = '$userId'");
            $get_unread_pms = mysql_fetch_array($unread_pms);
            $userUnreadpms = $get_unread_pms['total_unread_pms'];
            if ($userNewpm == '1') {
	            $update_pm = mysql_query("UPDATE users SET newpm = '0' WHERE userid = '$userId'");
            }
		} else {
			$userName = NULL;
			$userId = '0';
			$userStatus = '0';
			$userGroup = '0';
		}
		
	} else {
			$userName = NULL;
			$userId = '0';
			$userStatus = '0';
			$userGroup = '0';
    }
} else {
    $userName = NULL;
	$userId = '0';
	$userStatus = '0';
	$userGroup = '0';
}

?>