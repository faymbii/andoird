<?php
 
// Get MySQL database info
include ("dbinfo.php");

// Connect to MySQL server
$connect = @mysql_connect($db_host,$db_user,$db_pass);

if (!$connect) {
   include ("noconnection.html");
   exit();
}

// Connect to MySQL database
$db = mysql_select_db($db_name,$connect);

// Escape string for MySQL query
function escape_string($string) {
    if (get_magic_quotes_gpc()) {
          $string = stripslashes($string);
    }
    if (function_exists("mysql_real_escape_string")) {
          $string = mysql_real_escape_string($string);
    } else {
          $string = addslashes($string);
    }
    return $string;
}

// Escape GET variable
foreach ( $_GET as $key => $val ){
	$val =  escape_string($val);
	$_GET[ $key ] = $val;
}

// Escape POST variable
foreach ( $_POST as $key => $val ){
	$val =  escape_string($val);
	$_POST[ $key ] = $val;
}

// Get settings
include ("settings.php");

// Get site statistics
$statistics_sql = mysql_query("SELECT playedtoday, datetoday FROM statistics ORDER BY statsid DESC LIMIT 1");
$stats_row = mysql_fetch_array($statistics_sql);

$played_today = $stats_row['playedtoday'];
$datetoday2 = $stats_row['datetoday'];

// Update stats
$datetoday = date("Y-m-d");
if ($datetoday != $datetoday2) {
	$today_mysql = mysql_query("INSERT INTO statistics SET datetoday = '$datetoday', playedtoday = '0'");
	$played_today = "0";
}

include ("sessions.php");

include ("functions.php");

$ipaddress = getip();

include ("updateonline.php");

$total_files = totalfiles();
$total_played = totalplayed();
if ($memberlogin == '1') {
	$total_members = totalmembers();
}
if ($links == '1') {
	// Get referer
	if (!isSet($_SESSION['referer'])) { 
		$referer = $_SERVER['HTTP_REFERER'];
		$array = parse_url($referer);
		$referer1 = $array[host];
		$referer2 = trim(str_replace("www.", "", $referer1));
		$referer3 = "www.".$referer2;
		$referer4 = "http://".$referer2;
		$referer5 = "http://".$referer3;
		$add_hitsin = mysql_query("UPDATE links SET hitsin = hitsin + 1 WHERE linkurl LIKE '$referer2' || linkurl LIKE '$referer3' || linkurl LIKE '$referer4' || linkurl LIKE '$referer5'");
		$_SESSION['referer'] = 1;
	} 
}
// Check if site is online
if ($siteonline == '0' && $userGroup != '2') {
	$sitename2 = $sitename." - Offline";
	// Load template files
    include ("templates/".$template."/header.html");
    include ("templates/".$template."/offline.html");
    include ("templates/".$template."/footer.html");
	exit();
}
// Check if user is banned
if ($userStatus == '2') {
	$sitename2 = $sitename;
	// Load template files
    include ("templates/".$template."/header.html");
    include ("templates/".$template."/banned.html");
    include ("templates/".$template."/footer.html");
	exit();
}
if ($userStatus == '0' && $guestcredits == '1') {
    $guestPlays = mysql_query("SELECT played FROM online WHERE ip = '$ipaddress' && status = '0'");
    $guest_row = mysql_fetch_array($guestPlays);
    $guestPlayed = $guest_row['played'];
}

?>