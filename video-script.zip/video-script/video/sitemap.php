<?php
include ("includes/config.php");
header('Content-type: text/xml');

echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n";
echo "<urlset xmlns=\"http://www.google.com/schemas/sitemap/0.84\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.google.com/schemas/sitemap/0.84 http://www.google.com/schemas/sitemap/0.84/sitemap.xsd\">";

$map_result = mysql_query("SELECT fileid, title FROM files WHERE status = '1'");
while ($map_row = mysql_fetch_array($map_result)) {
	$fileId = $map_row['fileid'];
	$fileTitle = $map_row['title'];
	echo "\n<url>\n<loc>".fileurl($fileId, $fileTitle)."</loc>\n<changefreq>weekly</changefreq>\n<priority>1.0</priority>\n</url>";
}
echo "\n</urlset>";
?>