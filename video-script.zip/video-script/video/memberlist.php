<?php
 
session_start();

include ("includes/config.php");

$page = $_GET[page];
if (empty($page) || !is_numeric($page)) {
	$page = "1";
}
	
function displaymembers($page) {
	global $siteurl, $sefriendly;
	$usersperpage = "20";
	$result = mysql_query("SELECT * FROM users WHERE status ='1'");
	if (mysql_num_rows($result) == '0') {
		echo "<tr><td colspan=\"6\">&#1575;&#1606;&#1578; &#1594;&#1610;&#1585; &#1605;&#1588;&#1578;&#1585;&#1603; &#1604;&#1583;&#1610;&#1606;&#1575;</td></tr>";
	} else {
		
		// Get number of pages
		$numrows = mysql_num_rows($result);
		$offset = ($page - 1) * $usersperpage;
		$pagescount = ceil($numrows/$usersperpage);
		
		for ($pagen = 1; $pagen <= $pagescount; $pagen++) {
			if ($pagen == $page) {
				$nav .= "&nbsp;<b>$pagen</b>";
            } else {
	            $nav .= "&nbsp;<a href=\"".$siteurl."/memberlist.php?page=".$pagen."\">$pagen</a>";
	        } 
        }
        if ($page > 1) {
	        $pagen  = $page - 1;
	        $prev  = "<a href=\"".$siteurl."/memberlist.php?page=".$pagen."\">< &#1604;&#1604;&#1582;&#1604;&#1601;</a>";
	    } else {
		    $prev  = "";
		}
		if ($page < $pagescount) {
			$pagen = $page + 1;
			$next = "&nbsp;<a href=\"".$siteurl."/memberlist.php?page=".$pagen."\">&#1575;&#1604;&#1578;&#1575;&#1604;&#1610; ></a>";
		} else {
			$next = "";
		}
    
    $result2 = mysql_query("SELECT userid, username, played, joined, location FROM users WHERE status ='1' ORDER BY username LIMIT $offset, $usersperpage");
    
    while($row = mysql_fetch_array($result2)) {
	    
	    $muserid = $row['userid'];
	    $muserName = ($row['username']);
	    $muserPlayed = number_format($row['played']);
	    $muserdateJoined = $row['joined'];
	    $muserLocation = ($row['location']);
?>
     <tr>
       <td><a href="<?php echo profileurl($muserid,$muserName); ?>" target="_self"><?php echo $muserName; ?></a></td><td align="center"><?php echo $muserLocation; ?></td><td align="center"><?php echo $muserdateJoined; ?></td><td align="center"><?php echo $muserPlayed; ?></td><td align="center"><a href="<?php echo $siteurl; ?>/privatemessages.php?a=compose&uid=<?php echo $muserid; ?>" target="_self">PM</a></td>
     </tr>
<?php
    
    }
    // Display page numbers
    if ($pagescount > '1') {
	    echo "<tr><td colspan=\"6\" class='pagenumbers'>".$prev.$nav.$next."</td></tr>";
    }
    }
}
$pagefile = "memberlist.html";
$sitename2 = $sitename." - &#1602;&#1575;&#1574;&#1605;&#1577; &#1575;&#1604;&#1575;&#1593;&#1590;&#1575;&#1569;";

// Load template files
include ("templates/".$template."/header.html");
include ("templates/".$template."/memberlist.html");
include ("templates/".$template."/footer.html");
?>