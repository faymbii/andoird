<?php
 
session_start();

include ("includes/config.php");

if ($links != '1') {
    header("Location: ".$siteurl."/");
	exit();
}

$linksAction = $_GET[action];
$linkTitle = $_POST[linktitle];
$linkUrl = $_POST[linkurl];
$linkDescription = $_POST[linkdescription];
$linkEmail = $_POST[linkemail];
$linkError = $_GET[e];
$linkErrorText = "";
if ($linkError == '1') {
	$linkErrorText = "All fields are required";
}

if ($linksAction == 'submit') {
	if (empty($linkTitle) || empty($linkUrl) || empty($linkDescription) || empty($linkEmail)) {
		header("Location: ".$siteurl."/links.php?action=addlink&e=1");
	    exit();
	}
	$linksession = $_SESSION['linkTitle'];
	if ($linksession != $linkTitle) {
		$add_link = mysql_query( "INSERT INTO links SET linkurl = '$linkUrl', name = '$linkTitle', description = '$linkDescription', email = '$linkEmail', status = '0'");
		$_SESSION['linkTitle'] = $linkTitle;
    }
}
function displaylinks() {
	$result = mysql_query("SELECT * FROM links WHERE status = '1' ORDER BY hitsin DESC");
    if (mysql_num_rows($result)) {
    while($row = mysql_fetch_array($result)) {
    $linkName = ($row['name']);
    $linkUrl = ($row['linkurl']);
    $linkDescription = ($row['description']);
    ?>
        <a href = "<?php echo $linkUrl; ?>" target="_blank"><?php echo $linkName; ?></a> - <?php echo $linkDescription; ?><br />
    <?php
    }
    } else {
	    echo "No links";
    }
}
$sitename2 = $sitename." - Links";

// Load template files
include ("templates/".$template."/header.html");
include ("templates/".$template."/links.html");
include ("templates/".$template."/footer.html");
?>