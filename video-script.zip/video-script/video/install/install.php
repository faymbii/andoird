<?

if(!is_writable("../includes/dbinfo.php")) die("Error: includes/dbinfo.php �� ����� �� ������� ���� , ���� ������ ������� 666");
if(!is_writable("../includes/settings.php")) die("Error: includes/settings.php  �� ����� �� ������� ���� , ���� ������ ������� 666");

$db_host=$_POST["db_host"];
$db_user=$_POST["db_user"];
$db_pass=$_POST["db_pass"];
$db_name=$_POST["db_name"];

@mysql_connect($db_host,$db_user,$db_pass)
or die("�� ����� �������� ��������");

@mysql_select_db($db_name)
or die("Can't select DB, probably not exists");

$sql=array();
$sql[]="CREATE TABLE `categories` (
  `catid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `keywords` varchar(255) NOT NULL default '',
  `catorder` int(11) NOT NULL default '0',
  `permissions` tinyint(1) NOT NULL default '0',
  `parentcategory` int(11) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`catid`),
  KEY `catorder` (`catorder`),
  KEY `permissions` (`permissions`),
  KEY `parentcategory` (`parentcategory`),
  KEY `status` (`status`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `keywords` (`keywords`)
)";

$sql[]="CREATE TABLE `comments` (
  `commentid` int(11) NOT NULL auto_increment,
  `fileid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `ip` varchar(20) NOT NULL default '',
  `date` date NOT NULL default '0000-00-00',
  `status` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`commentid`),
  KEY `fileid` (`fileid`),
  KEY `userid` (`userid`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  FULLTEXT KEY `comment` (`comment`),
  FULLTEXT KEY `ip` (`ip`)
)";

$sql[]="CREATE TABLE `files` (
  `fileid` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `keywords` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `category` mediumint(9) NOT NULL default '0',
  `width` int(11) NOT NULL default '0',
  `height` int(11) NOT NULL default '0',
  `filetype` tinyint(4) NOT NULL default '0',
  `filelocation` tinyint(4) NOT NULL default '0',
  `icon` varchar(255) NOT NULL default '',
  `iconlocation` tinyint(4) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  `dateadded` date NOT NULL default '0000-00-00',
  `timesplayed` int(11) NOT NULL default '0',
  `totalvotes` int(11) NOT NULL default '0',
  `totalvotepoints` int(11) NOT NULL default '0',
  `rating` int(11) NOT NULL default '0',
  `customcode` text NOT NULL,
  `file` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`fileid`),
  KEY `category` (`category`),
  KEY `filetype` (`filetype`),
  KEY `filelocation` (`filelocation`),
  KEY `imagelocation` (`iconlocation`),
  KEY `status` (`status`),
  KEY `dateadded` (`dateadded`),
  KEY `timesplayed` (`timesplayed`),
  KEY `totalvotes` (`totalvotes`),
  KEY `totalvotepoints` (`totalvotepoints`),
  KEY `rating` (`rating`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `keywords` (`keywords`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `file` (`file`)
)";

$sql[]="CREATE TABLE `links` (
  `linkid` int(11) NOT NULL auto_increment,
  `linkurl` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `status` tinyint(4) NOT NULL default '0',
  `hitsin` int(11) NOT NULL default '0',
  PRIMARY KEY  (`linkid`),
  KEY `status` (`status`),
  KEY `hitsin` (`hitsin`),
  FULLTEXT KEY `linkurl` (`linkurl`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `email` (`email`)
)";

$sql[]="CREATE TABLE `news` (
  `newsid` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `message` text NOT NULL,
  `date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`newsid`),
  KEY `date` (`date`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `message` (`message`)
)";

$sql[]="CREATE TABLE `online` (
  `uid` int(11) NOT NULL default '0',
  `timestamp` int(11) NOT NULL default '0',
  `online_date` tinyint(4) NOT NULL default '0',
  `isonline` tinyint(4) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  `played` int(11) NOT NULL default '0',
  `ip` varchar(20) NOT NULL default '',
  KEY `isonline` (`isonline`),
  KEY `status` (`status`),
  KEY `played` (`played`),
  KEY `timestamp` (`timestamp`),
  KEY `uid` (`uid`),
  FULLTEXT KEY `ip` (`ip`)
)";

$sql[]="CREATE TABLE `pages` (
  `pageid` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `keywords` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  PRIMARY KEY  (`pageid`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `keywords` (`keywords`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `content` (`content`)
)";

$sql[]="CREATE TABLE `privatemessages` (
  `pmid` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  `touser` int(11) NOT NULL default '0',
  `fromuser` int(11) NOT NULL default '0',
  `folder` tinyint(4) NOT NULL default '0',
  `subject` varchar(50) NOT NULL default '',
  `message` text NOT NULL,
  `date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`pmid`),
  KEY `userid` (`userid`),
  KEY `status` (`status`),
  KEY `touser` (`touser`),
  KEY `fromuser` (`fromuser`),
  KEY `folder` (`folder`),
  KEY `date` (`date`),
  FULLTEXT KEY `subject` (`subject`),
  FULLTEXT KEY `message` (`message`)
)";

$sql[]="CREATE TABLE `statistics` (
  `statsid` int(11) NOT NULL auto_increment,
  `playedtoday` int(11) NOT NULL default '0',
  `datetoday` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`statsid`),
  KEY `datetoday` (`datetoday`),
  KEY `playedtoday` (`playedtoday`)
)";

$sql[]="CREATE TABLE `users` (
  `userid` int(11) NOT NULL auto_increment,
  `username` varchar(45) NOT NULL default '',
  `comments` int(11) NOT NULL default '0',
  `favourite` int(11) NOT NULL default '0',
  `played` int(11) NOT NULL default '0',
  `email` varchar(50) NOT NULL default '',
  `status` tinyint(4) NOT NULL default '0',
  `confirmation` varchar(32) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `joined` date NOT NULL default '0000-00-00',
  `location` varchar(45) NOT NULL default '',
  `avatar` varchar(255) NOT NULL default '',
  `avatar_uploaded` tinyint(4) NOT NULL default '0',
  `newpm` tinyint(4) NOT NULL default '0',
  `receiveemails` tinyint(4) NOT NULL default '0',
  `usergroup` tinyint(4) NOT NULL default '0',
  `website` varchar(100) NOT NULL default '',
  `gender` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`userid`),
  KEY `comments` (`comments`),
  KEY `favourite` (`favourite`),
  KEY `played` (`played`),
  KEY `status` (`status`),
  KEY `joined` (`joined`),
  KEY `avatar_uploaded` (`avatar_uploaded`),
  KEY `newpm` (`newpm`),
  KEY `receiveemails` (`receiveemails`),
  KEY `usergroup` (`usergroup`),
  KEY `gender` (`gender`),
  FULLTEXT KEY `username` (`username`),
  FULLTEXT KEY `email` (`email`),
  FULLTEXT KEY `confirmation` (`confirmation`),
  FULLTEXT KEY `password` (`password`),
  FULLTEXT KEY `location` (`location`),
  FULLTEXT KEY `website` (`website`)
)";

for($i=0; $i<count($sql); $i++) {
  mysql_query($sql[$i]);
  if(mysql_errno()!=0) die(mysql_error());
}

echo "<p>�� ��� ������� �����!</p>";

$sitename=$_POST["sitename"];
$sitedescription=$_POST["sitedescription"];
$sitekeywords=$_POST["sitekeywords"];
$siteurl=$_POST["siteurl"];
$sitecontactemail=$_POST["sitecontactemail"];
$adminusername=$_POST["adminusername"];
$adminpassword=$_POST["adminpassword"];

$f=fopen("../includes/dbinfo.php","wb");
if($f){
  fwrite($f,"<?php
// Your MySQL database host (usually \"localhost\")
\$db_host = \"$db_host\";
// Your MySQL database username
\$db_user = \"$db_user\";
// Your MySQL database password
\$db_pass = \"$db_pass\";
// Your MySQL database name
\$db_name = \"$db_name\";
// License key
\$license_key = \"Translate by aljayyash & sh2soft\";
?>");
  fclose($f);
} else { die("Can't write to includes/dbinfo.php"); }
echo "<p>includes/dbinfo.php �� �������!</p>";

$f=fopen("../includes/settings.php","wb");
if($f){
  if(get_magic_quotes_gpc()){
    $siteurl=stripslashes($siteurl);
    $sitename=stripslashes($sitename);
    $sitedescription=stripslashes($sitedescription);
    $sitekeywords=stripslashes($sitekeywords);
    $sitecontactemail=stripslashes($sitecontactemail);
    $adminusername=stripslashes($adminusername);
  }
  $xsiteurl=addslashes($siteurl);
  $xsitename=addslashes($sitename);
  $xsitedescription=addslashes($sitedescription);
  $xsitekeywords=addslashes($sitekeywords);
  $xsitecontactemail=addslashes($sitecontactemail);
  fwrite($f,"<?php
    \$siteonline = \"1\";
        \$siteurl = \"$xsiteurl\";
        \$filesdir = \"file\";
        \$sitename = \"$xsitename\";
        \$sitedescription = \"$xsitedescription\";
        \$sitekeywords = \"$xsitekeywords\";
        \$sitecontactemail = \"$xsitecontactemail\";
        \$template = \"style\";
        \$emailconfirmation = \"1\";
        \$addtoyourwebsite = \"1\";
        \$commentson = \"1\";
        \$commentapproval = \"1\";
        \$commentwho = \"2\";
        \$ratewho = \"2\";
        \$maxcomments = \"5\";
        \$mostpopularlist = \"1\";
        \$maxmostpopular = \"5\";
        \$newestlist = \"1\";
        \$maxnewest = \"5\";
        \$maxfilewidth = \"600\";
        \$maxfileheight = \"1000\";
        \$autoresize = \"1\";
        \$filesperpage = \"24\";
        \$maxindexpage = \"4\";
        \$memberlogin = \"1\";
        \$avataruploading = \"1\";
        \$maxavatarsize = \"10240\";
        \$topplayerslist = \"1\";
        \$maxtopplayers = \"5\";
        \$shownews = \"1\";
        \$maxnews = \"3\";
        \$links = \"1\";
        \$maxlinks = \"5\";
        \$relatedfiles = \"1\";
        \$maxrelatedfiles = \"5\";
        \$guestcredits = \"1\";
        \$maxguestplays = \"50\";
        \$sefriendly = \"0\";
        \$tellfriend = \"1\";
        \$submitcontent = \"2\";
        \$maxsubmitfilesize = \"1048576\";
        \$maxsubmitimagesize = \"5120\";
?>");
  fclose($f);
} else { die("�� ���� ������� ��� ����� ���� ����� ������� 66 includes/settings.php"); }
echo "<p>includes/settings.php �� �������!</p>";

$euserpassword=md5($adminpassword);

mysql_query("INSERT INTO users SET username = '$adminusername', email = '$sitecontactemail', location = '', website = '$siteurl', gender = '0', usergroup = '2', avatar = '', status = '1', password = '$euserpassword', joined = now()");
echo "<p>�� ��� ���� ������</p>";

echo "<p><b>�� ������� ����� , ���� ��� ���� install</b></p>";

?>