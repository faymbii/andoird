<?php
 
session_start();

include ("includes/config.php");

$page = $_GET[page];
if (empty($page) || !is_numeric($page)) {
	$page = "1";
}
$searchTerm = $_GET[t];
if (empty($searchTerm)) {
  $searchTerm = $_POST[t];
}
    
// Display games
function searchgames($page,$searchTerm) {
	global $siteurl, $filesperpage, $sefriendly;
	$result = mysql_query("SELECT * FROM files WHERE title LIKE '%$searchTerm%' && status ='1' || description LIKE '%$searchTerm%' && status ='1'");
	if (mysql_num_rows($result) == '0') {
		echo "No games found";
	} else {
		
		// Get number of pages
		$numrows = mysql_num_rows($result);
		$offset = ($page - 1) * $filesperpage;
		$pagescount = ceil($numrows/$filesperpage);
		
		for ($pagen = 1; $pagen <= $pagescount; $pagen++) {
			if ($pagen == $page) {
				$nav .= " <b>$pagen</b>";
            } else {
                if ($pagen >= $page - 5 && $pagen <= $page + 5) {
				    $nav .= " <a href=\"".$siteurl."/search.php?t=".$searchTerm."&page=".$pagen."\">$pagen</a>";
				}
	        } 
        }
        if ($page > 1) {
	        $pagen  = $page - 1;
	        $prev  = "<a href=\"".$siteurl."/search.php?t=".$searchTerm."&page=1\"><<</a> <a href=\"".$siteurl."/search.php?t=".$searchTerm."&page=".$pagen."\"><</a>";
	    } else {
		    $prev  = "";
		}
		if ($page < $pagescount) {
			$pagen = $page + 1;
			$next = " <a href=\"".$siteurl."/search.php?t=".$searchTerm."&page=".$pagen."\">></a> <a href=\"".$siteurl."/search.php?t=".$searchTerm."&page=".$pagescount."\">>></a>";
		} else {
			$next = "";
		}
    // Display page numbers
    if ($pagescount > '1') {
	    echo "<tr><td colspan='3' class='pagenumbers'>".$prev.$nav.$next."</td></tr>";
    }
	
	$result2 = mysql_query("SELECT fileid, title, description, icon, iconlocation, timesplayed FROM files WHERE title LIKE '%$searchTerm%' && status ='1' || description LIKE '%$searchTerm%' && status ='1' ORDER BY title LIMIT $offset, $filesperpage");
	
		$fileinrow="1";
    while($row = mysql_fetch_array($result2)) {
	    $fileid = $row['fileid'];
        $filetitle = $row['title'];
        $filedescription = $row['description'];
        $fileicon = $row['icon'];
        $iconlocation = $row['iconlocation'];
        $timesplayed = number_format($row['timesplayed']);
        
        if ($iconlocation == '1') {
	        $imageurl = $siteurl."/files/image/".$fileicon;
        } else {
	        $imageurl = $fileicon;
        }
        
        if (strlen($filedescription) > '40') {
	        $filedescription = substr("$filedescription",0,37)."...";
        }
        
        if ($fileinrow == '1') {
	     echo "<tr>";   
        }
    ?>
    <td width="33%">
      <table class="browsegamesbox">
        <tr>
          <td width="71" valign="top">
          <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self"><img src="<?php echo $imageurl; ?>" width="70" height="59" title="<?php echo $filetitle; ?>" border="0"></a>
          </td>
          <td valign="top">
          <a href="<?php echo fileurl($fileid,$filetitle); ?>" target="_self" class="gamelink"><?php echo $filetitle; ?></a><br />
          <?php echo $filedescription; ?><br />
          <span class="played">(Played: <?php echo $timesplayed; ?> times)</span>
          </td>
        </tr>
      </table>
    </td>
    <?php
        if ($fileinrow == '3') {
	     echo "</tr>";
	     $fileinrow = "0";
        }
        $fileinrow++;
    }
    if ($fileinrow == '2') {
	    echo "<td width=\"33%\"></td><td width=\"33%\"></td></tr>";
    } elseif ($fileinrow == '3') {
	    echo "<td width=\"33%\"></td></tr>";
    }
    // Display page numbers
    if ($pagescount > '1') {
	    echo "<tr><td colspan='3' class='pagenumbers'>".$prev.$nav.$next."</td></tr>";
    }
    }
}
$sitename2 = $sitename." - Search";

// Load template files
include ("templates/".$template."/header.html");
include ("templates/".$template."/search.html");
include ("templates/".$template."/footer.html");
?>