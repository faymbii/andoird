<?php
 
session_start();

include ("includes/config.php");

if ($userStatus != '1') {
	header ("Location: ".$siteurl."/");
}
$pmFolder = $_GET[folder];
if ($pmFolder == '2') {
	$pmFolder = "2";
} else {
	$pmFolder = "1";
}
$pmAction = $_GET[a];
$pmError = $_GET[e];
$readpmId = $_GET[pmid];
$composepmUserid = $_GET[uid];

	
if ($pmAction == 'read') {
	$readpm_result = mysql_query("SELECT * FROM privatemessages WHERE pmid = '$readpmId' && userid = '$userId'");
	if (mysql_num_rows($readpm_result) == '0') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$readpm_row = mysql_fetch_array($readpm_result);
	$readpmFromuser = $readpm_row['fromuser'];
	$fromname_sql = mysql_query("SELECT username, avatar, avatar_uploaded, played, comments, joined FROM users WHERE userid = '$readpmFromuser'");
	if (mysql_num_rows($fromname_sql)) {
		$fromname_row = mysql_fetch_array($fromname_sql);
	    $readpmFromuserName = ($fromname_row['username']);
		$readpmFromuserurl = profileurl($readpmFromuser,$readpmFromuserName);
	    $readpmFromuserAvatar = ($fromname_row['avatar']);
	    $avatarUploaded = $fromname_row['avatar_uploaded'];
	    if (empty($readpmFromuserAvatar)) {
		    $readpmFromuserAvatar = $siteurl."/images/noavatar.gif";
		}
		if (empty($readpmFromuserAvatar)) {
		    $readpmFromuserAvatar = $siteurl."/images/noavatar.gif";
		    $avatarWidth = "100";
		    $avatarHeight = "100";
		} else {
		    if ($avatarUploaded == '1') {
		    	$readpmFromuserAvatar = $siteurl."/images/avatars/".$readpmFromuserAvatar;
			}
			$avatarSize = @getimagesize($readpmFromuserAvatar);
			$avatarWidth = $avatarSize[0];
			$avatarHeight = $avatarSize[1];
			if ($avatarWidth > 150) {
			    $change = ($avatarWidth / 150);
				$avatarWidth = 150;
				$avatarHeight = ($avatarHeight / $change);    
			}
			if ($avatarHeight > 150) {
			  $change = ($avatarHeight / 150);
			  $avatarHeight = 150;
			  $avatarWidth = ($avatarWidth / $change);    
			}
		}
		$readpmFromuserPlayed = number_format($fromname_row['played']);
	    $readpmFromuserComments = number_format($fromname_row['comments']);
	    $readpmFromuserJoined = $fromname_row['joined'];
    }
    $readpmSubject = ($readpm_row['subject']);
    if (empty($readpmSubject)) {
		$readpmSubject = "[No Subject]";
	}
	$readpmMessage = nl2br(($readpm_row['message']));
	$readpmMessage = bbcode($readpmMessage);
	$readpmDate = $readpm_row['date'];
	$readpmStatus = $readpm_row['status'];
	if ($readpmStatus == '0') {
		$update_status = mysql_query("UPDATE privatemessages SET status = '1' WHERE pmid = '$readpmId'");
	}
	$sitename2 = $sitename;
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/readprivatemessage.html");
	include ("templates/".$template."/footer.html");
} elseif ($pmAction == 'delete') {
	$readpm_result = mysql_query("SELECT * FROM privatemessages WHERE pmid = '$readpmId' && userid = '$userId'");
	if (mysql_num_rows($readpm_result) == '0') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$delete_pm = mysql_query("DELETE FROM privatemessages WHERE pmid='$readpmId'");
	if ($pmFolder == '2') {
		header ("Location: ".$siteurl."/privatemessages.php?folder=2");
	} else {
		header ("Location: ".$siteurl."/privatemessages.php");
	}
	exit();
} elseif ($pmAction == 'compose') {
	// Get username
	$composepmRecipient = "";
	if (strlen($composepmUserid)) {
		$recipient_sql = mysql_query("SELECT * FROM users WHERE userid = '$composepmUserid'");
	    $composepmRecipient = "";
		if (mysql_num_rows($recipient_sql)) {
		    $recipient_row = mysql_fetch_array($recipient_sql);
		    $composepmRecipient = ($recipient_row['username']);
        }
	}
	// Get message and subject
	$composepmMessage = NULL;
	$composepmSubject = NULL;
	$send_error = NULL;
	if (strlen($readpmId)) {
		$message_sql = mysql_query("SELECT * FROM privatemessages WHERE pmid = '$readpmId' && userid = '$userId'");
		if (mysql_num_rows($message_sql)) {
		    $message_row = mysql_fetch_array($message_sql);
		    $composepmMessage = "[quote]".($message_row['message'])."[/quote]\n";
		    $composepmSubject = ($message_row['subject']);
		    if (substr("$composepmSubject",0,3) != 'Re:') {
			    $composepmSubject = "Re: ".($message_row['subject']);
		    }
        }
    }
    if (isset($_POST[preview])) {
		 $composepmRecipient = ($_POST[messagerecipient]);
		 $composepmSubject = ($_POST[messagesubject]);
		 $composepmMessage = (stripslashes($HTTP_POST_VARS[message]));
		 $previewSubject = $composepmSubject;
		 $previewMessage = bbcode(nl2br($composepmMessage));
	} elseif (isset($_POST[submit])) {
		$sendpmRecipient = $_POST[messagerecipient];
		$sendpmSubject = $_POST[messagesubject];
		$sendpmMessage = $_POST[message];
		
		$sendpmuser_sql = mysql_query("SELECT * FROM users WHERE username = '$sendpmRecipient' && status = '1'");
		if (mysql_num_rows($sendpmuser_sql)) {
			$sendpmuser_row = mysql_fetch_array($sendpmuser_sql);
			$sendpmUserid = $sendpmuser_row['userid'];		
			// Send message
			$result = mysql_query( "INSERT INTO privatemessages SET userid = '$sendpmUserid', touser = '$sendpmUserid', fromuser = '$userId', folder = '1', subject = '$sendpmSubject', message = '$sendpmMessage', date = now(), status = '0'");
			// Also save it to your sent items
			$result = mysql_query( "INSERT INTO privatemessages SET userid = '$userId', touser = '$sendpmUserid', fromuser = '$userId', folder = '2', subject = '$sendpmSubject', message = '$sendpmMessage', date = now(), status = '1'");
			// And make it so that user who gets new PM gets also pop-up
			$update_pm = mysql_query("UPDATE users SET newpm = '1' WHERE userid = '$sendpmUserid'");
			
			$send_error = "Message sent";
		} else {
			$composepmRecipient = ($_POST[messagerecipient]);
			$composepmSubject = ($_POST[messagesubject]);
			$composepmMessage = (stripslashes($HTTP_POST_VARS[message]));
			$previewSubject = $composepmSubject;
			$previewMessage = bbcode(nl2br($composepmMessage));
			$send_error = "Invalid recipient";
		}
	}
    $sitename2 = $sitename;
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/composeprivatemessage.html");
	include ("templates/".$template."/footer.html");
} elseif ($pmAction == 'newprivatemessage') {
	
	$sitename2 = $sitename." - New Private Message";
	include ("templates/".$template."/newprivatemessage.html");
	
} else {
    function displaypms($userId,$pmFolder) {
	    global $siteurl, $sefriendly;
		$pm_result = mysql_query("SELECT * FROM privatemessages WHERE userid = '$userId' && folder = '$pmFolder' ORDER BY pmid DESC");
		if (mysql_num_rows($pm_result) == '0') {
		    echo "<tr><td colspan=\"5\" align=\"center\">You have no private messages</td></tr>";
		} else {
		    while($pm_row = mysql_fetch_array($pm_result)) {
			    $pmId = $pm_row['pmid'];
				$pmSubject = ($pm_row['subject']);
				if (empty($pmSubject)) {
				    $pmSubject = "[No Subject]";
				}
				if ($pmFolder == '2') {
				    $pmFromuser = $pm_row['touser'];
				} else {
				    $pmFromuser = $pm_row['fromuser'];
				}
				$pmMessage = ($pm_row['message']);
				if (strlen($pmMessage) > '60') {
				    $pmMessage = substr("$pmMessage",0,57)."...";
				}
				$fromname_sql = mysql_query("SELECT username FROM users WHERE userid = '$pmFromuser'");
				if (mysql_num_rows($fromname_sql)) {
				    $fromname_row = mysql_fetch_array($fromname_sql);
					$pmFromuserName = ($fromname_row['username']);
				}
				$pmFromuserurl = profileurl($pmFromuser,$pmFromuserName);
				$pmDate = $pm_row['date'];
				$pmStatus = $pm_row['status'];
				if ($pmStatus == '1') {
				    $pmStatusImg = $siteurl."/images/read.gif";
					$pmStatusText = "Read";
				} else {
				    $pmStatusImg = $siteurl."/images/unread.gif";
					$pmStatusText = "Unread";
				}
?>
		<tr>
          <td width="5%" align="center"><img src="<?php echo $pmStatusImg; ?>" width="16" height="16" title="<?php echo $pmStatusText; ?>" alt="<?php echo $pmStatusText; ?>"></td><td width="40%"  align="left"><a href="<?php echo $siteurl; ?>/privatemessages.php?a=read&pmid=<?php echo $pmId; ?>" target="_self" title="<?php echo $pmMessage; ?>"><?php if ($pmStatus == '0') { echo "<b>"; } ?><?php echo $pmSubject; ?><?php if ($pmStatus == '0') { echo "</b>"; } ?></a></td><td width="20%" align="center"><a href="<?php echo $pmFromuserurl; ?>" target="_self"><?php echo $pmFromuserName; ?></a></td><td width="20%" align="center"><?php echo $pmDate; ?></td><td width="15%" align="center"><a onclick='return confirmDelete()' href="<?php echo $siteurl; ?>/privatemessages.php?a=delete&pmid=<?php echo $pmId; if ($pmFolder == '2') { echo "&folder=2"; } ?>" target="_self">Delete</a></td>
        </tr>
<?php
		    }
		}
	}
	$sitename2 = $sitename;
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/privatemessages.html");
	include ("templates/".$template."/footer.html");
}

?>