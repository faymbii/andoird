<?php
 
session_start();

include ("includes/config.php");

$action = $_GET[action];

if ($action == 'wrongpw') {
    if ($userStatus == '1') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$sitename2 = $sitename;
	
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/wrongpw.html");
	include ("templates/".$template."/footer.html");
} elseif ($action == 'logout') {
	// Unset sessions
	session_unset();  
    // Now destory them and remove them from the users browser
	session_destroy(); 
	// Kill cookies
	setcookie("arcadeuser", '', time() - 60*60*24*365, "/");
    header("Location: ".$siteurl."/"); 
    exit();
} elseif ($action == 'lostpw') { 
    if ($userStatus == '1') {
		header ("Location: ".$siteurl."/");
		exit();
	}
	$lostpwAction = $_GET[a];
	$lostpwError = $_GET[e];
	$lostpwErrorText = "";
	if ($lostpwError == '1') {
		$lostpwErrorText = "&#1606;&#1575;&#1587;&#1601; &#1575;&#1610;&#1605;&#1610;&#1604;&#1603; &#1594;&#1610;&#1585; &#1605;&#1583;&#1585;&#1580; &#1576;&#1575;&#1604;&#1576;&#1610;&#1575;&#1606;&#1575;&#1578; &#1604;&#1583;&#1610;&#1606;&#1575;";
	}
	$lostpwEmail = $_POST[recoverEmail];
	$lostpwCode = $_GET[code];
	$lostpwId = $_GET[id];
    if ($lostpwAction == 'confirm') {
	    if (!strlen($lostpwEmail)) {
		    header ("Location: ".$siteurl."/index.php?action=lostpw&e=1"); 
			exit();
		}
		$lostinfo_result = mysql_query("SELECT * FROM users WHERE email = '$lostpwEmail' && status = '1' LIMIT 1");
		if (mysql_num_rows($lostinfo_result) == '0') {
		    header ("Location: ".$siteurl."/index.php?action=lostpw&e=1");
			exit();
		}
		$lostinfo_row = mysql_fetch_array($lostinfo_result);
		$lostuserId = $lostinfo_row['userid'];
		$lostuserName = ($lostinfo_row['username']);
		
		$uniqkey = substr( md5(uniqid (rand())), 0, 9 );
		$result = mysql_query("UPDATE users SET confirmation = '$uniqkey' WHERE email = '$lostpwEmail' && status = '1'");
    
		// Send email
		$to = "$lostpwEmail";
		$subject = "&#1575;&#1587;&#1578;&#1585;&#1580;&#1575;&#1593; &#1575;&#1604;&#1585;&#1602;&#1605; &#1575;&#1604;&#1587;&#1585;&#1610;";
		$headers = "Return-Path: ".$sitecontactemail."\r\n";
		$headers .= "From: ".$sitename." <".$sitecontactemail.">\n";
		$headers .= "MIME-Version: 1.0\n";
		$headers .= "Content-type: text/html\r\n"; 
		$msg .= "<p dir=\"rtl\" align=\"right\">&#1605;&#1585;&#1581;&#1576;&#1575; ".$lostuserName."</p>
<p dir=\"rtl\" align=\"right\">&#1588;&#1603;&#1585;&#1575; &#1604;&#1603; &#1593;&#1604;&#1609; &#1578;&#1587;&#1580;&#1610;&#1604;&#1603; &#1601;&#1610; &#1605;&#1603;&#1578;&#1576;&#1577; &#1575;&#1604;&#1601;&#1610;&#1583;&#1610;&#1608; &#1575;&#1604;&#1582;&#1575;&#1589;&#1577; &#1576;&#1600; 
".$sitename."</p>
<p dir=\"rtl\" align=\"right\">&#1610;&#1585;&#1580;&#1609;<a href=\"".$siteurl."/login.php?action=lostpw&a=change&id=".$lostuserId."&code=".$uniqkey."\"> 
&#1575;&#1604;&#1590;&#1594;&#1591; &#1607;&#1606;&#1575;</a> &#1604;&#1578;&#1571;&#1603;&#1610;&#1583; &#1575;&#1604;&#1578;&#1587;&#1580;&#1610;&#1604; &#1608; &#1581;&#1578;&#1609; &#1578;&#1578;&#1605;&#1603;&#1606; &#1605;&#1606; &#1575;&#1604;&#1605;&#1588;&#1575;&#1585;&#1603;&#1577; &#1576;&#1575;&#1604;&#1605;&#1603;&#1578;&#1576;&#1577; </p>
<p dir=\"rtl\" align=\"right\">&#1575;&#1584;&#1575; &#1604;&#1605; &#1578;&#1578;&#1605;&#1603;&#1606; &#1605;&#1606; &#1575;&#1604;&#1578;&#1601;&#1593;&#1610;&#1604; &#1593;&#1576;&#1585; &#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1575;&#1593;&#1604;&#1575;&#1607; &#1610;&#1585;&#1580;&#1609; &#1606;&#1587;&#1582; 
&#1575;&#1604;&#1585;&#1575;&#1576;&#1591; &#1607;&#1584;&#1575; &#1576;&#1575;&#1604;&#1605;&#1578;&#1589;&#1601;&#1581;</p>
<p dir=\"rtl\" align=\"right\">
".$siteurl."/login.php?action=lostpw&a=change&id=".$lostuserId."&code=".$uniqkey."";
		@mail($to, $subject, $msg, $headers);
    } elseif ($lostpwAction == 'change') {
	    if (strlen($lostpwCode) != '9' && !strlen($lostpwId)) {
		    header ("Location: ".$siteurl."/"); 
			exit();
		}
		$lostinfo_result = mysql_query("SELECT * FROM users WHERE userid = '$lostpwId' && confirmation = '$lostpwCode'");
		if (mysql_num_rows($lostinfo_result) == '0') {
			header ("Location: ".$siteurl."/");
			exit();
		}
		$lostinfo_row = mysql_fetch_array($lostinfo_result);
	    $lostpwEmail = $lostinfo_row['email'];
	    $lostuserName = ($lostinfo_row['username']);
		
		$uniqpw = substr( md5(uniqid (rand())), 0, 5 );
		$newuniqpw = md5($uniqpw);
		
		$result = mysql_query("UPDATE users SET password = '$newuniqpw', confirmation = '' WHERE userid = '$lostpwId'");
		
		// Send email
        $to = "$lostpwEmail";
        $subject = "&#1575;&#1604;&#1585;&#1602;&#1605; &#1575;&#1604;&#1587;&#1585;&#1610; &#1575;&#1604;&#1580;&#1583;&#1610;&#1583;";
        $headers = "Return-Path: ".$sitecontactemail."\r\n";
        $headers .= "From: ".$sitename." <".$sitecontactemail.">\n";
        $headers .= "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html\r\n"; 
	$msg .= "&#1605;&#1585;&#1581;&#1576;&#1575; ".$lostuserName."<br><br>";
        $msg .= "&#1578;&#1601;&#1590;&#1604; &#1607;&#1584;&#1575; &#1575;&#1604;&#1585;&#1602;&#1605; &#1575;&#1604;&#1587;&#1585;&#1610; &#1575;&#1604;&#1580;&#1583;&#1610;&#1583; &#1575;&#1604;&#1582;&#1575;&#1589; &#1576;&#1603;<br>";
        $msg .= "&#1575;&#1587;&#1605; &#1575;&#1604;&#1605;&#1587;&#1578;&#1582;&#1583;&#1605;: ".$lostuserName."<br>";
        $msg .= "&#1575;&#1604;&#1585;&#1602;&#1605; &#1575;&#1604;&#1587;&#1585;&#1610;: ".$uniqpw."<br><br>";
        $msg .= "&#1588;&#1603;&#1585;&#1575; &#1604;&#1603;";
        @mail($to, $subject, $msg, $headers);
}
	$sitename2 = $sitename." - Lost Password";
	// Load template files
	include ("templates/".$template."/header.html");
	include ("templates/".$template."/lostpw.html");
	include ("templates/".$template."/footer.html");
} else {
    $username = $_POST[username];
	$password = md5($_POST[password]);
	$remember = $_POST[remember];
	
	if (empty($username) || empty($password)) {
	    header("Location: ".$siteurl."/login.php?action=wrongpw");
		exit();
	}
	
	$check = mysql_query("SELECT * FROM users WHERE username = '$username' && password = '$password'");
	if (mysql_num_rows($check) > 0) {	
	    $row = mysql_fetch_array($check);
		$userid = $row['userid'];	
		if ($row['status'] == '1') {
		    $_SESSION['userid'] = $userid;
			if ($remember == '1'){
			    setcookie("arcadeuser", $userid.":".$password, time()+60*60*24*365, "/");
			}
			header("Location: ".$_SERVER['HTTP_REFERER']);
			exit();
		} else {
		    header("Location: ".$siteurl."/");
			exit();
		}
	} else {
	    header("Location: ".$siteurl."/login.php?action=wrongpw");
		exit();
	}
}
?>