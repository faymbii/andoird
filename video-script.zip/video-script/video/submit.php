<?php
 
session_start();

include ("includes/config.php");
if ($submitcontent == '0' || $userStatus != '1' && $submitcontent == '2') {
	header("Location: ".$siteurl."/");
	exit();
}
	
if (isset($_POST[submit])) {
	$fileTitle = $_POST[fileTitle];
	$fileDescription = $_POST[fileDescription];
	$fileCategory = $_POST[fileCategory];
	$fileType = $_POST[fileType];
	if (strlen($_FILES['fileFile']['name']) && strlen($_FILES['fileImage']['name']) && strlen($fileTitle) && strlen($fileDescription) && strlen($fileCategory) && strlen($fileType)) {
		$check_gamename = mysql_query("SELECT count(fileid) AS filenamecount FROM files WHERE title = '$fileTitle'");
		$get_check_gamename = mysql_fetch_array($check_gamename);
		$gamenamecount = $get_check_gamename['filenamecount'];
		if ($gamenamecount == '0') {
			$validFile = array ("jpg","gif","png","avi","wmv","mpg","swf","dcr");
			$extensionFile = strtolower( substr($_FILES['fileFile']['name'], -3));
			$validImage = array ("jpg","gif","png");
			$extensionImage = strtolower( substr($_FILES['fileImage']['name'], -3));
			if (in_array($extensionFile, $validFile) && in_array($extensionImage, $validImage) && $_FILES['fileFile']['size'] <= $maxsubmitfilesize && $_FILES['fileImage']['size'] <= $maxsubmitimagesize) {
				$uniqkey = substr( md5(uniqid (rand())), 0, 9 );
				@move_uploaded_file($_FILES['fileFile']['tmp_name'], "files/".$filesdir."/".$uniqkey.".".$extensionFile);
				@move_uploaded_file($_FILES['fileImage']['tmp_name'], "files/image/".$uniqkey.".".$extensionImage);
				$size = @getimagesize($siteurl."/files/".$filesdir."/".$uniqkey.".".$extensionFile);
				$filewidth = $size[0];
				$fileheight = $size[1];
				if ($autoresize == '1') {
	    			if ($filewidth > $maxfilewidth) {
		    			$change = ($filewidth / $maxfilewidth);
						$filewidth = $maxfilewidth;
						$fileheight = ($fileheight / $change);    
					}
					if ($fileheight > $maxfileheight) {
		    			$change = ($fileheight / $maxfileheight);
						$fileheight = $maxfileheight;
						$filewidth = ($filewidth / $change);    
					}
    			}
    			$dateadded = date('Y-m-d');
    			
				$addgame = mysql_query("INSERT INTO files SET  title = '$fileTitle', description = '$fileDescription', keywords = '$fileTitle', category = '$fileCategory', width = '$filewidth', height = '$fileheight', filetype = '$fileType', file = '$uniqkey.$extensionFile', filelocation = '1', icon = '$uniqkey.$extensionImage', iconlocation = '1', status = '2', dateadded = '$dateadded'");
				$error = "File has been submitted!";
			} else {
				$error = "File or image is too big!";
			}
		} else {
			$error = "This file is already in our database!";
		}
	} else {
		$error = "All fields are required!";
	}
}
function selectcaterory() {
echo '<select name="fileCategory">\n';
$category_result = mysql_query("SELECT name,catid FROM categories ORDER BY name");
if (mysql_num_rows($category_result)) {
	while ($cat_row = mysql_fetch_array($category_result)) {
		echo "<option value=\"".$cat_row['catid']."\">".stripslashes($cat_row['name'])."</option>\n";
	}
}
echo '</select>';
}


$sitename2 = $sitename." - Submit Content";
$sitekeywords = $sitekeywords.", submit content";

// Load template files
include ("templates/".$template."/header.html");
include ("templates/".$template."/submit.html");
include ("templates/".$template."/footer.html");
?>